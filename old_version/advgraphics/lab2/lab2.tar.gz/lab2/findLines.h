//
//  findLines.h
//  lab2
//
//  Created by Andrew Cantino on 2/16/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <AppKit/AppKit.h>
#import "effect.h"

@interface findLines : effect {
	float *xS;
	float *yS;
	unsigned char *bw;
	NSMutableArray *points;
	int threshold;
	int mode;
}
- (void)doApplyRGB:(Pixel *)imgData width:(int)w height:(int)h;
- (void)doApplyMono:(unsigned char *)imgData width:(int)w height:(int)h;
- (void)dealloc;
- (void)setMode:(int)m;
- (void)doSnow2On:(Pixel *)imgData width:(int)w height:(int)h;
- (void)setThreshold:(float)t;

@end
