//
//  effect.h
//  lab2
//
//  Created by Andrew Cantino on 2/16/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <AppKit/AppKit.h>

typedef struct Pixel {
	unsigned char r, g, b;
} Pixel;

@interface effect : NSObject {
	NSImage *srcImage;
}
- (id)initWithImage:(NSImage *)inImage;
- (void)setImage:(NSImage *)inImage;
- (NSImage *)apply;
- (void)doApplyRGB:(Pixel *)imgData width:(int)w height:(int)h;
- (void)doApplyMono:(unsigned char *)imgData width:(int)w height:(int)h;
- (float *)convolveImage:(unsigned char *)imgData 
				   width:(int)w 
				  height:(int)h
		 withConvolution:(float[])convolveImage 
				 ofSizeX:(int)Xsize
				andSizeY:(int)Ysize;
- (void)dealloc;

@end
