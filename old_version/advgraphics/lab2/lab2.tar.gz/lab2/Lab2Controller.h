/* Lab2Controller */

#import <Cocoa/Cocoa.h>
#import "findLines.h"

@interface Lab2Controller : NSObject
{
    IBOutlet NSTextField *curFile;
    IBOutlet NSImageView *image;
    IBOutlet NSPopUpButton *partSelect;
	IBOutlet NSSlider *threshold;
	NSString *file;
	NSImage *myImage;
	findLines *l;
}
- (IBAction)go:(id)sender;
- (IBAction)reloadImage:(id)sender;
- (IBAction)loadImage:(id)sender;
- (NSString *)loadDialog;
- (IBAction)saveCurrent:(id)sender;
- (void) awakeFromNib;
- (void)dealloc;
@end
