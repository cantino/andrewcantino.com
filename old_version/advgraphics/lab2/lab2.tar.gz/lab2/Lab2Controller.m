#import "Lab2Controller.h"
#import "findLines.h"

@implementation Lab2Controller

- (void) awakeFromNib
{  
	[curFile setStringValue:@"none"];
}  


- (IBAction)go:(id)sender
{
	[myImage autorelease];
	if ([[[partSelect selectedItem] title] isEqualToString:@"Snow"]) {
		[l setMode:1];
	} else if ([[[partSelect selectedItem] title] isEqualToString:@"Edges"]) {
		[l setMode:2];
	} else if ([[[partSelect selectedItem] title] isEqualToString:@"Snow2"]) {
		[l setMode:3];
	}
	[l setThreshold:[threshold floatValue]];
	myImage = [l apply];
	[image setImage:myImage];
}

- (void)dealloc {
	[l autorelease];
}

- (IBAction)reloadImage:(id)sender {
	if (! [file isEqualToString:@""]) {
		[curFile setStringValue:file];
		if (myImage)
			[myImage autorelease];
		myImage = [[NSImage alloc] initWithContentsOfFile:file];
		[image setImage:myImage];
		
		[l autorelease];
		l = [[findLines alloc] initWithImage:myImage];
		
		if (! [image image]) {
			[curFile setStringValue:@"not an image!"];
		}
	} else {
		[curFile setStringValue:@"none"];
	}
}

- (IBAction)loadImage:(id)sender
{
	file = [self loadDialog];
	if (! [file isEqualToString:@""]) {
		[curFile setStringValue:file];
		if (myImage)
			[myImage autorelease];
		myImage = [[NSImage alloc] initWithContentsOfFile:file];
		[image setImage:myImage];
		
		[l autorelease];
		l = [[findLines alloc] initWithImage:myImage];
		
		if (! [image image]) {
			[curFile setStringValue:@"not an image!"];
		}
	} else {
		[curFile setStringValue:@"none"];
	}
}

- (NSString *)loadDialog
{
	int result;
	NSString *aFile;
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];
    [oPanel setAllowsMultipleSelection:NO];
    result = [oPanel runModalForDirectory:NSHomeDirectory() file:nil];
    if (result == NSOKButton) {
        NSArray *filesToOpen = [oPanel filenames];
        int i, count = [filesToOpen count];
        for (i=0; i<count; i++) {
            aFile = [filesToOpen objectAtIndex:i];
        }
		return aFile;
    } else {
		return @"";
	}
}

- (IBAction)saveCurrent:(id)sender
{
	NSSavePanel *sp;
	int runResult;
	sp = [NSSavePanel savePanel];
	[sp setRequiredFileType:@"tiff"];
	runResult = [sp runModalForDirectory:NSHomeDirectory() file:@""];
	if (runResult == NSOKButton && myImage) {
		[[myImage TIFFRepresentation] writeToFile:[sp filename] atomically:YES];
	} else {
		NSBeep();
		NSWindow *infoWindow;
		infoWindow = NSGetCriticalAlertPanel( @"Save failed",
											  @"Failed to save image",
											  @"OK", nil, nil );
		[ NSApp runModalForWindow:infoWindow ];
		[ infoWindow close ];
	}
}

@end
