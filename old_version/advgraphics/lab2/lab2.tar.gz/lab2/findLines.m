//
//  findLines.m
//  lab2
//
//  Created by Andrew Cantino on 2/16/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import "findLines.h"
#import "point.h"


@implementation findLines

- (void)setMode:(int)m { mode = m; }
- (void)setThreshold:(float)t { threshold = (int)t; }

- (void)doSnow2On:(Pixel *)imgData width:(int)w height:(int)h {
	int i, x, y;
	for ( i = 0; i < 100000; i++ ) {
		int rX = (int)(random() % w);
		int rY = (int)(random() % h);
		if (rY > -1 && rY < h - 1 && rX > 0 && rX < w - 1) {
			if (yS[(rY + 1) * w + rX] > threshold || ((bw[(rY + 1) * w + rX - 1] == 201 && bw[(rY + 1) * w + rX] == 201 && bw[(rY + 1) * w + rX + 1] == 201) || ((int)(random() % 5) == 2 && bw[(rY + 1) * w + rX] == 201))) {
				if ((int)(random() % 20) == 2) { // Sometimes add a pixel to the right as well.
					bw[rY * w + rX + 1] = 201;
				}
				if ((int)(random() % 20) == 2) { // Sometimes add a pixel to the left as well.
					bw[rY * w + rX - 1] = 201;
				}
				bw[rY * w + rX] = 201;
			}
		}
	}
	for ( y = 0; y < h; y++ ) {
		for ( x = 0; x < w; x++ ) {
			if (bw[y * w + x] == 201) {
				int a = random() % 20;
				imgData[y * w + x].r = 255 - a;
				imgData[y * w + x].g = 255 - a;
				imgData[y * w + x].b = 255 - a;
			}
		}
	}
	
	//Gaussian filter
	//float gaussian[] = {1/273.0, 4/273.0, 7/273.0, 4/273.0, 1/273.0, 4/273.0, 16/273.0, 26/273.0, 16/273.0, 4/273.0, 7/273.0, 26/273.0, 41/273.0, 26/273.0, 7/273.0, 4/273.0, 16/273.0, 26/273.0, 16/273.0, 4/273.0, 1/273.0, 4/273.0, 7/273.0, 4/273.0, 1/273.0};
	//[self convolveImage:imgData width:w height:h withConvolution:conv ofSizeX:5 andSizeY:5];
}

- (void)doApplyRGB:(Pixel *)imgData width:(int)w height:(int)h {
	if (! xS) {
		bw = malloc(sizeof(unsigned int) * w * h);
		int x, y;
		for ( y = 0; y < h; y++ )
			for ( x = 0; x < w; x++ )
				bw[y * w + x] = (0.222*imgData[y * w + x].r) + (0.707*imgData[y * w + x].g) + (0.071*imgData[y * w + x].b); // http://www.oreillynet.com/cs/user/view/cs_msg/8691
		
		//http://www.cee.hw.ac.uk/hipr/html/sobel.html
		float xSobal[] = {-1, 0, 1, -2, 0, 2, -1, 0, 1};
		float ySobal[] = {1, 2, 1, 0, 0, 0, -1, -2, -1};
		
		xS = [self convolveImage:bw width:w height:h withConvolution:xSobal ofSizeX:3 andSizeY:3];
		yS = [self convolveImage:bw width:w height:h withConvolution:ySobal ofSizeX:3 andSizeY:3];
		
		for ( y = 0; y < h; y++ )
			for ( x = 0; x < w; x++ )
				bw[y * w + x] = sqrt(pow(yS[y * w + x], 2) + pow(xS[y * w + x], 2)) > threshold ? 255 : 0;
		
		points = [[NSMutableArray alloc] init];
		
		srandom(time(NULL));
	}
	
	if (mode == 3) {
		[self doSnow2On:imgData width:w height:h];
	} else {
		int j;
		for (j = 0; j < 2; j++) {
			int x, y, i;
			float tStep = 1;
			
			// Add some new particles
			point *p;
			for ( i = 0; i < 10; i++ ) {
				float rX = random() % w;
				float rY = 1;
				//float vx = (random() % 10) - 5;
				//float vy = (random() % 10) - 5;
				p = [[[point alloc] initWithX:rX andY:rY] autorelease];
				//[p setVX:vx andVY:vy];
				[points addObject:p];
			}
			
			/*for ( y = 0; y < h; y++ ) {
				for ( x = 0; x < w; x++ ) {
					imgData[y * w + x].r = sqrt(pow(yS[y * w + x], 2) + pow(xS[y * w + x], 2)) > 100 ? 255 : 0;
					imgData[y * w + x].g = imgData[y * w + x].r;
					imgData[y * w + x].b = imgData[y * w + x].r;
				}
			}
			*/
			NSLog(@"count: %d", [points count]);
			//NSLog(@"Point at (%f, %f) with velocity (%f, %f).", [p x], [p y], [p vx], [p vy]);
			for ( i = [points count] - 1; i > -1; i-- ) {
				point *p = [points objectAtIndex:i];
				[p setY:([p y] + 1)];
				imgData[(int)[p y] * w + (int)[p x]].r = 255;
				imgData[(int)[p y] * w + (int)[p x]].g = 255;
				imgData[(int)[p y] * w + (int)[p x]].b = 255;
				if ([p y] > -1 && [p y] < h - 1 && [p x] > 0 && [p x] < w - 1) {
					if (bw[(int)([p y] + 1) * w + (int)[p x]] > 200) { // If the next pixel down is marked, mark this one
						bw[(int)[p y] * w + (int)[p x]] = 201;
						[points removeObjectAtIndex:i];
					}
				} else {
					[points removeObjectAtIndex:i];
				}	
			}
			
			for ( y = 0; y < h; y++ ) {
				for ( x = 0; x < w; x++ ) {
					if (mode == 2) {
						if (bw[y * w + x] > 201) {
							imgData[y * w + x].r = 255;
							imgData[y * w + x].g = 0;
							imgData[y * w + x].b = 0;
						} else {
							imgData[y * w + x].r = 0;
							imgData[y * w + x].g = 0;
							imgData[y * w + x].b = 0;
						}
					}
					if (bw[y * w + x] == 201 && mode == 1) {
						imgData[y * w + x].r = 255;
						imgData[y * w + x].g = 255;
						imgData[y * w + x].b = 255;
					}
				}
			}
		}
	}
}

- (void)dealloc {
	[super dealloc];
	[points autorelease];
	NSLog(@"Performing dealloc of findLines");
	if (xS)
		free(xS);
	if (yS)
		free(yS);
	if (bw)
		free(bw);
}

- (void)doApplyMono:(unsigned char *)imgData width:(int)w height:(int)h {
	int x, y;
	// Gaussian filter
	//float conv[] = {1/273.0, 4/273.0, 7/273.0, 4/273.0, 1/273.0, 4/273.0, 16/273.0, 26/273.0, 16/273.0, 4/273.0, 7/273.0, 26/273.0, 41/273.0, 26/273.0, 7/273.0, 4/273.0, 16/273.0, 26/273.0, 16/273.0, 4/273.0, 1/273.0, 4/273.0, 7/273.0, 4/273.0, 1/273.0};
	//[self convolveImage:imgData width:w height:h withConvolution:conv ofSizeX:5 andSizeY:5 normalize:YES];
	
	
	//http://www.cee.hw.ac.uk/hipr/html/sobel.html
	/*
	float xSobal[] = {-1, 0, 1, -2, 0, 2, -1, 0, 1};
	float ySobal[] = {1, 2, 1, 0, 0, 0, -1, -2, -1};
	
	unsigned char *xS = malloc(sizeof(unsigned char) * w * h);
	for ( y = 0; y < h; y++ )
		for ( x = 0; x < w; x++ )
			xS[y * w + x] = imgData[y * w + x];
	[self convolveImage:xS width:w height:h withConvolution:xSobal ofSizeX:3 andSizeY:3 normalize:YES];
	
	unsigned char *yS = malloc(sizeof(unsigned char) * w * h);
	for ( y = 0; y < h; y++ )
		for ( x = 0; x < w; x++ )
			yS[y * w + x] = imgData[y * w + x];
	[self convolveImage:yS width:w height:h withConvolution:ySobal ofSizeX:3 andSizeY:3 normalize:YES];
	
	for ( y = 0; y < h; y++ )
		for ( x = 0; x < w; x++ )
			imgData[y * w + x] = sqrt(pow(yS[y * w + x], 2) + pow(xS[y * w + x], 2));
	
	free(xS);
	free(yS);
	 */
}

@end
