//
//  effect.m
//  lab2
//
//  Created by Andrew Cantino on 2/16/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import "effect.h"


@implementation effect

- (id)initWithImage:(NSImage *)inImage {
	self = [super init];
	if (self) {
		[self setImage:inImage];
	}
	return self;
}

- (void)setImage:(NSImage *)inImage {
	[srcImage autorelease];
	srcImage = inImage;
	[srcImage retain];
}

- (void)dealloc {
	[srcImage autorelease];
}

- (NSImage *)apply {
	// Helpful code from http://www.macdevcenter.com/pub/a/mac/2002/08/06/cocoa.html?page=3
	NSBitmapImageRep *srcImageRep = [NSBitmapImageRep imageRepWithData:[srcImage TIFFRepresentation]];
	int w = [srcImageRep pixelsWide];
    int h = [srcImageRep pixelsHigh];
    NSImage *destImage = [[NSImage alloc] initWithSize:NSMakeSize(w,h)];
	
	int n = [srcImageRep bitsPerPixel] / 8; // Number of bits per pixel divided by 8 is the number of bytes, or unsigned characters.
	int x, y;
	if (n == 3) {
		
		NSBitmapImageRep *destImageRep = [[[NSBitmapImageRep alloc] 
					initWithBitmapDataPlanes:NULL
								  pixelsWide:w 
								  pixelsHigh:h 
							   bitsPerSample:8
							 samplesPerPixel:3
									hasAlpha:NO
									isPlanar:NO
							  colorSpaceName:NSCalibratedRGBColorSpace
								 bytesPerRow:NULL 
								bitsPerPixel:NULL] autorelease];
		
		unsigned char *srcData = [srcImageRep bitmapData];
		unsigned char *destData = [destImageRep bitmapData];
		unsigned char *p1, *p2;
		
		Pixel *img = malloc(sizeof(Pixel) * w * h);
	
		for ( y = 0; y < h; y++ ) {
			for ( x = 0; x < w; x++ ) {
				p1 = srcData + n * (y * w + x); // Do some pointer math.  p1 points to the red value of the src pixel. 
				img[y * w + x].r = *p1; // red
				img[y * w + x].g = *(p1 + 1); // green
				img[y * w + x].b = *(p1 + 2); // blue
			}
		}
		
		[self doApplyRGB:img width:w height:h];
		
		for ( y = 0; y < h; y++ ) {
			for ( x = 0; x < w; x++ ) {
				p2 = destData + n * (y * w + x); //p2 points to the red value of the dest pixel.
				*p2 = img[y * w + x].r; // red
				*(p2 + 1) = img[y * w + x].g; // green
				*(p2 + 2) = img[y * w + x].b; // blue
			}
		}
		
		free(img);
		[destImage addRepresentation:destImageRep];
	} else if([srcImageRep samplesPerPixel] == 1) {
		//NSLog(@"numberOfPlanes: %d", [srcImageRep numberOfPlanes]);
		//NSLog(@"isPlanar: %d", [srcImageRep isPlanar]);
		
		NSBitmapImageRep *destImageRep = [[[NSBitmapImageRep alloc] 
					initWithBitmapDataPlanes:NULL
								  pixelsWide:w 
								  pixelsHigh:h 
							   bitsPerSample:8
							 samplesPerPixel:1
									hasAlpha:NO
									isPlanar:NO
							  colorSpaceName:NSCalibratedWhiteColorSpace
								 bytesPerRow:NULL 
								bitsPerPixel:NULL] autorelease];
		
		unsigned char *srcData = [srcImageRep bitmapData];
		unsigned char *destData = [destImageRep bitmapData];
		unsigned char *p1, *p2;
		
		unsigned char *img = malloc(sizeof(unsigned char) * w * h);
		
		for ( y = 0; y < h; y++ ) {
			for ( x = 0; x < w; x++ ) {
				p1 = srcData + (y * w + x); // Do some pointer math.  p1 points to the red value of the src pixel. 
				img[y * w + x] = *p1;
			}
		}
		
		[self doApplyMono:img width:w height:h];
		
		for ( y = 0; y < h; y++ ) {
			for ( x = 0; x < w; x++ ) {
				p2 = destData + (y * w + x); //p2 points to the red value of the dest pixel.
				*p2 = img[y * w + x];
			}
		}
		
		free(img);
		[destImage addRepresentation:destImageRep];
	} else {
		NSBeep();
		NSWindow *infoWindow;
		infoWindow = NSGetCriticalAlertPanel( @"Error",
											  @"Image has incorrect bitsPerPixel",
											  @"OK", nil, nil );
		[ NSApp runModalForWindow:infoWindow ];
		[ infoWindow close ];
		return srcImage;
	}

    return destImage;
}

- (void)doApplyRGB:(Pixel *)imgData width:(int)w height:(int)h {

}

- (void)doApplyMono:(unsigned char *)imgData width:(int)w height:(int)h {
	
}

- (float *)convolveImage:(unsigned char *)imgData 
				width:(int)w 
			   height:(int)h
	  withConvolution:(float[])convolveImage 
			  ofSizeX:(int)Xsize
			 andSizeY:(int)Ysize
{
	// Perform a convolution with the given mask.  Size should be odd.
	int x, y;
	float *imgData2 = malloc(sizeof(float) * w * h);
	for ( y = 0; y < h; y++ ) {
		for ( x = 0; x < w; x++ ) {
			int i, j;
			float sum = 0;
			int cy = 0, cx = 0;
			for ( i = y - Ysize/2, cy = 0; i < y + Ysize/2 + 1; i++, cy++ ) {
				for ( j = x - Xsize/2, cx = 0; j < x + Xsize/2 + 1; j++, cx++ ) {
					if (i > -1 && i < h && j > -1 && j < w) {
						sum += imgData[i * w + j] * (float) convolveImage[cy * Xsize + cx];
					}
				}
			}
			imgData2[y * w + x] = sum;
		}
	}
	return(imgData2);
}
@end
