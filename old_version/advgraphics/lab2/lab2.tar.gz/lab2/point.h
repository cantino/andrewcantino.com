//
//  point.h
//  lab2
//
//  Created by Andrew Cantino on 2/17/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface point : NSObject {
	float x, y;
	float vx, vy;
	BOOL stationary;
}
- (void) setX:(float)inX;
- (void) setY:(float)inY;
- (float) x;
- (float) y;
- (id) initWithX:(float)inX andY:(float)inY;
- (void) setVX:(float)inVx andVY:(float)inVy;
- (void) vx:(float)inVx;
- (void) vy:(float)inVy;
- (float) vx;
- (float) vy;
- (void) setStationary:(BOOL)s;
- (BOOL) stationary;

@end
