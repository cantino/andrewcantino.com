//
//  point.m
//  lab2
//
//  Created by Andrew Cantino on 2/17/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import "point.h"

@implementation point

- (void) setX:(float)inX { x = inX; }
- (void) setY:(float)inY { y = inY; }
- (float) x { return x; }
- (float) y { return y; }
- (id) initWithX:(float)inX andY:(float)inY {
	self = [super init];
	if (self) {
		[self setX:inX];
		[self setY:inY];
	}
	return self;
}
- (void) setVX:(float)inVx andVY:(float)inVy { vx = inVx; vy = inVy; }
- (void) vx:(float)inVx { vx = inVx; }
- (void) vy:(float)inVy { vy = inVy; }
- (float) vx { return vx; }
- (float) vy { return vy; }
- (void) setStationary:(BOOL)s { stationary = s; }
- (BOOL) stationary { return stationary; }
@end
