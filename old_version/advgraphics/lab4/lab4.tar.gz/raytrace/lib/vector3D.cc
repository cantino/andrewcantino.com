#include "vector3D.h"
#include <math.h>

vector3D::vector3D() {}

vector3D::vector3D(double x, double y, double z)
{
  this->x = x; this->y = y; this->z = z;
}

//point vector3D::getPoint()
//{
//  return point(x, y);
//}

//point3D vector3D::getPoint3D()
//{
//  return point3D(x, y, z);
//}

double vector3D::magnitude()
{
  return sqrt(x*x + y*y + z*z);
}

void vector3D::normalize()
{
  double l = sqrt(x*x + y*y + z*z);
  x = x / l;
  y = y / l;
  z = z / l;
}

vector3D vector3D::normalized()
{
  double l = sqrt(x*x + y*y + z*z);
  return vector3D(x / l, y / l, z / l);
}

vector3D crossProduct(vector3D a, vector3D b)
{
  return vector3D(a.y*b.z - b.y*a.z,
	     a.z*b.x - b.z*a.x,
	     a.x*b.y - b.x*a.y);
}

double dotProduct(vector3D a, vector3D b)
{
  return a.x*b.x + a.y*b.y + a.z*b.z;
}

std::ostream& operator<< (std::ostream & out, const vector3D &p)
{
  out.precision(3);
  out << "(" << p.x << ", " << p.y << ", " << p.z << ")";
  return out;
}

vector3D operator- (const vector3D &x)
{
  return vector3D(-x.x, -x.y, -x.z);
}

vector3D operator+ (const vector3D &x, const vector3D &y)
{
  return vector3D(x.x + y.x, x.y + y.y, x.z + y.z);
}

vector3D operator- (const vector3D &x, const vector3D &y)
{
  return vector3D(x.x - y.x, x.y - y.y, x.z - y.z);
}

vector3D operator* (const double &d, const vector3D &x)
{
  return vector3D(d * x.x, d * x.y, d * x.z);
}

vector3D operator* (const vector3D &x, const double &d)
{
  return vector3D(d * x.x, d * x.y, d * x.z);
}

// ------------- colorVector -------------

colorVector::colorVector() : r(0), g(0), b(0) {}

colorVector::colorVector(double r, double g, double b)
{
  this->r = r < 1 ? r : 1;
  this->g = g < 1 ? g : 1;
  this->b = b < 1 ? b : 1;
}

colorVector operator+ (const colorVector &x, const colorVector &y)
{
  return colorVector(x.r + y.r > 1 ? 1 : x.r + y.r, x.g + y.g > 1 ? 1 : x.g + y.g, x.b + y.b > 1 ? 1 : x.b + y.b);
}

std::ostream& operator<< (std::ostream & out, const colorVector &c)
{
  out.precision(3);
  out << "(" << c.r << ", " << c.g << ", " << c.b << ")";
  return out;
}

colorVector operator* (const double &d, const colorVector &y)
{
  return colorVector(d * y.r > 1 ? 1 : d * y.r,
		     d * y.g > 1 ? 1 : d * y.g,
		     d * y.b > 1 ? 1 : d * y.b);
}
