#ifndef RAY_H
#define RAY_H

#include "matrix.h"
#include "vector3D.h"
#include "model.h"
#include <ostream.h>

class polygon3D;
class modelPrimative;

// Inspired/borrowed in parts from ray class in
// "Object-Oriented Ray Tracing in C++," by Nicholas Wilt, 1994

class ray {
 public:
  vector3D loc, dir;
  double iR;

  ray();
  ray(vector3D &loc, vector3D &dir);
  vector3D extend(double t);
  friend std::ostream& operator<< (std::ostream & out, const ray &r);

};

class intersect {
 public:
  vector3D loc, normal;
  double t, nS, kR, kT, kC;
  double iR;
  colorVector kD, kS, texColor;
  modelPrimative *object;
  
  intersect();
  friend std::ostream& operator<< (std::ostream & out, const intersect &i);
};

bool intersect_gt (const intersect &x, const intersect &y);

//bool shadowCast(point3D start, point3D light, list<polygonRef3D> & polygonList, polygonRef3D *pRef);

double intersectRayTriangle(ray &r, polygon3D &poly);

point3D vector3DtoPoint3D(vector3D v);

#endif

