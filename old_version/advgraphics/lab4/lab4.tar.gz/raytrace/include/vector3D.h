#ifndef VECTOR3D_H
#define VECTOR3D_H

class matrix;

#include <ostream.h>
/**
 * A 3D vector class
 */
class vector3D {
 public:
  double x, y, z;

  /**
   * Primative Constructor
   */
  vector3D();
  /**
   * Standard Constructor
   * @param x The x component of the vector
   * @param y The y component of the vector
   * @param z The z component of the vector
  */
  vector3D(double x, double y, double z);

  /**
   * Normalize the vector
   */
  void normalize();
  /**
   * Return a normalized vector
   */
  vector3D normalized();
  /**
   * Return the vector magnitude
   */
  double magnitude();

  /**
   * Take the cross product of two vectors
   */
  friend vector3D crossProduct(vector3D a, vector3D b);
  /**
   * Take the dot product of two vectors
   */
  friend double dotProduct(vector3D a, vector3D b);

  friend std::ostream& operator<< (std::ostream & out, const vector3D &v);
  /**
   * Negate a vector
   */
  friend vector3D operator- (const vector3D &x);
  /**
   * Add two vectors
   */
  friend vector3D operator+ (const vector3D &x, const vector3D &y);
  /**
   * Subtract two vectors
   */
  friend vector3D operator- (const vector3D &x, const vector3D &y);
  /**
   * Multiply a vector by a scalar
   * @param d The scaling factor
   * @param y The vector to scale
   */
  friend vector3D operator* (const double &d, const vector3D &y);
  friend vector3D operator* (const vector3D &y, const double &d);
  friend vector3D operator* (const matrix &x, const vector3D &y);
};

/**
 * A colorVector class
 * This class stores a red, green, and blue value for the color of something.  All the values range from 0 to 1.
 */
class colorVector {
 public:
  double r, g, b;
  
  /**
   * Primative Constructor
   */
  colorVector();
  /**
   * Constructor
   * @param r The red value for the color (in the range 0 to 1)
   * @param g The green value for the color (in the range 0 to 1)
   * @param b The blue value for the color (in the range 0 to 1)
   */
  colorVector(double r, double g, double b);

  /**
   * Add two colors.
   * This adds the two colors, limiting the result for each color to the range 0 to 1.
   */
  friend colorVector operator+ (const colorVector &x, const colorVector &y);
  friend std::ostream& operator<< (std::ostream & out, const colorVector &c);
  friend colorVector operator* (const double &d, const colorVector &y);
};

#endif
