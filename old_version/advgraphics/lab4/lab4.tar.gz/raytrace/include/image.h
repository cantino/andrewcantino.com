#ifndef IMAGE_H
#define IMAGE_H

#include "ppmIO.h"
#include "matrix.h"
#include "graphic.h"
#include "model.h"
#include <string>

class image {
 public:
  Pixel *data;
  unsigned char *alpha;
  double *zbuffer;
  unsigned char penAlpha;
  int rows, cols, colors;
  Pixel color;
  Pixel gradColor1, gradColor2;
  image *imPattern;
  int patternOriginX, patternOriginY, gradMode;
  bool doGrad, doPattern;
  double gradX, gradY, gradCr, gradCg, gradCb, magGrad, gradMaxLength, magGrad2;
  int gradStartX, gradStartY;

  image();
  image(string file);
  image(const image &copy);
  image& operator= (const image &rhs);
  image(int cols, int rows);
  image(int cols, int rows, Pixel c);
  ~image();

  int getRows();
  int getCols();
  Pixel getPenColor();
  void setPenColor(Pixel p);
  void setPenAlpha(unsigned char c);
  unsigned char getPenAlpha();
  void setGradColor(Pixel c1, Pixel c2);
  void setGradDirection(point d1, point d2);
  void setGradMode(int m);
  void clearGradient();
  void setPenPattern(const image &i);
  void setPatternOrigin(const point &p);
  void disablePattern();
  void enablePattern();
  void clearPattern();

  void readImage(string file);
  void writeImage(string file);
  void writeImage(string file, double scale);
  bool inImage(int x, int y);
  void drawPixel(int x, int y);
  void drawPixel(int x, int y, Pixel color, unsigned char alpha);
  void drawPixel(int x, int y, Pixel color);
  Pixel getPixel(int x, int y);
  image rotate(double rad);
  image scale(double factor);
  unsigned char getAlpha(int x, int y);
  void setAlpha(int x, int y, unsigned char a);

  void makeZBuffer(double init);
  double getZValue(int x, int y);
  void setZValue(int x, int y, double z);

  void medianFilterAlpha(); // Apply a median filter to the alpha layer.
  void medianFilter(); // Apply a median filter to the image.
  void shrinkAlpha(); // Apply a 4-connected shrink to alpha.

  void drawImage(int x, int y, image i); // Overlay image i at (x, y) using i's alpha layer.

  void drawGraphic(graphic &g);
  void drawFilledGraphic(graphic &g);
 
  void fill(point l, Pixel c); // c is the color of the boundary to fill to.
  void gradFill(point l, Pixel grad); // grad is a vector in color space to be used as a fill.

 private:
  double dist(double x1, double y1, double x2, double y2);
};

#endif





