#ifndef MODEL_H
#define MODEL_H

#include <list>
#include <vector>
#include <map>
#include <math.h>
#include "ray.h"
#include "matrix.h"
#include "image.h"
#include "graphic.h"
#include "vector3D.h"

/*
Class Hierarchy

	modelItem
		 model

		 modelPrimative
				point3D
	line3D
	polygon3D
	polyline3D
	polygonMesh
	box3D
	pyramid3D
	paramObject3D
	sphere (only avaliable in raytracer)

		 modelTransform
				 modelTranslate3D
	 modelScale3D
	 modelRotate3Dx
	 modelRotate3Dy
	 modelRotate3Dz
	 modelSheer3Dx
	 modelSheer3Dy
	 modelSheer3Dz
	 modelMatrixReset

		modelLight
				 pointLight
*/

// Prototype some classes
class polygonRef3D;
class modelLight;
class colorVector;
class intersect;
class ray;

/**
 * A virtual class for all models.
 * All our modeling objects (primative objects, lights, and transforms) inherit from this virtual class.
 */
class modelItem {
 public:
	/**
	 * Returns the type of the subclass.
	 * This function is used to return the type of the subclass.
	 * @return 
	 * 1 -> Model
	 * 2 -> Transform
	 * 3 -> Depricated
	 * 4 -> Light
	 */
	virtual int getName() = 0;
};

/**
 * Our model object.
 * Stores a list of modelItems, as well as a logicFunction.
 */
class model : public modelItem {
 private:
	std::list<modelItem*> data;
	void (*logicFunction)(model&, std::map<string, double>&, std::list<modelItem*>&);

	matrix drawList(matrix &GTM, image &im, std::list<modelItem*> &dataList);
	matrix renderList(matrix &GTM, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, std::list<modelItem*> &dataList, vector<modelLight> &lightList);

 public:
	/**
	 * The memory passed down to all the child models.
	 * This data is passed down by reference to each of the models that are contained within the model, allow the children to pass information back up to the parent by way of modifying this memory.
	 */
	std::vector< std::map<string, double> > childMemory;
 
	/**
	 * Primative Constructor.
	 * Constructs and empty model.
	 */
	model();
	/**
	 * Copy Constructor.
	 * Copies the model.
	 */
	model(const model &p);
	/**
	 * Destructor.
	 * Destroys all the elements in the list, however, it does not recursively delete models.
	 */
	virtual ~model();
	/**
	 * Primative Constructor.
	 * Constructs and empty model.
	 */
	model& operator= (const model &rhs);

	
	virtual int getName();
	/**
	 * Adds a modelItem.
	 * Adds the modelItem to the list
	 * @param i The model item to add
	 */
	void addItem(modelItem *i);
	/**
	 * Add a logic function.
	 * Adds a logic function to the model.	Once this is set, the function is called prior to the model being rendered.	 The logic function must take three arguments, the model calling it, a map which is its memory to modify as it needs, and a list of modelItems that it can add models to.
	 */
	void addLogic(void (*logicFunction)(model&, std::map<string, double>&, std::list<modelItem*>&));
	
	void draw(matrix &GTM, image &im);
	void draw(matrix &GTM, image &im, std::map<string, double> &memory);

	/**
	 * Renders the model.
	 * This steps through the list of modelItems, applying the transforms to the VTM, and recursively calling render on the models, modelPrimatives, lights.
	 * @param m The incoming GTM
	 * @param pointList The global list of points that will contain all points in the scene once everything has rendered.
	 * @param polygonList The global list of polygons that will contain all polygons in the scene once everything has rendered.
	 * @param memory The incoming memory from the parent model.	 For use by the logicFunction.
	 * @param lightList The global list of lights that will contain all lights in the scene once everything has rendered.
	 */
	void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, std::map<string, double> &memory, vector<modelLight> &lightList);
 /**
	 * Renders the model.
	 * This steps through the list of modelItems, applying the transforms to the VTM, and recursively calling render on the models, modelPrimatives, lights.
	 * @param m The incoming GTM
	 * @param pointList The global list of points that will contain all points in the scene once everything has rendered.
	 * @param polygonList The global list of polygons that will contain all polygons in the scene once everything has rendered.
	 * @param lightList The global list of lights that will contain all lights in the scene once everything has rendered.
	 */
	void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList);

	void doIntersect(ray &r, std::list<intersect> &intersects);
	void xformWorld(matrix &GTM, vector<modelLight> &lightList);
};

/**
 * A virtual class for all our model primatives.
 * All the primatives (e.g. a polygon, a pyramid, etc.) that we define inherit from this superclass.
 */
class modelPrimative : public modelItem {
 public:
 	list<ray> photonMap;
	virtual int getName();
	virtual void draw(matrix &m, image &i) = 0;
	/**
	 * Renders the primative.
	 * This applies the incoming GTM to all the points in the model and returns the points and polygons forming the model.
	 * @param m The incoming GTM
	 * @param pointList The global list of points that will contain all points in the scene once everything has rendered.
	 * @param polygonList The global list of polygons that will contain all polygons in the scene once everything has rendered.
	 * @param lightList The global list of lights that will contain all lights in the scene once everything has rendered.
	 */
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList) = 0;
	virtual void doIntersect(ray &r, std::list<intersect> &intersects) = 0;
	virtual void xformWorld(matrix &GTM) = 0;
};

/**
 *	A 3D point object.
 *	A 3D point that stored a homogenious represenation of itself.	 It is also capable of performing various simple operations on itself.
 */
class point3D {
 public:
	/**
	 * Primative Constructor.
	 * Primative Constructor.
	 */
	point3D();
	/**
	 * Standard Constructor.
	 * Constructor taking three doubles for x, y, z.
	 */
	point3D(double x, double y, double z);
	/**
	 * Constructor.
	 * Constructor taking three doubles for x, y, z and a value for the homogenious coordinate.
	 */
	point3D(double x, double y, double z, double h);
	/**
	 * Constructor.
	 * Constructor taking three doubles for x, y, z and a color.
	 */
	point3D(double x, double y, double z, Pixel color);
	/**
	 * Constructor.
	 * Constructor taking three doubles for x, y, z, a value for the homogenious coordinate, and a color.
	 */
	point3D(double x, double y, double z, double h, Pixel color);
	
	// Accessors
	/**
	 * The x value of the point.
	 * Returns the x value of the point scaled by the homoegenous coordinate.
	 */
	double x() const;
	/**
	 * The y value of the point.
	 * Returns the y value of the point scaled by the homoegenous coordinate.
	 */
	double y() const;
	/**
	 * The z value of the point.
	 * Returns the z value of the point scaled by the homoegenous coordinate.
	 */
	double z() const;
	/**
	 * The x value of the point in world space.
	 * Returns the x value of the point in world space.
	 */
	double worldX() const;
	/**
	 * The y value of the point in world space.
	 * Returns the y value of the point in world space.
	 */
	double worldY() const;
	/**
	 * The z value of the point in world space.
	 * Returns the z value of the point in world space.
	 */
	double worldZ() const;
	/**
	 * The z value of the point.
	 * Returns the z value of the point NOT scaled by the homoegenous coordinate.
	 */
	double depth() const;
	/**
	 * The z value of the point.
	 * Returns the z value of the point NOT scaled by the homoegenous coordinate.
	 */
	point getPoint();
	/**
	 * Get a 2D version of the point.
	 * Returns the x and y coordinate, dropping the z value.
	 */
	Pixel getColor();
	/**
	 * Set the world x, y, and z.
	 * Archives the current x, y, and z values in the world corrdinates.	These can be later accessed with the worldX(), worldY(), and worldZ() operators.
	 */
	void archive();

	/**
	 * Set the pixel color.
	 * Set the color of the pixel.
	 */
	void setColor(Pixel c);
	void normalize();
	point3D normalized();
	double magnitude();

	friend point3D crossProduct(point3D a, point3D b);
	friend double dotProduct(point3D a, point3D b);

	/**
	 * Premultiply the point by a matrix.
	 * Premultiplies the point by a matrix, storing the result back in itself.
	 */
	void operator*= (const matrix &rhs);

	friend std::ostream& operator<< (std::ostream & out, const point3D &p);
 
	/**
	 * Add two points.
	 * Add the two points, returning their result.
	 */
	friend point3D operator+ (const point3D &x, const point3D &y);
	/**
	 * Subtract two points.
	 * Subtract the two points, returning their result.
	 */
	friend point3D operator- (const point3D &x, const point3D &y);
	friend point3D operator* (const double &d, const point3D &y);
	/**
	 * Premultiply the point by a matrix.
	 * Premultiply the point by a matrix, returning the result.
	 */
	friend point3D operator* (const matrix &x, const point3D &y);

	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);

	/**
	 * The normal at that point.
	 */
	vector3D normal;

	double data[4];

 private:
	double worldData[3];
	Pixel color;
};

class line3D : public modelPrimative {
 public:
	point3D start, end;
	line3D();
	line3D(point3D s, point3D e);

	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
};

/**
 * A 3D polygon.
 * Polygons may contain more that three points, however, it is not recommened as our graphics system does not guarantee stable results on anything by triangles.
 */
class polygon3D : public modelPrimative {
 public:
	point3D *points;
	int pointCount, n;
	bool filled, flat, shadowed;
	colorVector kD, kS;
	double nS, kR, kT, iR, kC;
	int tex;
	
	/**
	 * Primative Constructor.
	 * Constructs an empty polygon that cannot accept any points.
	 */
	polygon3D();
	/**
	 * Primative Constructor.
	 * Constructs an empty polygon that can contain up to n points.
	 * @param n The maximum number of points the polygon will contain. 
	 */
	polygon3D(int n);
	/**
	 * Copy Constructor.
	 */
	polygon3D(const polygon3D &p);
	virtual ~polygon3D();

	polygon3D& operator= (const polygon3D &rhs);
	
	/**
	 * Sets whether the polygon will be filled or not.
	 * WARNING: Results unpredictable in 3D with unfilled polygons.
	 */
	void setFilled(bool m);
	/**
	 * Sets whether the polygon will be shaded as if it is flat or not.
	 * WARNING: Results unpredictable in 3D with non-flat polygons.
	 */
	void setFlat(bool m);
	/**
	 * Sets whether material properties for the polygon.
	 * @param kD The coeffient of diffuse reflectence.
	 * @param kS The coeffient of specular reflection.
	 * @param nS The speculer coefficient.
	 */
	void setMaterial(colorVector kD, colorVector kS, double nS, double kR, double kT, double iR, double kC);

	/**
	 * Adds a point to the polygon
	 * @param p The point to be added.
	 */
	void addPoint(point3D p);

	virtual void draw(matrix &m, image &im);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	void setTex(int t);
	virtual void xformWorld(matrix &GTM);
};

class polyline3D : public modelPrimative {
 public:
	point3D *points;
	int pointCount, n;
	polyline3D();
	polyline3D(int n);

	polyline3D(const polyline3D &p);
	polyline3D& operator= (const polyline3D &rhs);
	virtual ~polyline3D();
	void addPoint(point3D p);
	virtual void draw(matrix &m, image &im);
};

/**
 * A polygon mesh
 */
class polygonMesh : public modelPrimative {
 public:
	vector<point3D*> * pntList;
	list<polygonRef3D> * polyList;
 
	/**
	 * Primative Constructor.
	 * Constructs an empty polygon mesh.
	 */
	polygonMesh();
	/**
	 * Constructor.
	 * Constructs an polygon mesh from a list of points and a list of polygons.
	 * @param pointList The list of points used in the mesh
	 * @param polygonList The list of polygons used in the mesh
	 */
	polygonMesh(vector<point3D*> * pointList, list<polygonRef3D> * polygonList);
	void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM);
	virtual void draw(matrix &m, image &im);
};

/**
 * A 3D box object
 */
class box3D : public modelPrimative {
 public:
	double lx, ly, lz;
	colorVector kD, kS;
	double nS;
	bool flat;
	
	/**
	 * Primative Constructor.
	 * Constructs a unit box at the origin.
	 */
	box3D();
	/**
	 * Constructor.
	 * @param lx The length of the side in the x direction.
	 * @param ly The length of the side in the y direction.
	 * @param lz The length of the side in the z direction.
	 */
	box3D(double lx, double ly, double lz);

	/**
	 * Sets whether material properties for the polygon.
	 * @param kD The coeffient of diffuse reflectence.
	 * @param kS The coeffient of specular reflection.
	 * @param nS The speculer coefficient.
	 */
	void setMaterial(colorVector kD, colorVector kS, double nS);
	/**
	 * Sets whether the polygon will be shaded as if it is flat or not.
	 * WARNING: Results unpredictable in 3D with non-flat polygons.
	 */
	void setFlat(bool b);

	virtual ~box3D();
	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM);
};

/**
 * A 3D pyramid object
 */
class pyramid3D : public modelPrimative {
 public:
	point3D top;
	polygon3D base;
	colorVector kD, kS;
	double nS;
	bool flat;

	/**
	 * Primative Constructor.
	 * Constructs a unit box at the origin.
	 */
	pyramid3D();
	/**
	 * Constructor.
	 * @param top The point of the pyramid
	 * @param base The polygon forming the base of the pyramid
	 */
	pyramid3D(point3D top, polygon3D base);

	/**
	 * Sets whether material properties for the polygon.
	 * @param kD The coeffient of diffuse reflectence.
	 * @param kS The coeffient of specular reflection.
	 * @param nS The speculer coefficient.
	 */
	void setMaterial(colorVector kD, colorVector kS, double nS);
	/**
	 * Sets whether the polygon will be shaded as if it is flat or not.
	 * WARNING: Results unpredictable in 3D with non-flat polygons.
	 */
	void setFlat(bool b);

	virtual ~pyramid3D();
	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM);
};

/**
 * A 3D paramterized object.
 * An object that takes a parameterized functrion for a 3D object and polygonalizes it and renders it to the screen.
 */
class paramObject3D : public modelPrimative {
 public:
	double dU, dV;
	point3D* (*f)(double, double);
	colorVector kD, kS;
	double nS;
	bool flat;

	/**
	 * Primative Constructor.
	 * Dear lord Bruce, please don't use this.
	 */
	paramObject3D();
	/**
	 * Constructor.
	 * @param f The parameterized function that takes two values u and v and returns a point3D
	 * @param dU The step size in u (u ranges from 0 to 1)
	 * @param dV The step size in v (v ranges from 0 to 1)
	 */
	paramObject3D(point3D* (*f)(double, double), double dU, double dV);
	virtual ~paramObject3D();

 /**
	 * Sets whether material properties for the polygon.
	 * @param kD The coeffient of diffuse reflectence.
	 * @param kS The coeffient of specular reflection.
	 * @param nS The speculer coefficient.
	 */
	void setMaterial(colorVector kD, colorVector kS, double nS);
	/**
	 * Sets whether the polygon will be shaded as if it is flat or not.
	 * WARNING: Results unpredictable in 3D with non-flat polygons.
	 */
	void setFlat(bool b);

	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM);
};


/**
 * A 3D sphere object.
 */
class sphere : public modelPrimative {
 public:
		vector3D loc;
		double r;
		colorVector kD, kS;
		double nS, kR, kT, iR, kC;
		int tex;
		
		sphere();
 
		sphere(vector3D loc, double r);

	/**
	 * Sets whether material properties for the polygon.
	 * @param kD The coeffient of diffuse reflectence.
	 * @param kS The coeffient of specular reflection.
	 * @param nS The speculer coefficient.
	 */
	void setMaterial(colorVector kD, colorVector kS, double nS, double kR, double kT, double iR, double kC);
	void setTex(int t);
	void setFlat(bool b);
	virtual void draw(matrix &m, image &i);
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM);
};


/**
 * A virtual class for all our model transforms.
 * All the transforms (e.g. scale, rotate, etc.) that we define inherit from this superclass.
 */
class modelTransform : public modelItem {
 public:
	virtual int getName();
	/**
	 * Apply the transform to a matrix
	 * @param m The matrix to apply the transform to
	 */
	virtual void apply(matrix &m) = 0;
};

/**
 * 3D Translate
 */
class modelTranslate3D : public modelTransform {
	double tx, ty, tz;
	
 public:
	/**
	 * Constructor
	 * @param tx Translation in x
	 * @param ty Translation in y
	 * @param tz Translation in z
	 */
	modelTranslate3D(double tx, double ty, double tz);

	virtual void apply(matrix &m);
};
/**
 * 3D Scale
 */
class modelScale3D : public modelTransform {
	double sx, sy, sz;
	point3D center;
	int mode;

 public:

	/**
	 * Constructor
	 * @param s The scale factor for all directions
	 */
	modelScale3D(double s);
	/**
	 * Constructor
	 * @param sx The scale factor in the x direction
	 * @param sy The scale factor in the y direction
	 * @param sz The scale factor in the z direction
	 */
	modelScale3D(double sx, double sy, double sz);
	/**
	 * Constructor
	 * @param s The scale factor for all directions
	 * @param center The point to perform the scale around
	 */
	modelScale3D(point3D center, double s);
	/**
	 * Constructor
	 * @param center The point to perform the scale around 
	 * @param sx The scale factor in the x direction
	 * @param sy The scale factor in the y direction
	 * @param sz The scale factor in the z direction
	 */	 
	modelScale3D(point3D center, double sx, double sy, double sz);

	virtual void apply(matrix &m);
};
/**
 * Rotate about the x axis
 */
class modelRotate3Dx : public modelTransform {
	point3D center;
	double theta;
	int mode;

 public:
	/**
	 * Constructor
	 * @param theta The angle to rotate around the x axis
	 */
	modelRotate3Dx(double theta);
	/**
	 * Constructor
	 * @param center The point to do the rotation around
	 * @param theta The angle to rotate around the x axis
	 */
	modelRotate3Dx(point3D center, double theta);

	virtual void apply(matrix &m);
};
/**
 * Rotate about the y axis
 */
class modelRotate3Dy : public modelTransform {
	point3D center;
	double theta;
	int mode;

 public:
	/**
	 * Constructor
	 * @param theta The angle to rotate around the y axis
	 */
	modelRotate3Dy(double theta);
	/**
	 * Constructor
	 * @param center The point to do the rotation around
	 * @param theta The angle to rotate around the y axis
	 */
	modelRotate3Dy(point3D center, double theta);

	virtual void apply(matrix &m);
};
/**
 * Rotate about the z axis
 */
class modelRotate3Dz : public modelTransform {
	point3D center;
	double theta;
	int mode;

 public:
	/**
	 * Constructor
	 * @param theta The angle to rotate around the z axis
	 */
	modelRotate3Dz(double theta);
	/**
	 * Constructor
	 * @param center The point to do the rotation around
	 * @param theta The angle to rotate around the z axis
	 */
	modelRotate3Dz(point3D center, double theta);

	virtual void apply(matrix &m);
};
/**
	 * Align two sets of axes
	 * @param newX A vector pointing in the direction of the new x axis.
	 * @param newY A vector pointing in the direction of the new y axis.
	 * @param newZ A vector pointing in the direction of the new z axis.
	 */
class modelAlignAxes3D : public modelTransform {
	point3D newX, newY, newZ;

 public:
/**
	 * Constructor
	 * @param newX A vector pointing in the direction of the new x axis.
	 * @param newY A vector pointing in the direction of the new y axis.
	 * @param newZ A vector pointing in the direction of the new z axis.
	 */
	modelAlignAxes3D(point3D newX, point3D newY, point3D newZ);
 
	virtual void apply(matrix &m);
};
/**
 * Sheer the matrix in x
 */
class modelSheer3Dx : public modelTransform {
	double shy, shz;
	
 public:
	/**
	 * Constructor
	 * @param shy The sheer factor in y
	 * @param shz The sheer factor in z
	 */
	modelSheer3Dx(double shx, double shy);

	virtual void apply(matrix &m);
};
/**
 * Sheer the matrix in y
 */
class modelSheer3Dy : public modelTransform {
	double shx, shz;
	
 public:
	/**
	 * Constructor
	 * @param shx The sheer factor in x
	 * @param shz The sheer factor in z
	 */
	modelSheer3Dy(double shx, double shz);

	virtual void apply(matrix &m);
};
/**
 * Sheer the matrix in z
 */
class modelSheer3Dz : public modelTransform {
	double shx, shy;
	
 public:
	/**
	 * Constructor
	 * @param shx The sheer factor in x
	 * @param shy The sheer factor in y
	 */
	modelSheer3Dz(double shx, double shy);

	virtual void apply(matrix &m);
};
/**
 * Reset the LTM
 */
class modelMatrixReset : public modelTransform {
 public:
	/**
	 * Constructor
	 */
	modelMatrixReset();

	virtual void apply(matrix &m);
};

/**
 * A light object
 * A superclass for all of the types of lights in our scenes
 */
class modelLight : public modelItem {
 public:
	point3D loc;
	colorVector I;
	vector3D D;
	double cos_a;
	int type;

	/**
	 * Primative Constructor.
	 */
	modelLight();

	/**
	 * Returns the location of the light.
	 * @param P A 3D point representing the point the light is illuminating
	 * @return A vector pointing from the point, P, to this light
	 */
	virtual vector3D getL(point3D P);
	/**
	 * Returns the intensity of the light
	 * @param L A vector pointing from the point being illuminated to this light
	 * @return A colorVector representing the intensity of the light illuminating the point
	 */
	virtual colorVector getI(vector3D L);
	
	virtual int getName();
	/**
	 * Renders the model.
	 * This steps through the list of modelItems, applying the transforms to the VTM, and recursively calling render on the models, modelPrimatives, lights.
	 * @param m The incoming GTM
	 * @param pointList The global list of points that will contain all points in the scene once everything has rendered.
	 * @param polygonList The global list of polygons that will contain all polygons in the scene once everything has rendered.
	 * @param lightList The global list of lights that will contain all lights in the scene once everything has rendered.
	 */
	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM, vector<modelLight> &lightList);
};
/**
 * A point light source
 * Illuminates equally in all directions
 */
class pointLight : public modelLight {
 public:
	/**
	 * Primative Constructor.
	 */
	pointLight();
	/**
	 * Constructor.
	 * @param I The intensity of the light emmitted by this light source
	 */
	pointLight(colorVector I);

	virtual vector3D getL(point3D P);
	virtual colorVector getI(vector3D L);

	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList);
	virtual void doIntersect(ray &r, std::list<intersect> &intersects);
	virtual void xformWorld(matrix &GTM, vector<modelLight> &lightList);
};
/**
 * A spot light
 * Illuminates a dicrete cone in the world
 */
class spotLight : public modelLight {
 public:
	/**
	 * Primative Constructor.
	 */
	spotLight();
	/**
	 * Constructor.
	 * @param I The intensity of the light emmitted by this light source
	 * @param d The direction this light source is facing
	 * @param a The angle from d that this light source illuminates (in radians)
	 */
	spotLight(colorVector I, vector3D d, double a);

	virtual vector3D getL(point3D P);
	virtual colorVector getI(vector3D L);

	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList);
};
/**
 * Sunlight
 * Illuminates from a specific direction with all incoming rays being parallel
 */
class sunLight : public modelLight {
 public:
	 /**
	 * Primative Constructor.
	 */
	sunLight();
	/**
	 * Constructor.
	 * @param I The intensity of the light emmitted by this light source
	 * @param d The direction the sunlight is coming from
	 */
	sunLight(colorVector I, vector3D d);

	virtual vector3D getL(point3D P);
	virtual colorVector getI(vector3D L);

	virtual void render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList);
};
#endif


