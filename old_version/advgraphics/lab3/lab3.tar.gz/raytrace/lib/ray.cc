#include "ray.h"
#include <math.h>

// Inspired/borrowed in parts from ray class in
// "Object-Oriented Ray Tracing in C++," by Nicholas Wilt, 1994

ray::ray()
{
	loc = vector3D(0, 0, 0);
	dir = vector3D(0, 0, 0);
}

ray::ray(vector3D &loc, vector3D &dir)
{
	this->loc = loc;
	this->dir = dir.normalized();
}

vector3D ray::extend(double t)
{
	return loc + dir * t;
}

intersect::intersect() {}

// Comparison function to compare two intersects.
bool intersect_gt (const intersect &x, const intersect &y)
{
	return x.t > y.t;
}

double intersectRayTriangle(ray &r, polygon3D &poly) {
	double xa = poly.points[0].x();
	double ya = poly.points[0].y();
	double za = poly.points[0].z();
	double xb = poly.points[1].x();
	double yb = poly.points[1].y();
	double zb = poly.points[1].z();
	double xc = poly.points[2].x();
	double yc = poly.points[2].y();
	double zc = poly.points[2].z();
	double xd = r.dir.x;
	double yd = r.dir.y;
	double zd = r.dir.z;
	double xe = r.loc.x;
	double ye = r.loc.y;
	double ze = r.loc.z;
	
	double a = xa - xb;
	double b = ya - yb;
	double c = za - zb;
	double d = xa - xc;
	double e = ya - yc;
	double f = za - zc;
	double g = xd;
	double h = yd;
	double i = zd;
	double j = xa - xe;
	double k = ya - ye;
	double l = za - ze;
	
	double eiMinushf = e*i - h*f;
	double gfMinusdi = g*f - d*i;
	double dhMinuseg = d*h - e*g;
	double akMinusjb = a*k - j*b;
	double jcMinusal = j*c - a*l;
	double blMinuskc = b*l - k*c;
	
	double M = a*eiMinushf + b*gfMinusdi + c*dhMinuseg;
	double t = -(f*akMinusjb + e*jcMinusal + d*blMinuskc)/M;
	double B = (j*eiMinushf + k*gfMinusdi + l*dhMinuseg)/M;
	double G = (i*akMinusjb + h*jcMinusal + g*blMinuskc)/M;
	
	//if (t < .001 || t > .999)
	//	continue;
	if (G < .001 || G > .999)
		return -1;
	if (B < .001 || B > .999 - G)
		return -1;

	return t;
}

point3D vector3DtoPoint3D(vector3D v) {
		return point3D(v.x, v.y, v.z);
}

std::ostream& operator<< (std::ostream & out, const intersect &i)
{
	out.precision(3);
	out << "loc: " << i.loc << "	normal: " << i.normal << "	t: " << i.t << "	nS: " << i.nS;
	out << "	kD: " << i.kD << "	kS: " << i.kS;
	return out;
}

std::ostream& operator<< (std::ostream & out, const ray &r)
{
	out.precision(3);
	out << "loc: " << r.loc << "	dir: " << r.dir;
	return out;
}


/*
bool shadowCast(vector3D start, vector3D light, list<polygonRef3D> & polygonList, polygonRef3D *pRef)
{
	for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
		if ((iter->pointCount > 2) && (&(*iter) != pRef)) {
			point3D v = light - start;
			//double t1 = v.magnitude();
			//v.normalize();
			
			double xa = iter->points[0]->worldX();
			double ya = iter->points[0]->worldY();
			double za = iter->points[0]->worldZ();
			double xb = iter->points[1]->worldX();
			double yb = iter->points[1]->worldY();
			double zb = iter->points[1]->worldZ();
			double xc = iter->points[2]->worldX();
			double yc = iter->points[2]->worldY();
			double zc = iter->points[2]->worldZ();
			double xd = v.x();
			double yd = v.y();
			double zd = v.z();
			double xe = start.x();
			double ye = start.y();
			double ze = start.z();
			
			double a = xa - xb;
			double b = ya - yb;
			double c = za - zb;
			double d = xa - xc;
			double e = ya - yc;
			double f = za - zc;
			double g = xd;
			double h = yd;
			double i = zd;
			double j = xa - xe;
			double k = ya - ye;
			double l = za - ze;
			
			double eiMinushf = e*i - h*f;
			double gfMinusdi = g*f - d*i;
			double dhMinuseg = d*h - e*g;
			double akMinusjb = a*k - j*b;
			double jcMinusal = j*c - a*l;
			double blMinuskc = b*l - k*c;
			
			double M = a*eiMinushf + b*gfMinusdi + c*dhMinuseg;
			double t = -(f*akMinusjb + e*jcMinusal + d*blMinuskc)/M;
			double B = (j*eiMinushf + k*gfMinusdi + l*dhMinuseg)/M;
			double G = (i*akMinusjb + h*jcMinusal + g*blMinuskc)/M;
			
			if (t < .001 || t > .999)
	continue;
			if (G < .001 || G > .999)
	continue;
			if (B < .001 || B > .999 - G)
	continue;
			//cout << "Intersects with polygon " << *iter << endl;
			return true;
		}
	}
	//cout << "No intersection found with any polygon." << endl;
	return false;
}
*/
