#include "modelio.h"

model * loadASEModel(const char * filename)
{
  int debug = 0;
  model *m = new model();
  ifstream file(filename);
  if (! file.is_open()) {
    cerr << "Error, unable to open " << filename << "!" << endl;
  } else {
    int doingGeoObject = 0;
    std::vector<point3D*> * pointList;
    std::list<polygonRef3D> * polygonList;
    polygonMesh * mesh;
    int vertCount = 0, faceCount = 0;
    while (! file.eof() )
      {
	string search;
	file >> search;
	if (search == "*GEOMOBJECT") {
	  if (debug)
	    cout << "Found a GEOMOBJECT!" << endl;
	  if (doingGeoObject == 0) {
	    vertCount = 0;  faceCount = 0;
	    pointList = new std::vector<point3D*>();
	    polygonList = new std::list<polygonRef3D>();
	    mesh = new polygonMesh(pointList, polygonList);
	    doingGeoObject = 1;
	  } else {
	    m->addItem(mesh);
	    vertCount = 0;  faceCount = 0;
	    pointList = new std::vector<point3D*>();
	    polygonList = new std::list<polygonRef3D>();
	    mesh = new polygonMesh(pointList, polygonList);
	  }
	} else if (search == "*MESH_NUMVERTEX") {
	  file >> vertCount;
	  if (debug)
	    cout << "Got a vertCount of " << vertCount << "." << endl;
	} else if (search == "*MESH_NUMFACES") {
	  file >> faceCount;
	  if (debug)
	    cout << "Got a faceCount of " << faceCount << "." << endl;
	} else if (search == "*MESH_VERTEX") {
	  int num;
	  double v1, v2, v3;
	  file >> num >> v1 >> v2 >> v3;
	  if (debug)
	    cout << "Got vertex (" << v1 << ", " << v2 << ", " << v3 << ")." << endl;
	  pointList->push_back(new point3D(v1, v2, v3));
	} else if (search == "*MESH_FACE") {
	  string t;
	  int i1 = 0, i2 = 0, i3 = 0;
	  file >> t >> t >> i1 >> t >> i2 >> t >> i3;
	  if (debug)
	    cout << "Got triangle " << i1 << "-->" << i2 << "-->" << i3 << "." << endl;
	  polygonRef3D pRef = polygonRef3D(3);
	  pRef.addPoint((*pointList)[i1]);
	  pRef.addPoint((*pointList)[i2]);
	  pRef.addPoint((*pointList)[i3]);
	  pRef.kD = colorVector(.7, .7, .7);
	  pRef.kS = colorVector(.8, .8, .8);
	  pRef.nS = 32;
	  pRef.setFlat(true);
	  polygonList->push_back(pRef);
	}
      }
    if (debug)
      cout << "End of File" << endl;
    if (doingGeoObject == 1)
      m->addItem(mesh);
    file.close();
  }
  return m;
}
