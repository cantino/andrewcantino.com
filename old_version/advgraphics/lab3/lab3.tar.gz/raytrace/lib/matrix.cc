#include "matrix.h"
#include <math.h>

// [rows][cols]
#include "model.h"

matrix::matrix()
{
}

matrix::matrix(const matrix &copy)
{
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      data[i][j] = copy.data[i][j];
}

matrix::matrix(const double copy[][4])
{
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      data[i][j] = copy[i][j];
    }
  }
}

matrix::matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33)
{
  data[0][0] = m00; data[0][1] = m01; data[0][2] = m02; data[0][3] = m03;
  data[1][0] = m10; data[1][1] = m11; data[1][2] = m12; data[1][3] = m13;
  data[2][0] = m20; data[2][1] = m21; data[2][2] = m22; data[2][3] = m23;
  data[3][0] = m30; data[3][1] = m31; data[3][2] = m32; data[3][3] = m33;
}

void matrix::translate3D(double tx, double ty, double tz)
{
  // 1 0 0 tx
  // 0 1 0 ty
  // 0 0 1 tz
  // 0 0 0 1
  // We know that this could be simplified algebraically for speed and
  // memory optimization, but this is easier to think about.  If we end up
  // needing the speed, or turn this into a game engine or something, then
  // this optimization is in order.  The same goes for the following transformations.
  matrix t = matrix(1, 0, 0, tx, 0, 1, 0, ty, 0, 0, 1, tz, 0, 0, 0, 1);
  *this *= t;
}

void matrix::scale3D(double s)
{
  scale3D(s, s, s);
}

void matrix::scale3D(double sx, double sy, double sz)
{
  matrix s = matrix(sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1);
  *this *= s;
}

void matrix::scale3D(point3D center, double s)
{
  scale3D(center, s, s, s);
}

void matrix::scale3D(point3D center, double sx, double sy, double sz)
{
  translate3D(-center.x(), -center.y(), -center.z());
  scale3D(sx, sy, sz);
  translate3D(center.x(), center.y(), center.z());
}

void matrix::scale3D(point3D center, point3D direction, double sx, double sy, double sz)
{
  cerr << "General Scale3D not yet implemented" << endl;
  translate3D(-center.x(), -center.y(), -center.z());
  //rotate3Dz(-theta);
  scale3D(sx, sy, sz);
  //rotate3Dz(theta);
  translate3D(center.x(), center.y(), center.z());
}

void matrix::sheer3Dx(double shy, double shz)
{
  matrix sh = matrix(1  , 0, 0, 0,
		     shy, 1, 0, 0, 
		     shz, 0, 1, 0, 
		     0  , 0, 0, 1);
  *this *= sh;
}

void matrix::sheer3Dy(double shx, double shz)
{
  matrix sh = matrix(1, shx, 0, 0,
		     0, 1  , 0, 0, 
		     0, shz, 1, 0, 
		     0, 0  , 0, 1);
  *this *= sh;
}

void matrix::sheer3Dz(double shx, double shy)
{
  matrix sh = matrix(1, 0, shx, 0,
		     0, 1, shy, 0, 
		     0, 0, 1  , 0, 
		     0, 0, 0  , 1);
  *this *= sh;
}

void matrix::rotate3Dx(double theta)
{
  matrix r = matrix(1, 0, 0, 0, 0, cos(theta), -sin(theta), 0, 0, sin(theta), cos(theta), 0, 0, 0, 0, 1);
  *this *= r;
}

void matrix::rotate3Dx(point3D center, double theta)
{
  translate3D(-center.x(), -center.y(), 0);
  rotate3Dx(theta);
  translate3D(center.x(), center.y(), 0);
}

void matrix::rotate3Dy(double theta)
{
  matrix r = matrix(cos(theta), 0, sin(theta), 0,
		    0, 1, 0, 0,
		    -sin(theta), 0, cos(theta), 0,
		    0, 0, 0, 1);
  *this *= r;
}

void matrix::rotate3Dy(point3D center, double theta)
{
  translate3D(-center.x(), -center.y(), 0);
  rotate3Dy(theta);
  translate3D(center.x(), center.y(), 0);
}

void matrix::rotate3Dz(double theta)
{
  matrix r = matrix(cos(theta), -sin(theta), 0, 0, sin(theta), cos(theta), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  *this *= r;
}

void matrix::rotate3Dz(point3D center, double theta)
{
  translate3D(-center.x(), -center.y(), 0);
  rotate3Dz(theta);
  translate3D(center.x(), center.y(), 0);
}

void matrix::alignAxes3D(point3D newX, point3D newY, point3D newZ)
{
  newX.normalize();
  newY.normalize();
  newZ.normalize();

  matrix a = matrix(newX.x(), newX.y(), newX.z(), 0,
		    newY.x(), newY.y(), newY.z(), 0,
		    newZ.x(), newZ.y(), newZ.z(), 0,
		    0,            0,            0,            1);

  *this *= a;
}

void matrix::PerspProject(double d)
{
  matrix a = matrix(1, 0,  0,  0,
		    0, 1,  0,  0,
		    0, 0,  1,  0,
		    0, 0, 1/d, 0);
  *this *= a;
}

void matrix::ParallelProject()
{
  matrix a = matrix(1, 0, 0, 0,
		    0, 1, 0, 0,
		    0, 0, 0, 0,
		    0, 0, 0, 1);
  *this *= a;
}

matrix operator* (const matrix &x, const matrix &y)
{
  matrix m = matrix();
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      {
	m.data[i][j] = 0;
	for (int k = 0; k < 4; k++) {
	  m.data[i][j] += x.data[i][k] * y.data[k][j];
	}
      }
  return m;
}

void matrix::operator*= (const matrix &rhs)
{
  matrix m = *this;
  *this = rhs*m;
}

matrix operator+ (const matrix &x, const matrix &y)
{
  matrix m = matrix();
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      m.data[i][j] = x.data[i][j] + y.data[i][j];
    }
  }
  return m;
}

ostream& operator<< (ostream & out, const matrix &p)
{
  
  for (int i = 0; i < 4; i++)
    {
      out << "[";
      for (int j = 0; j < 4; j++)
	out << p.data[i][j] << "\t";
      out << "]\n";
    }
  return out;
}

point3D operator* (const matrix &x, const point3D &y)
{
  point3D p = point3D();
  for (int i = 0; i < 4; i++) {
    p.data[i] = 0;
    for (int j = 0; j < 4; j++) {
      p.data[i] += x.data[i][j] * y.data[j];
    }
  }
  p.color = y.color;
  for (int i = 0; i < 3; i++) {
    p.worldData[i] = y.worldData[i];
  }
  return p;
}

vector3D operator* (const matrix &x, const vector3D &y)
{
	double indata[4];
	indata[0] = y.x; indata[1] = y.y; indata[2] = y.z; indata[3] = 1;
	double outdata[4];
	for (int i = 0; i < 4; i++) {
		outdata[i] = 0;
		for (int j = 0; j < 4; j++) {
			outdata[i] += x.data[i][j] * indata[j];
		}
	}
	
	return vector3D(outdata[0], outdata[1], outdata[2]);
}

matrix& matrix::operator= (const double rhs[][4])
{
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      data[i][j] = rhs[i][j];
    }
  }
  return *this;
}

const double matrix::I[4][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};
