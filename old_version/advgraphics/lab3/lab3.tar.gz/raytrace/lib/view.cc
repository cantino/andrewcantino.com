#include "view.h"
#include "ray.h"
#include <vector>
#include <list>
#include <algorithm>
#include <math.h>

view3D::view3D() { recurseDepth = 5; maxDist = 20000; }

void view3D::setCamera(point3D vrp, point3D vpn, point3D vup)
{
	this->vrp = vrp;
	this->vpn = vpn;
	this->vup = vup;
}

void view3D::setProjectionDistance(double d)
{
	this->d = d;
}

void view3D::setCameraSize(double du, double dv)
{
	this->du = du;
	this->dv = dv;
}

void view3D::setClipPlanes(double F, double B)
{
	this->F = F;
	this->B = B;
}

void view3D::setAmbientLight(colorVector Ia)
{
	this->Ia = Ia;
}

void view3D::setRecurseDepth(int r)
{
	this->recurseDepth = r;
}


// Comparison function to compare two polygonRef3Ds.
bool polygonRef3D_gt (const polygonRef3D &x, const polygonRef3D &y)
{
	return x.points[0]->z() > y.points[0]->z();
}

colorVector view3D::doRayTrace(ray &r, model &m, vector<modelLight> &lightList, int level) {
	colorVector c = colorVector(0, 0, 0);
	list<intersect> intersects;
	m.doIntersect(r, intersects);
	intersects.sort(intersect_gt);
	list<intersect>::iterator iter = intersects.end(); iter--;
	if (! intersects.empty() && iter->t > 0 && iter->t < maxDist) {
		c = colorVector(Ia.r * iter->kD.r, Ia.g * iter->kD.g, Ia.b * iter->kD.b);
		// Do lighting
		for (vector<modelLight>::iterator iterLight = lightList.begin(); iterLight != lightList.end(); iterLight++) {
			vector3D L = iterLight->getL(vector3DtoPoint3D(iter->loc));
			colorVector l = iterLight->getI(L);
			if (dotProduct(iter->normal, L) > 0) {
				//cout << "light: " << iterLight->loc << " | Light Vect: " << L << endl;
				//cout << "intersect: " << *iter << endl;
				// Do a shadow ray to this light source
				list<intersect> sIntersects;
				vector3D lightDir = vector3D(iterLight->loc.z(),
											iterLight->loc.y(),
											iterLight->loc.z()) - iter->loc;
				ray s = ray(iter->loc, L);
				m.doIntersect(s, sIntersects);
				sIntersects.sort(intersect_gt);
				list<intersect>::iterator sIter = sIntersects.end();
				sIter--;
				bool inShadow = false;
				if (! sIntersects.empty())
					if (sIter->t > .00001 && sIter->t < lightDir.magnitude())
						inShadow = true;
				if (! inShadow) {
					//cout << "lambert: " << lambertian(L, iter->normal, l, iter->kD) << endl;
					//cout << "phong: " << phong(L, iter->normal, -r.dir, l, iter->kS, iter->nS) << endl << endl;
					c = c + lambertian(L, iter->normal, l, iter->kD) + phong(L, iter->normal, -r.dir, l, iter->kS, iter->nS);
				}
			}
		}
		
		// Do reflection
		if (iter->kR > 0 && level > 0) {
			vector3D rDir = ((2 * dotProduct(-r.dir,iter->normal)) * iter->normal) + r.dir;
			ray rRay = ray(iter->loc, rDir);
			c = c + iter->kR * doRayTrace(rRay, m, lightList, level - 1);
		}
		
		// Do transmission
	}
	return c;
}

void view3D::raytrace(model &m, image &i)
{
	screenX = i.getCols();
	screenY = i.getRows();
	matrix VTM = matrix::I;
	VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
	vpn.normalize();
	vup.normalize();
	point3D uvec = crossProduct(vup, vpn);
	vup = crossProduct(vpn, uvec);
	VTM.alignAxes3D(uvec, vup, vpn);
	VTM.translate3D(0, 0, d);
	B = B + d;
	//VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
	//d = d / B;
	
	//VTM.scale3D(screenX / (2 * d), screenY / (2 * d), 1.0);
	//VTM.translate3D(-screenX / 2, -screenY / 2, 0);
	
	vector<modelLight> lightList;
	m.xformWorld(VTM, lightList);
	
	for (int x = -screenX / 2; x < screenX / 2; x++) {
		for (int y = -screenY / 2; y < screenY / 2; y++) {
			colorVector pColor = colorVector(0, 0, 0);
			int nJitter = 10;
			for (int jitter = 0; jitter < nJitter; jitter++) {
				vector3D start = vector3D(0.0, 0.0, 0.0);
				double jx = (du/(double)screenX) * (drand48() - .5);
				double jy = (dv/(double)screenY) * (drand48() - .5);
				vector3D end = vector3D((x/(double)(screenX / 2.0))*du + jx, (y/(double)(screenY / 2.0))*dv + jy, d);
				ray r = ray(start, end);

				colorVector c = doRayTrace(r, m, lightList, recurseDepth); // Do the ray tracing!
				
				if (c.r == 0 && c.g == 0 & c.b == 0)
					c = colorVector(1, 1, 1); // Background color.
					
				pColor = colorVector(pColor.r + c.r/(double)nJitter,
								 pColor.g + c.g/(double)nJitter,
								 pColor.b + c.b/(double)nJitter);
			}
			
			if (pColor.r > 1 || pColor.g > 1 || pColor.b > 1)
				cout << "Oh no, color overflow!!" << endl;
			
			i.drawPixel(x + screenX / 2, y + screenY / 2, Pixel(255 * pColor.r, 255 * pColor.g, 255 * pColor.b));
		}
	}

	cout << "Done with raytrace." << endl;
}

void view3D::project(model &m, image &i)
{
	screenX = i.getCols();
	screenY = i.getRows();
	matrix VTM = matrix::I;
	VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
	vpn.normalize();
	vup.normalize();
	point3D uvec = crossProduct(vup, vpn);
	vup = crossProduct(vpn, uvec);
	VTM.alignAxes3D(uvec, vup, vpn);
	VTM.translate3D(0, 0, d);
	B = B + d;
	VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
	d = d / B;

	vector<point3D*> pointList;
	list<polygonRef3D> polygonList;
	vector<modelLight> lightList;
	matrix mx = matrix::I;

	m.render(mx, pointList, polygonList, lightList);

	// Sort the polygonList
	polygonList.sort(polygonRef3D_gt);

	i.makeZBuffer(1.0/B);

	// Apply VTM to all points.
	for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
		**iter *= VTM;
		(**iter).archive();
	}

	for (vector<modelLight>::iterator iter = lightList.begin(); iter != lightList.end(); iter++) {
		iter->loc *= VTM;
		iter->loc.archive();
	}

	// Find a normal for all polygons, using the now transformed points.
	for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {	
		iter->findNormal();
	}

	VTM = matrix::I;
	VTM.PerspProject(d);
	VTM.scale3D( - screenX / (2 * d), screenY / (2 * d), 1.0);
	VTM.translate3D(screenX / 2, screenY / 2, 0);

	// Apply VTM to all points, performing the perspective projection.
	for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
		**iter *= VTM;
	}

	int sz = polygonList.size();
	cout << "Rendering " << sz << " polygons...";

	// Draw all of the polygons in polygonList to the screen.
	for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
		if (dotProduct(vector3D(0,0,1), iter->getNormal()) >= 0) { // Backface culling
			iter->drawZBuffer(i, lightList, polygonList, vrp, Ia);
		}
	}
	cout << "Done." << endl;

}

// ----------- Assorted Functions ---------
colorVector lambertian(vector3D L, vector3D N, colorVector l, colorVector kD) 
{
	double d = dotProduct(N, L);
	//cout << "d: " << d << endl;
	return colorVector(l.r * kD.r * d, l.g * kD.g * d, l.b * kD.b * d);
}

colorVector phong(vector3D L, vector3D N, vector3D v, colorVector l, colorVector kS, double n)
{
	double d = 0;

	vector3D R = (2 * dotProduct(N, L) * N - L).normalized();
	//cout << "R: " << R << " v: " << v << " dp: " << dotProduct(R, v) << endl;
	if (dotProduct(R, v) > 0) {
		d = pow(dotProduct(N, .5 * (L + v)), n);
	}

	return colorVector(l.r * kS.r * d, l.g * kS.g * d, l.b * kS.b * d);
}

Pixel shade(vector<modelLight> lights, list<polygonRef3D> &polygonList, point3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia, polygonRef3D *pRef, bool shadow) 
{
	// Ambient lighting
	colorVector c = colorVector(Ia.r * kD.r, Ia.g * kD.g, Ia.b * kD.b);
 
	for (vector<modelLight>::iterator iter = lights.begin(); iter != lights.end(); iter++) {
		// Do shadows (for each light)
		if (shadow && !shadowCast(P, iter->loc, polygonList, pRef)) {
			vector3D L = iter->getL(P);
			colorVector l = iter->getI(L);
			
			if (dotProduct(N, L) > 0) {
	c = c + lambertian(L, N, l, kD) + phong(L, N, v, l, kS, n);
			}
		} else if (! shadow) {
			vector3D L = iter->getL(P);
			colorVector l = iter->getI(L);
			
			if (dotProduct(N, L) > 0) {
	c = c + lambertian(L, N, l, kD) + phong(L, N, v, l, kS, n);
			}
		}
	}
	return Pixel(255 * c.r, 255 * c.g, 255 * c.b);
}


bool shadowCast(point3D start, point3D light, list<polygonRef3D> & polygonList, polygonRef3D *pRef)
{
	for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
		if ((iter->pointCount > 2) && (&(*iter) != pRef)) {
			point3D v = light - start;
			//double t1 = v.magnitude();
			//v.normalize();
			
			double xa = iter->points[0]->worldX();
			double ya = iter->points[0]->worldY();
			double za = iter->points[0]->worldZ();
			double xb = iter->points[1]->worldX();
			double yb = iter->points[1]->worldY();
			double zb = iter->points[1]->worldZ();
			double xc = iter->points[2]->worldX();
			double yc = iter->points[2]->worldY();
			double zc = iter->points[2]->worldZ();
			double xd = v.x();
			double yd = v.y();
			double zd = v.z();
			double xe = start.x();
			double ye = start.y();
			double ze = start.z();
			
			double a = xa - xb;
			double b = ya - yb;
			double c = za - zb;
			double d = xa - xc;
			double e = ya - yc;
			double f = za - zc;
			double g = xd;
			double h = yd;
			double i = zd;
			double j = xa - xe;
			double k = ya - ye;
			double l = za - ze;
			
			double eiMinushf = e*i - h*f;
			double gfMinusdi = g*f - d*i;
			double dhMinuseg = d*h - e*g;
			double akMinusjb = a*k - j*b;
			double jcMinusal = j*c - a*l;
			double blMinuskc = b*l - k*c;
			
			double M = a*eiMinushf + b*gfMinusdi + c*dhMinuseg;
			double t = -(f*akMinusjb + e*jcMinusal + d*blMinuskc)/M;
			double B = (j*eiMinushf + k*gfMinusdi + l*dhMinuseg)/M;
			double G = (i*akMinusjb + h*jcMinusal + g*blMinuskc)/M;
			
			if (t < .001 || t > .999)
	continue;
			if (G < .001 || G > .999)
	continue;
			if (B < .001 || B > .999 - G)
	continue;
			//cout << "Intersects with polygon " << *iter << endl;
			return true;
		}
	}
	//cout << "No intersection found with any polygon." << endl;
	return false;
}


// ------------- polygonRef3D -------------

polygonRef3D::polygonRef3D() : points(NULL), filled(true), flat(true), kD(colorVector(.7, .7, .7)), kS(colorVector(.8, .8, .8)), nS(48), shadowed(false) {
}

polygonRef3D::polygonRef3D(int n) : pointCount(0), n(n), filled(true), flat(true), kD(colorVector(.7, .7, .7)), kS(colorVector(.8, .8, .8)), nS(48), shadowed(false)
{
	points = new point3D*[n];
}

polygonRef3D::polygonRef3D(const polygonRef3D &p)
{
	pointCount = p.pointCount;
	n = p.n;
	points = new point3D*[n];
	for (int i = 0; i < n; i++) {
		points[i] = p.points[i];
	}
	flat = p.flat;
	filled = p.filled;
	kD = p.kD;
	kS = p.kS;
	nS = p.nS;
	shadowed = p.shadowed;
}

polygonRef3D& polygonRef3D::operator= (const polygonRef3D &rhs)
{
	if (this != &rhs) {
		delete[] points;
		pointCount = rhs.pointCount;
		n = rhs.n;
		points = new point3D*[n];
		for (int i = 0; i < n; i++) {
			points[i] = rhs.points[i];
		}
		flat = rhs.flat;
		filled = rhs.filled;
		kD = rhs.kD;
		kS = rhs.kS;
		nS = rhs.nS;
		shadowed = rhs.shadowed;
	}
	return *this;
}

polygonRef3D::~polygonRef3D()
{
	delete[] points;
}

void polygonRef3D::addPoint(point3D *p)
{
	if (pointCount < n) {
		points[pointCount++] = p;
	} else {
		cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
	}
}

void polygonRef3D::findNormal()
{
	point3D norm = crossProduct(*points[1] - *points[0], *points[2] - *points[0]).normalized();

	normal.x = norm.x();
	normal.y = norm.y();
	normal.z = norm.z();
}

vector3D polygonRef3D::getNormal()
{
	point3D norm = crossProduct(*points[1] - *points[0], *points[2] - *points[0]).normalized();

	vector3D n;
	n.x = norm.x();
	n.y = norm.y();
	n.z = norm.z();

	return n;
}


void polygonRef3D::setFilled(bool m) { filled = m; }

void polygonRef3D::setMaterial(colorVector kD, colorVector kS, double nS)
{
	this->kD = kD;
	this->kS = kS;
	this->nS = nS;
}

void polygonRef3D::setFlat(bool m) { flat = m; }

Pixel polygonRef3D::getColor()
{
	long r = 0, g = 0, b = 0;
	for (int i = 0; i < pointCount; i++) {
		r += points[i]->getColor().r;
		g += points[i]->getColor().g;
		b += points[i]->getColor().b;
	}
	r = r / pointCount;
	g = g / pointCount;
	b = b / pointCount;

	return Pixel(r, g, b);
}

std::ostream& operator<< (std::ostream &out, const polygonRef3D &p)
{
	for (int i = 0; i < p.pointCount; i++)
		{
			out << "(" << p.points[i]->x() << ", " << p.points[i]->y() << ", " << p.points[i]->z() << ") -> ";
		}
	 out << "(" << p.points[0]->x() << ", " << p.points[0]->y() << ", " << p.points[0]->z() << ")";
	return out;
}

bool edgeRecord3D_lt (const polygonRef3D::edgeRecord3D *x, const polygonRef3D::edgeRecord3D *y)
{
	return x->xIntersect < y->xIntersect;
}

polygonRef3D::edgeRecord3D createEdgeRecord(point3D p1, point3D p2, vector3D normal, bool flat);

void polygonRef3D::drawZBuffer(image &im, vector<modelLight> &lightList, list<polygonRef3D> &polygonList, point3D vrp, colorVector Ia)
{
	if (pointCount < 3) {
		cerr << "Too few points in the polygon\n" << endl;
	} else {
		std::list<edgeRecord3D*> activeEdgeList;
		int yStart = im.getRows(), yEnd = 0;
		edgeRecord3D *edges = new edgeRecord3D[pointCount];

		int next_pt, prev_pt;
		int edgeCount = 0;
		for (int j = 0; j < pointCount; j++) {
			next_pt = j < pointCount - 1 ? j + 1 : 0;
			prev_pt = j > 0 ? j - 1 : pointCount - 1;

			if (points[j]->y() != points[next_pt]->y()) {

	if (points[j]->y() < points[next_pt]->y()) {
		edges[edgeCount] = createEdgeRecord(*points[j], *points[next_pt], normal, flat);
	} else {
		edges[edgeCount] = createEdgeRecord(*points[next_pt], *points[j], normal, flat);
	}
	
	if (edges[edgeCount].yStart < yStart) { yStart = edges[edgeCount].yStart; }
	if (edges[edgeCount].yEnd > yEnd) { yEnd = edges[edgeCount].yEnd; }
	edgeCount++;
		
			}
		}
	
		for (int j = yStart; j <= yEnd; j++) {

			//Build Active Edge List
			for (int k = 0; k < edgeCount; k++) {
	if ((edges[k].yStart <= j) && (edges[k].yEnd >= j)) {
		activeEdgeList.push_back(&edges[k]);
	}
			}

			//Sort Active Edge List
			activeEdgeList.sort(edgeRecord3D_lt);

			//Draw Scan Line
			std::list<edgeRecord3D*>::iterator iterEnd = activeEdgeList.end();
			std::list<edgeRecord3D*>::iterator iter = activeEdgeList.begin();
			std::list<edgeRecord3D*>::iterator iterNext = activeEdgeList.begin(); iterNext++;

			while ((iterNext != iterEnd) && (iter != iterEnd)) {
	double z = (**iter).zIntersect;
	double worldX = (**iter).worldXIntersect;
	double worldY = (**iter).worldYIntersect;
	double worldZ = (**iter).worldZIntersect;

	double normalX = (**iter).normalXIntersect;
	double normalY = (**iter).normalYIntersect;
	double normalZ = (**iter).normalZIntersect;

	double dzPerColumn = double((**iter).zIntersect - (**iterNext).zIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);

	double dWorldXPerColumn = double((**iter).worldXIntersect - (**iterNext).worldXIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dWorldYPerColumn = double((**iter).worldYIntersect - (**iterNext).worldYIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dWorldZPerColumn = double((**iter).worldZIntersect - (**iterNext).worldZIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);

	double dNormalXPerColumn = double((**iter).normalXIntersect - (**iterNext).normalXIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dNormalYPerColumn = double((**iter).normalYIntersect - (**iterNext).normalYIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dNormalZPerColumn = double((**iter).normalZIntersect - (**iterNext).normalZIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);

	/*if (int((**iter).xIntersect) == int((**iterNext).xIntersect)) {
		point3D worldPoint = point3D(worldX / z, worldY / z, 1.0 / worldZ);
		vector3D viewV = vector3D(vrp.x() - worldPoint.x(), vrp.y() - worldPoint.y(), vrp.z() - worldPoint.z()).normalized();
		vector3D norm = vector3D(normalX / z, normalY / z, normalZ / z).normalized();
		im.drawPixel(int((**iter).xIntersect), j, shadeWithShadows(lightList, polygonList, worldPoint, norm, viewV, kD, kS, nS, Ia, this));
		}*/
	for (int i = int((**iter).xIntersect); i < (**iterNext).xIntersect; i++) {
		if (z > im.getZValue(i, j)) {
			point3D worldPoint = point3D(worldX / z, worldY / z, 1.0 / worldZ);
			vector3D viewV = vector3D(vrp.x() - worldPoint.x(), vrp.y() - worldPoint.y(), vrp.z() - worldPoint.z()).normalized();
			vector3D norm = vector3D(normalX / z, normalY / z, normalZ / z).normalized();
			
			im.drawPixel(i, j, shade(lightList, polygonList, worldPoint, norm, viewV, kD, kS, nS, Ia, this, shadowed));
			
			//im.drawPixel(i, j, Pixel(lightList.begin()->getL(worldPoint).x * 255, lightList.begin()->getL(worldPoint).y * 255, lightList.begin()->getL(worldPoint).z * 255));
			//im.drawPixel(i, j, Pixel(worldPoint.z() * 255, 0, 0));

			im.setZValue(i, j, z);
		}
		z += dzPerColumn;
		worldX += dWorldXPerColumn;
		worldY += dWorldYPerColumn;
		worldZ += dWorldZPerColumn;

		normalX += dNormalXPerColumn;
		normalY += dNormalYPerColumn;
		normalZ += dNormalZPerColumn;
	}

	iter++; iterNext++;
	if (iter == iterEnd) { break; }
	iter++; iterNext++;
			}
		
			iter = activeEdgeList.begin();
			for (iter = activeEdgeList.begin(); iter != activeEdgeList.end(); iter++) {
	(**iter).xIntersect += (**iter).dxPerScan;
	(**iter).zIntersect += (**iter).dzPerScan;

	(**iter).worldXIntersect += (**iter).dWorldXPerScan;
	(**iter).worldYIntersect += (**iter).dWorldYPerScan;
	(**iter).worldZIntersect += (**iter).dWorldZPerScan;

	(**iter).normalXIntersect += (**iter).dNormalXPerScan;
	(**iter).normalYIntersect += (**iter).dNormalYPerScan;
	(**iter).normalZIntersect += (**iter).dNormalZPerScan;
			}

			activeEdgeList.clear();
		}
		delete [] edges;
	 
	}
}

polygonRef3D::edgeRecord3D createEdgeRecord(point3D p1, point3D p2, vector3D normal, bool flat) {

	polygonRef3D::edgeRecord3D edge;

	edge.yStart = int(p1.y());
	edge.yEnd = int(p2.y() - 1);
	
	double deltaY = edge.yEnd - edge.yStart;

	edge.xIntersect = p1.x();
	edge.zIntersect = 1.0 / p1.depth();
	
	edge.dxPerScan = double(p2.x() - p1.x()) / deltaY;
	edge.dzPerScan = double(1.0 / p2.depth() - 1.0 / p1.depth()) / deltaY;
		
	edge.worldXIntersect = p1.worldX() * edge.zIntersect;
	edge.worldYIntersect = p1.worldY() * edge.zIntersect;
	edge.worldZIntersect = 1.0 / p1.worldZ();
	
	edge.dWorldXPerScan = double(p2.worldX() / p2.worldZ() - p1.worldX() / p1.worldZ()) / (deltaY);
	edge.dWorldYPerScan = double(p2.worldY() / p2.worldZ() - p1.worldY() / p1.worldZ()) / (deltaY);
	edge.dWorldZPerScan = double(1.0 / p2.worldZ() - 1.0 / p1.worldZ()) / deltaY;
	
	if (flat) {
		edge.normalXIntersect = normal.x * edge.zIntersect;
		edge.normalYIntersect = normal.y * edge.zIntersect;
		edge.normalZIntersect = normal.z * edge.zIntersect;
		edge.dNormalXPerScan = 0;
		edge.dNormalYPerScan = 0;
		edge.dNormalZPerScan = 0;
	} else {
		edge.normalXIntersect = p1.normal.x * edge.zIntersect;
		edge.normalYIntersect = p1.normal.y * edge.zIntersect;
		edge.normalZIntersect = p1.normal.z * edge.zIntersect;
		edge.dNormalXPerScan = double(p2.normal.x / p2.worldZ() - p1.normal.x / p1.worldZ()) / deltaY;
		edge.dNormalYPerScan = double(p2.normal.y / p2.worldZ() - p1.normal.y / p1.worldZ()) / deltaY;
		edge.dNormalZPerScan = double(p2.normal.z / p2.worldZ() - p1.normal.z / p1.worldZ()) / deltaY;
	}

	return edge;
}
	
	
void view3D::parallelProject(model &m, image &i)
{
	cerr << "No parallel projection for you!" << endl;
	/*
	screenX = i.getCols();
	screenY = i.getRows();
	matrix VTM = matrix::I;
	VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
	vpn.normalize();
	vup.normalize();
	point3D uvec = crossProduct(vup, vpn);
	vup = crossProduct(vpn, uvec);
	VTM.alignAxes3D(uvec, vup, vpn);
	VTM.translate3D(0, 0, d);
	B = B + d;
	VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
	VTM.ParallelProject();
	VTM.scale3D(-screenX / 2, screenY / 2, 1);
	VTM.translate3D(screenX / 2, screenY / 2, 0);

	vector<point3D*> pointList;
	list<polygonRef3D> polygonList;
	vector<modelLight> lightList;
	matrix mx = matrix::I;

	m.render(mx, pointList, polygonList, lightList);

	for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
		**iter *= VTM;
	}

	for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
		iter->drawZBuffer(i);
	}

	//Clear Point List
	for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
		delete *iter;
	}
	*/
}
