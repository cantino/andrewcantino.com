#include "modelio.h"
#include <sstream>

using namespace std;

int main() {
    // Note, loaded models may get mutated when rendered!
    model * test = loadASEModel("../sphere.ase");
    model scene;
    scene.addItem(test);
    scene.addItem(new modelMatrixReset());
    polygon3D *floor = new polygon3D(4);
    floor->addPoint(point3D(-150, -150, -100));
    floor->addPoint(point3D(150, -150,  -100));
    floor->addPoint(point3D(150, 150,  -100));
    floor->addPoint(point3D(-150, 150,  -100));
    floor->setMaterial(colorVector(.7, .5, .5), colorVector(.8, .8, .8), 32);
    floor->setFlat(true);
    //scene.addItem(new modelScale3D(100, 100, 0));
    scene.addItem(floor);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(25, 25, 70));
    scene.addItem(new pointLight(colorVector(1, 0, 0)));
    cout << "Added the model." << endl;
    image im = image(200, 200, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(100, 100, 100), point3D(-1, -1, -1), point3D(0, 0, 1));
    v.setProjectionDistance(4);
    v.setCameraSize(1, 1);
    v.setClipPlanes(0, 1000000);
    v.setAmbientLight(colorVector(100/255.0, 100/255.0, 100/255.0));
    v.raytrace(scene, im);
    //v.project(scene, im);
    im.writeImage("../images/sphere.ppm");
}
