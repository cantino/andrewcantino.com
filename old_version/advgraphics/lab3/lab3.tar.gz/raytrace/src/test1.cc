#include "view.h"
#include <sstream>

int main() {
    model scene;
    polygon3D base = polygon3D(4);
    base.addPoint(point3D(-1, -1, 0));
    base.addPoint(point3D(1, -1, 0));
    base.addPoint(point3D(1, 1, 0));
    base.addPoint(point3D(-1, 1, 0));
    
    pyramid3D *pyr = new pyramid3D(point3D(0, 0, 1), base);
    pyr->setMaterial(colorVector(.7, .7, .7), colorVector(1, 1, 1), 48);
    pyr->setFlat(true);
    scene.addItem(new modelRotate3Dz(3.1415/2.0));
    scene.addItem(pyr);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(.75, .75, .5));

    scene.addItem(new modelRotate3Dz(3.1415/4.0));

    scene.addItem(new pointLight(colorVector(0, 0, 1)));
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(0, 0, 1.5));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));
    
    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(0, -1, .5), point3D(0, 1, -.5), point3D(0, 1, 0));
    v.setProjectionDistance(2);
    v.setCameraSize(4, 4);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(100/255.0, 100/255.0, 100/255.0));
    v.project(scene, im);
    
    im.writeImage("../images/test.ppm");
}
