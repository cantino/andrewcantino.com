#include "view.h"
#include <sstream>

using namespace std;

int main() {
	//for (int i = 0; i < 30; i++) {
		int i = 13;
		model scene;
		/*polygon3D *poly = new polygon3D(3);
		poly->addPoint(point3D(0, .1, 0));
		poly->addPoint(point3D(2, .1, 2));
		poly->addPoint(point3D(-2, .1, 2));
		poly->setMaterial(colorVector(.7, .2, .2), colorVector(1, 1, 1), 48, .5, 0);
		poly->setFlat(true);
		scene.addItem(poly);
		
		polygon3D *poly2 = new polygon3D(3);
		poly2->addPoint(point3D(1.5, 1.5, 4));
		poly2->addPoint(point3D(2.5, 2.5, 4));
		poly2->addPoint(point3D(1.5, 3.5, 4));
		poly2->setMaterial(colorVector(.2, .2, .7), colorVector(1, 1, 1), 48, .5, 0);
		poly2->setFlat(true);
		scene.addItem(poly2);

		sphere *s = new sphere(vector3D(-1, 0, 1), .5);
		s->setMaterial(colorVector(.2, .2, .7), colorVector(1, 1, 1), 48, .5, 0);
		scene.addItem(s);

		sphere *s2 = new sphere(vector3D(1, 0, 1), .5);
		s2->setMaterial(colorVector(.7, .2, .2), colorVector(1, 1, 1), 48, .5, 0);
		scene.addItem(s2);*/


		for (int a = 0; a < 500; a++) {
			sphere *s2 = new sphere(vector3D((drand48() - .5) * 2, (drand48() - .5) * 2, drand48() * 2), .1);
			s2->setMaterial(colorVector(drand48(), drand48(), drand48()), colorVector(drand48(), drand48(), drand48()), 48, drand48(), 0);
			scene.addItem(s2);
		}



		//scene.addItem(new modelMatrixReset());
		//scene.addItem(new modelTranslate3D(0, 4, 0));
		//scene.addItem(new modelRotate3Dx((i/10.0)*3.1415*2));
		//scene.addItem(new pointLight(colorVector(.5, .5, .5)));
		scene.addItem(new modelMatrixReset());
		scene.addItem(new modelTranslate3D(5, 4, -1));
		//scene.addItem(new modelRotate3Dy((i/30.0)*3.1415*2));
		scene.addItem(new pointLight(colorVector(1, 1, .2)));
		
		//scene.addItem(new modelMatrixReset());
		//scene.addItem(new modelTranslate3D(-2, 3, -1));
		//scene.addItem(new modelRotate3Dy((i/30.0)*3.1415*2));
		//scene.addItem(new pointLight(colorVector(1, 1, .2)));
		
		image im = image(400, 400, Pixel(255, 255, 255));
		view3D v;
		v.setCamera(point3D(0, 1, 0), point3D(0, -1, 1), point3D(0, 1, 0));
		v.setProjectionDistance(2);
		v.setCameraSize(1, 1);
		v.setClipPlanes(0, 100);
		v.setAmbientLight(colorVector(100/255.0, 100/255.0, 100/255.0));
		v.raytrace(scene, im);

		ostringstream osData;
		osData.width(2);
		osData.fill('0');
		osData.setf(ios::right, ios::adjustfield);
		osData << i;
		
		im.writeImage("../images/test.ppm");
		//im.writeImage("../images/test/test" + osData.str() + ".ppm");
	//}
}
