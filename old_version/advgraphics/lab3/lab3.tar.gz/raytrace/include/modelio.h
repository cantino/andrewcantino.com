#ifndef MODELIO_H
#define MODELIO_H

#include "view.h"
#include <fstream.h>

/**
 * Import a Model in ASE format
 * This will take a mesh in ASE file format, and load the various meshes.
 * @return A pointer to a model containing all the loaded meshes
 */
model * loadASEModel(const char * filename);

#endif
