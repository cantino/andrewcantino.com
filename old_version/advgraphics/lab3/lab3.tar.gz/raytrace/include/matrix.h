#ifndef MATRIX_H
#define MATRIX_H

#include <iostream.h>

class vector3D;
class point3D;

/**
 * A 4x4 Matrix class.
 */
class matrix {
  double data[4][4];
  
 public:
  /**
   * Primative Constructor
   */
  matrix();
  /**
   * Copy Constructor
   */
  matrix(const matrix &copy);
  /**
   * Array Constructor
   * Constructs a matrix from a 4 by 4 array.
   */
  matrix(const double copy[][4]);
  /**
   * Constructor
   * Constructs a matrix from 16 doubles.  The first four represent row 0, etc.
   */
  matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33);

  /**
   * Translate the matrix
   * Premultiplies the matrix by a 3D translation matrix.
   * @param tx Translation in x
   * @param ty Translation in y
   * @param tz Translation in z
   */
  void translate3D(double tx, double ty, double tz);

  /**
   * Scale the matrix
   * Premultiplies the matrix by a 3D scale matrix.
   * @param s The scale factor for all directions
   */
  void scale3D(double s); // Scale the same amount (s) in all directions.
  /**
   * Scale the matrix
   * Premultiplies the matrix by a 3D scale matrix.
   * @param sx The scale factor in the x direction
   * @param sy The scale factor in the y direction
   * @param sz The scale factor in the z direction
   */
  void scale3D(double sx, double sy, double sz);
  /**
   * Scale the matrix
   * Premultiplies the matrix by a 3D scale matrix.
   * @param s The scale factor for all directions
   * @param center The point to perform the scale around
   */
  void scale3D(point3D center, double s);
  /**
   * Scale the matrix
   * Premultiplies the matrix by a 3D scale matrix.
   * @param center The point to perform the scale around 
   * @param sx The scale factor in the x direction
   * @param sy The scale factor in the y direction
   * @param sz The scale factor in the z direction
   */  
  void scale3D(point3D center, double sx, double sy, double sz);
   /**
   * Scale the matrix
   * Premultiplies the matrix by a 3D scale matrix.
   * @param center The point to perform the scale around
   * @param direction The direction to align the x, y, and z axes with for the scale
   * @param sx The scale factor in the x direction
   * @param sy The scale factor in the y direction
   * @param sz The scale factor in the z direction
   */
  void scale3D(point3D center, point3D direction, double sx, double sy, double sz);

  /**
   * Rotate the matrix around the x axis.
   * Premultiplies the matrix by a 3D rotation matrix around x.
   * @param theta The angle to rotate around the x axis
   */
  void rotate3Dx(double theta);
  /**
   * Rotate the matrix around the x axis.
   * Premultiplies the matrix by a 3D rotation matrix around x.
   * @param center The point to do the rotation around
   * @param theta The angle to rotate around the x axis
   */
  void rotate3Dx(point3D center, double theta);
  /**
   * Rotate the matrix around the y axis.
   * Premultiplies the matrix by a 3D rotation matrix around y.
   * @param theta The angle to rotate around the y axis
   */
  void rotate3Dy(double theta);
  /**
   * Rotate the matrix around the y axis.
   * Premultiplies the matrix by a 3D rotation matrix around y.
   * @param center The point to do the rotation around
   * @param theta The angle to rotate around the y axis
   */
  void rotate3Dy(point3D center, double theta);
  /**
   * Rotate the matrix around the z axis.
   * Premultiplies the matrix by a 3D rotation matrix around z.
   * @param theta The angle to rotate around the z axis
   */
  void rotate3Dz(double theta);
  /**
   * Rotate the matrix around the z axis.
   * Premultiplies the matrix by a 3D rotation matrix around z.
   * @param center The point to do the rotation around
   * @param theta The angle to rotate around the z axis
   */
  void rotate3Dz(point3D center, double theta);

  /**
   * Align two sets of axes
   * Premultiplies the matrix by a 3D axes alignment matrix.
   * @param newX A vector pointing in the direction of the new x axis.
   * @param newY A vector pointing in the direction of the new y axis.
   * @param newZ A vector pointing in the direction of the new z axis.
   */
  void alignAxes3D(point3D newX, point3D newY, point3D newZ);

  /**
   * Sheer the matrix in x
   * Premultiplies the matrix by a 3D sheer matrix in x
   * @param shy The sheer factor in y
   * @param shz The sheer factor in z
   */
  void sheer3Dx(double shy, double shz);
  /**
   * Sheer the matrix in y
   * Premultiplies the matrix by a 3D sheer matrix in y
   * @param shx The sheer factor in x
   * @param shz The sheer factor in z
   */
  void sheer3Dy(double shx, double shz);
  /**
   * Sheer the matrix in z
   * Premultiplies the matrix by a 3D sheer matrix in z
   * @param shx The sheer factor in z
   * @param shy The sheer factor in y
   */
  void sheer3Dz(double shx, double shy);

  /**
   * Perspective transform
   * Premultiplies the matrix by a 3D perspective transform
   * @param d Distance from the the VPN to the center of projection
   */
  void PerspProject(double d);
  /**
   * Parallel transform
   * Premultiplies the matrix by a 3D parallel transform
   */
  void ParallelProject();

  /**
   * Standard matrix multiplication
   * @param x The first 4x4 matrix to multiply
   * @param y The second 4x4 matrix to multiply
   */
  friend matrix operator* (const matrix &x, const matrix &y);
  /**
   * Standard matrix addition
   * @param x The first matrix to add
   * @param y The second matrix to add
   */
  friend matrix operator+ (const matrix &x, const matrix &y);
  /**
   * Standard matrix multiplication
   * @param x The first 4x4 matrix to multiply
   * @param y The second 4x1 matrix (represented as a point3D) to multiply
   */
  friend point3D operator* (const matrix &x, const point3D &y);
  friend vector3D operator* (const matrix &x, const vector3D &y);

  void operator*= (const matrix &rhs);

  friend std::ostream& operator<< (std::ostream & out, const matrix &p);

  matrix& operator= (const double rhs[][4]);
  /**
   * The identity matrix
   */
  static const double I[][4];
};

#endif







