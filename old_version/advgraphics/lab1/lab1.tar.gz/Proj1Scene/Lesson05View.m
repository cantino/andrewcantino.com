/*
 * Original Windows comment:
 * "This code was created by Jeff Molofee 2000
 * A HUGE thanks to Fredric Echols for cleaning up
 * and optimizing the base code, making it more flexible!
 * If you've found this code useful, please let me know.
 * Visit my site at nehe.gamedev.net"
 * 
 * Cocoa port by Bryan Blackburn 2002; www.withay.com
 */

/* Lesson05View.m */

#import "Lesson05View.h"

@interface Lesson05View (InternalMethods)
- (NSOpenGLPixelFormat *) createPixelFormat:(NSRect)frame;
- (void) switchToOriginalDisplayMode;
- (BOOL) initGL;
- (BOOL) loadGLTextures:(NSString *)filename intoIndex:(int)index;
- (BOOL) loadBitmap:(NSString *)filename intoIndex:(int)texIndex;
- (void) drawBoxWithWidth:(float)width height:(float)height 
					depth:(float)depth frontTexture:(int)fT 
					backTexture:(int)bT leftTexture:(int)lT
					rightTexture:(int)rT bottomTexture:(int)boT
					topTexture:(int)tT;
- (void) drawBookwithTexturesStartingAt:(int)textureOffset;
@end

@implementation Lesson05View

- (id) initWithFrame:(NSRect)frame colorBits:(int)numColorBits
		   depthBits:(int)numDepthBits fullscreen:(BOOL)runFullScreen
{
	NSOpenGLPixelFormat *pixelFormat;
	
	colorBits = numColorBits;
	depthBits = numDepthBits;
	runningFullScreen = runFullScreen;
	originalDisplayMode = (NSDictionary *) CGDisplayCurrentMode( kCGDirectMainDisplay );
	xrot = yrot = zrot = 0;
	pixelFormat = [ self createPixelFormat:frame ];
	if( pixelFormat != nil )
	{
		self = [ super initWithFrame:frame pixelFormat:pixelFormat ];
		[ pixelFormat release ];
		if( self )
		{
			[ [ self openGLContext ] makeCurrentContext ];
			if( runningFullScreen )
				[ [ self openGLContext ] setFullScreen ];
			[ self reshape ];
			if( ![ self initGL ] )
			{
				[ self clearGLContext ];
				self = nil;
			}
		}
	}
	else
		self = nil;
	
	step = 0.0f;
	
	return self;
}


/*
 * Create a pixel format and possible switch to full screen mode
 */
- (NSOpenGLPixelFormat *) createPixelFormat:(NSRect)frame
{
	NSOpenGLPixelFormatAttribute pixelAttribs[ 16 ];
	int pixNum = 0;
	NSDictionary *fullScreenMode;
	NSOpenGLPixelFormat *pixelFormat;
	
	pixelAttribs[ pixNum++ ] = NSOpenGLPFADoubleBuffer;
	pixelAttribs[ pixNum++ ] = NSOpenGLPFAAccelerated;
	pixelAttribs[ pixNum++ ] = NSOpenGLPFAColorSize;
	pixelAttribs[ pixNum++ ] = colorBits;
	pixelAttribs[ pixNum++ ] = NSOpenGLPFADepthSize;
	pixelAttribs[ pixNum++ ] = depthBits;
	
	if( runningFullScreen )  // Do this before getting the pixel format
	{
		pixelAttribs[ pixNum++ ] = NSOpenGLPFAFullScreen;
		fullScreenMode = (NSDictionary *) CGDisplayBestModeForParameters(
																		 kCGDirectMainDisplay,
																		 colorBits, frame.size.width,
																		 frame.size.height, NULL );
		CGDisplayCapture( kCGDirectMainDisplay );
		CGDisplayHideCursor( kCGDirectMainDisplay );
		CGDisplaySwitchToMode( kCGDirectMainDisplay,
							   (CFDictionaryRef) fullScreenMode );
	}
	pixelAttribs[ pixNum ] = 0;
	pixelFormat = [ [ NSOpenGLPixelFormat alloc ]
                   initWithAttributes:pixelAttribs ];
	
	return pixelFormat;
}


/*
 * Enable/disable full screen mode
 */
- (BOOL) setFullScreen:(BOOL)enableFS inFrame:(NSRect)frame
{
	BOOL success = FALSE;
	NSOpenGLPixelFormat *pixelFormat;
	NSOpenGLContext *newContext;
	
	[ [ self openGLContext ] clearDrawable ];
	if( runningFullScreen )
		[ self switchToOriginalDisplayMode ];
	runningFullScreen = enableFS;
	pixelFormat = [ self createPixelFormat:frame ];
	if( pixelFormat != nil )
	{
		newContext = [ [ NSOpenGLContext alloc ] initWithFormat:pixelFormat
												   shareContext:nil ];
		if( newContext != nil )
		{
			[ super setFrame:frame ];
			[ super setOpenGLContext:newContext ];
			[ newContext makeCurrentContext ];
			if( runningFullScreen )
				[ newContext setFullScreen ];
			[ self reshape ];
			if( [ self initGL ] )
				success = TRUE;
		}
		[ pixelFormat release ];
	}
	if( !success && runningFullScreen )
		[ self switchToOriginalDisplayMode ];
	
	return success;
}


/*
 * Switch to the display mode in which we originally began
 */
- (void) switchToOriginalDisplayMode
{
	CGDisplaySwitchToMode( kCGDirectMainDisplay,
						   (CFDictionaryRef) originalDisplayMode );
	CGDisplayShowCursor( kCGDirectMainDisplay );
	CGDisplayRelease( kCGDirectMainDisplay );
}


/*
 * Initial OpenGL setup
 */
- (BOOL) initGL
{ 
	// Load chair textures
	if( ![ self loadGLTextures:"chairBack.bmp" intoIndex:1 ] )
		return FALSE;
	if( ![ self loadGLTextures:"chairSide.bmp" intoIndex:2 ] )
		return FALSE;
	if( ![ self loadGLTextures:"chairCloth.bmp" intoIndex:3 ] )
		return FALSE;
	// Load book textures
	if( ![ self loadGLTextures:"bookSide.bmp" intoIndex:4 ] )
		return FALSE;
	if( ![ self loadGLTextures:"bookSidePages.bmp" intoIndex:5 ] )
		return FALSE;
	if( ![ self loadGLTextures:"bookFront.bmp" intoIndex:6 ] )
		return FALSE;
	if( ![ self loadGLTextures:"bookBack.bmp" intoIndex:7 ] )
		return FALSE;
	// Load other textures
	if( ![ self loadGLTextures:"carpet.bmp" intoIndex:8 ] )
		return FALSE;
	if( ![ self loadGLTextures:"bricks.bmp" intoIndex:9 ] )
		return FALSE;
	
	glEnable( GL_TEXTURE_2D );                // Enable texture mapping
	glShadeModel( GL_SMOOTH );                // Enable smooth shading
	glClearColor( 0.0f, 0.0f, 0.0f, 0.5f );   // Black background
	glClearDepth( 1.0f );                     // Depth buffer setup
	glEnable( GL_DEPTH_TEST );                // Enable depth testing
	glDepthFunc( GL_LEQUAL );                 // Type of depth test to do
											  // Really nice perspective calculations
	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );
	
	return TRUE;
}


/*
 * Setup a texture from our model
 */
- (BOOL) loadGLTextures:(NSString *)filename intoIndex:(int)index
{
	BOOL status = FALSE;
	
	if( [ self loadBitmap:[ NSString stringWithFormat:@"%@/%s",
		[ [ NSBundle mainBundle ] resourcePath ],
		filename ] intoIndex:index-1 ] )
	{
		status = TRUE;
		
		glGenTextures( 1, &texture[ index-1 ] );   // Create the texture
		
		// Typical texture generation using data from the bitmap
		glBindTexture( GL_TEXTURE_2D, texture[ index-1 ] );
		
		glTexImage2D( GL_TEXTURE_2D, 0, 3, texSize[ index-1 ].width,
					  texSize[ index-1 ].height, 0, texFormat[ index-1 ],
					  GL_UNSIGNED_BYTE, texBytes[ index-1 ] );
		// Linear filtering
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		
		free( texBytes[ index-1 ] );
	} else {
		NSBeep();
		NSWindow *infoWindow;
		infoWindow = NSGetCriticalAlertPanel( @"Texture load failed",
											  @"Failed to load texture",
											  @"OK", nil, nil );
		[ NSApp runModalForWindow:infoWindow ];
		[ infoWindow close ];

		status = FALSE;
	}
	return status;
}


/*
 * Resize ourself
 */
- (void) reshape
{ 
	NSRect sceneBounds;
	
	[ [ self openGLContext ] update ];
	sceneBounds = [ self bounds ];
	// Reset current viewport
	glViewport( 0, 0, sceneBounds.size.width, sceneBounds.size.height );
	glMatrixMode( GL_PROJECTION );   // Select the projection matrix
	glLoadIdentity();                // and reset it
									 // Calculate the aspect ratio of the view
	gluPerspective( 45.0f, sceneBounds.size.width / sceneBounds.size.height,
					0.1f, 100.0f );
	glMatrixMode( GL_MODELVIEW );    // Select the modelview matrix
	glLoadIdentity();                // and reset it
}

- (void) drawBoxWithWidth:(float)width height:(float)height 
					depth:(float)depth frontTexture:(int)fT 
					backTexture:(int)bT leftTexture:(int)lT
					rightTexture:(int)rT bottomTexture:(int)boT topTexture:(int)tT
{
	glBindTexture( GL_TEXTURE_2D, texture[ fT ] );
	glBegin( GL_QUADS );
	// Front face
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -width, -height,  depth );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  width, -height,  depth );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  width,  height,  depth );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -width,  height,  depth );   // Top left
	glEnd();
	
    glBindTexture( GL_TEXTURE_2D, texture[ bT ] );
	glBegin( GL_QUADS );
	// Back face
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -width, -height, -depth );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -width,  height, -depth );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  width,  height, -depth );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  width, -height, -depth );   // Bottom left
	glEnd();
	
    glBindTexture( GL_TEXTURE_2D, texture[ tT ] );
	glBegin( GL_QUADS );
	// Top face
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -width,  height, -depth );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -width,  height,  depth );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  width,  height,  depth );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  width,  height, -depth );   // Top right
	glEnd();
	
    glBindTexture( GL_TEXTURE_2D, texture[ boT ] );
	glBegin( GL_QUADS );
	// Bottom face
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -width, -height, -depth );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  width, -height, -depth );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  width, -height,  depth );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -width, -height,  depth );   // Bottom right
	glEnd();
	
    glBindTexture( GL_TEXTURE_2D, texture[ rT ] );
	glBegin( GL_QUADS );
	// Right face
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  width, -height, -depth );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  width,  height, -depth );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  width,  height,  depth );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  width, -height,  depth );   // Bottom left
	glEnd();
	
    glBindTexture( GL_TEXTURE_2D, texture[ lT ] );
	glBegin( GL_QUADS );
	// Left face
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -width, -height, -depth );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -width, -height,  depth );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -width,  height,  depth );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -width,  height, -depth );   // Top left
	glEnd();
}


/*
 * Called when the system thinks we need to draw.
 */
- (void) drawRect:(NSRect)rect
{
	// Clear the screen and depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_NORMALIZE); // Automatically renormalize normals
	glLoadIdentity();   // Reset the current modelview matrix
	
	glTranslatef( 0.0f, 0.0f, -6.0f );   // into screen 6.0
	// Rotate on X axis
	glRotatef( xrot, 1.0f, 0.0f, 0.0f );
	// Rotate on Y axis
	glRotatef( yrot, 0.0f, 1.0f, 0.0f );
	// Rotate on Z axis
	glRotatef( zrot, 0.0f, 0.0f, 1.0f );
	
	
	// ============= Draw Chair =============
	glTranslatef( .7f, 0.0f, 0.0f );
	[self drawBoxWithWidth:.15 height:.7 depth:.9 frontTexture:1 backTexture:1 leftTexture:0 \
			  rightTexture:0 bottomTexture:1 topTexture:1]; // Right side
	
	glTranslatef( -1.4f, 0.0f, 0.0f );
	[self drawBoxWithWidth:.15 height:.7 depth:.9 frontTexture:1 backTexture:1  leftTexture:0 \
			  rightTexture:0 bottomTexture:1 topTexture:1]; // Left side
	
	glTranslatef( .7f, -.5f, 0.0f );
	[self drawBoxWithWidth:.55 height:.1 depth:.9 frontTexture:1 backTexture:1  leftTexture:1 \
			  rightTexture:1 bottomTexture:0 topTexture:0]; // Wooden base
	
	glTranslatef( 0.0f, .3f, 0.0f );
	[self drawBoxWithWidth:.55 height:.2 depth:.85 frontTexture:2 backTexture:2  leftTexture:2 \
			  rightTexture:2 bottomTexture:2 topTexture:2]; // Padded seat
	
	glTranslatef( 0.0f, .35f, -.6f );
	[self drawBoxWithWidth:.55 height:.7 depth:.2 frontTexture:2 backTexture:2  leftTexture:2 \
			  rightTexture:2 bottomTexture:2 topTexture:2]; // Back padded
	
	glTranslatef( 0.0f, -.1f, -.25f );
	[self drawBoxWithWidth:.55 height:.6 depth:.05 frontTexture:0 backTexture:0  leftTexture:1 \
			  rightTexture:1 bottomTexture:1 topTexture:1]; // Back wood
	
	
	glLoadIdentity();
	glTranslatef( 0.0f, 0.0f, -6.0f );   // into screen 6.0
	glRotatef( xrot, 1.0f, 0.0f, 0.0f );
	glRotatef( yrot, 0.0f, 1.0f, 0.0f );
	glRotatef( zrot, 0.0f, 0.0f, 1.0f );
	
	glScalef( .4f, .4f, .4f);
	glTranslatef( 1.7f, 2.175f, .7f );   // into screen 6.0
	glRotatef( 10, 0.0f, 1.0f, 0.0f );
	
	// ============= Draw Book ==============
	[self drawBookwithTexturesStartingAt:3];
	
	
	glLoadIdentity();
	glTranslatef( 0.0f, 0.0f, -6.0f );   // into screen 6.0
	glRotatef( xrot, 1.0f, 0.0f, 0.0f );
	glRotatef( yrot, 0.0f, 1.0f, 0.0f );
	glRotatef( zrot, 0.0f, 0.0f, 1.0f );
	
	glScalef( 2.0f, 2.0f, 2.0f );
	glTranslatef( 0.0f, -.36f, 0.0f );   // into screen 6.0
	
	// ============= Draw Floor ==============
    glBindTexture( GL_TEXTURE_2D, texture[ 7 ] );
	glBegin( GL_QUADS );
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -1.0f,  0.0f, -1.0f );
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -1.0f,  0.0f,  1.0f );
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  1.0f,  0.0f,  1.0f );
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  1.0f,  0.0f, -1.0f );
	glEnd();
	
	// ============= Draw Left Wall ==============
	glTranslatef( -1.0f, 1.0f, 0.0f );
	glBindTexture( GL_TEXTURE_2D, texture[ 8 ] );
	glBegin( GL_QUADS );
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( 0.0f,  -1.0f, -1.0f );
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( 0.0f,  1.0f,  -1.0f );
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  0.0f,  1.0f,  1.0f );
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  0.0f,  -1.0f, 1.0f );
	glEnd();
	
	// ============= Draw Back Wall ==============
	glTranslatef( 1.0f, 0.0f, 0.0f );
	glBindTexture( GL_TEXTURE_2D, texture[ 8 ] );
	glBegin( GL_QUADS );
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -1.0f,  -1.0f, -1.0f );
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( 1.0f,  -1.0f,  -1.0f );
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  1.0f,  1.0f,  -1.0f );
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  -1.0f,  1.0f, -1.0f );
	glEnd();
	
	[ [ self openGLContext ] flushBuffer ];
	xrot = fabs(50*sin(step*.2f));
	yrot = 25*sin(step);
	zrot = 0.0f;
	step += .02;
}

- (void) drawBookwithTexturesStartingAt:(int)textureOffset
{
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 1 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Front face
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -1.0f, -0.4f,  1.0f );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  1.0f, -0.4f,  1.0f );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  1.0f,  0.4f,  1.0f );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -1.0f,  0.4f,  1.0f );   // Top left
	glEnd();
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 1 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Back face
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -1.0f, -0.4f, -1.0f );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -1.0f,  0.4f, -1.0f );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  1.0f,  0.4f, -1.0f );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  1.0f, -0.4f, -1.0f );   // Bottom left
	glEnd();
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 2 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Top face
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -1.0f,  0.4f, -1.0f );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -1.0f,  0.4f,  1.0f );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  1.0f,  0.4f,  1.0f );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  1.0f,  0.4f, -1.0f );   // Top right
	glEnd();
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 3 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Bottom face
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -1.0f, -0.4f, -1.0f );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  1.0f, -0.4f, -1.0f );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  1.0f, -0.4f,  1.0f );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -1.0f, -0.4f,  1.0f );   // Bottom right
	glEnd();
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 1 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Right face
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f(  1.0f, -0.4f, -1.0f );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f(  1.0f,  0.4f, -1.0f );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f(  1.0f,  0.4f,  1.0f );   // Top left
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f(  1.0f, -0.4f,  1.0f );   // Bottom left
	glEnd();
	glBindTexture( GL_TEXTURE_2D, texture[ textureOffset + 0 ] );   // Select our texture
	glBegin( GL_QUADS );
	// Left face
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -1.0f, -0.4f, -1.0f );   // Bottom left
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( -1.0f, -0.4f,  1.0f );   // Bottom right
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( -1.0f,  0.4f,  1.0f );   // Top right
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -1.0f,  0.4f, -1.0f );   // Top left
	glEnd();
}


/*
 * Are we full screen?
 */
- (BOOL) isFullScreen
{
	return runningFullScreen;
}


/*
 * Cleanup
 */
- (void) dealloc
{
	if( runningFullScreen )
		[ self switchToOriginalDisplayMode ];
	[ originalDisplayMode release ];
}

/*
 * The NSBitmapImageRep is going to load the bitmap, but it will be
 * setup for the opposite coordinate system than what OpenGL uses, so
 * we copy things around.
 */
- (BOOL) loadBitmap:(NSString *)filename intoIndex:(int)texIndex
{
	BOOL success = FALSE;
	NSBitmapImageRep *theImage;
	int bitsPPixel, bytesPRow;
	unsigned char *theImageData;
	int rowNum, destRowNum;
	
	theImage = [ NSBitmapImageRep imageRepWithContentsOfFile:filename ];
	if( theImage != nil )
	{
		bitsPPixel = [ theImage bitsPerPixel ];
		bytesPRow = [ theImage bytesPerRow ];
		if( bitsPPixel == 24 )        // No alpha channel
			texFormat[ texIndex ] = GL_RGB;
		else if( bitsPPixel == 32 )   // There is an alpha channel
			texFormat[ texIndex ] = GL_RGBA;
		texSize[ texIndex ].width = [ theImage pixelsWide ];
		texSize[ texIndex ].height = [ theImage pixelsHigh ];
		texBytes[ texIndex ] = calloc( bytesPRow * texSize[ texIndex ].height,
									   1 );
		if( texBytes[ texIndex ] != NULL )
		{
			success = TRUE;
			theImageData = [ theImage bitmapData ];
			destRowNum = 0;
			for( rowNum = texSize[ texIndex ].height - 1; rowNum >= 0;
				 rowNum--, destRowNum++ )
			{
				// Copy the entire row in one shot
				memcpy( texBytes[ texIndex ] + ( destRowNum * bytesPRow ),
						theImageData + ( rowNum * bytesPRow ),
						bytesPRow );
			}
		}
	}
	
	return success;
}

// Code from http://www.idevgames.com/forum/showthread.php?t=5750 and http://www.idevgames.com/forum/archive/index.php/t-8121.html
- (void)saveScreenShot {
    NSSize  size = [self frame].size;
	GLfloat zero = 0.0f;
	long    rowbytes = size.width * 4;
	rowbytes = (rowbytes + 3)& ~3;                  // ctx rowbytes is always multiple of 4, per glGrab
    NSBitmapImageRep *minicon = [[NSBitmapImageRep alloc]
                initWithBitmapDataPlanes:nil
							  pixelsWide:size.width
							  pixelsHigh:size.height
						   bitsPerSample:8
						 samplesPerPixel:3
								hasAlpha:NO
								isPlanar:NO
						  colorSpaceName:NSDeviceRGBColorSpace
							 bytesPerRow:rowbytes
							bitsPerPixel:32];
	
    [[NSOpenGLContext currentContext] makeCurrentContext];
    glFinish();                                                         // finish any pending OpenGL commands
	glPushAttrib(GL_ALL_ATTRIB_BITS);               // reset all properties that affect glReadPixels, in case app was using them
	glDisable(GL_COLOR_TABLE);
	glDisable(GL_CONVOLUTION_1D);
	glDisable(GL_CONVOLUTION_2D);
	glDisable(GL_HISTOGRAM);
	glDisable(GL_MINMAX);
	glDisable(GL_POST_COLOR_MATRIX_COLOR_TABLE);
	glDisable(GL_POST_CONVOLUTION_COLOR_TABLE);
	glDisable(GL_SEPARABLE_2D);
	
	glPixelMapfv(GL_PIXEL_MAP_R_TO_R, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_G_TO_G, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_B_TO_B, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_A_TO_A, 1, &zero);
	
	glPixelStorei(GL_PACK_SWAP_BYTES, 0);
	glPixelStorei(GL_PACK_LSB_FIRST, 0);
	glPixelStorei(GL_PACK_IMAGE_HEIGHT, 0);
	glPixelStorei(GL_PACK_ALIGNMENT, 4);    // force 4-byte alignment from RGBA framebuffer
	glPixelStorei(GL_PACK_ROW_LENGTH, 0);
	glPixelStorei(GL_PACK_SKIP_PIXELS, 0);
	glPixelStorei(GL_PACK_SKIP_ROWS, 0);
	glPixelStorei(GL_PACK_SKIP_IMAGES, 0);
	
	glPixelTransferi(GL_MAP_COLOR, 0);
	glPixelTransferf(GL_RED_SCALE, 1.0f);
	glPixelTransferf(GL_RED_BIAS, 0.0f);
	glPixelTransferf(GL_GREEN_SCALE, 1.0f);
	glPixelTransferf(GL_GREEN_BIAS, 0.0f);
	glPixelTransferf(GL_BLUE_SCALE, 1.0f);
	glPixelTransferf(GL_BLUE_BIAS, 0.0f);
	glPixelTransferf(GL_ALPHA_SCALE, 1.0f);
	glPixelTransferf(GL_ALPHA_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_RED_SCALE, 1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_RED_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_GREEN_SCALE,   1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_GREEN_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_BLUE_SCALE, 1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_BLUE_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_ALPHA_SCALE,   1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_ALPHA_BIAS, 0.0f);
	glReadPixels(0, 0, size.width, size.height, GL_RGBA, GL_UNSIGNED_INT_8_8_8_8, [minicon bitmapData]);
	glPopAttrib();
	
	// http://www.toodarkpark.org/computers/objc/AppKit/Classes/NSSavePanel.html
	NSSavePanel *sp;
	int runResult;
	sp = [NSSavePanel savePanel];
	[sp setRequiredFileType:@"tiff"];
	runResult = [sp runModalForDirectory:NSHomeDirectory() file:@""];
	if (runResult == NSOKButton) {
		// We need to flip the image, so lets do that here.
		NSImage *theImage = [[NSImage alloc] initWithSize:[minicon size]];
		NSImage *theImage2 = [[NSImage alloc] initWithSize:[minicon size]];
		[theImage addRepresentation:minicon];
		[theImage setFlipped:YES];
		[theImage2 lockFocus];
		[theImage compositeToPoint:NSZeroPoint operation:NSCompositeCopy];
		[theImage2 unlockFocus];
		[[theImage2 TIFFRepresentation] writeToFile:[sp filename] atomically:YES];
	} else {
		NSBeep();
		NSWindow *infoWindow;
		infoWindow = NSGetCriticalAlertPanel( @"Save failed",
											  @"Failed to save image",
											  @"OK", nil, nil );
		[ NSApp runModalForWindow:infoWindow ];
		[ infoWindow close ];
	}
	[minicon release];
}

- (void) saveFrameWithNumber:(int)num {
    NSSize  size = [self frame].size;
	GLfloat zero = 0.0f;
	long    rowbytes = size.width * 4;
	rowbytes = (rowbytes + 3)& ~3;                  // ctx rowbytes is always multiple of 4, per glGrab
    NSBitmapImageRep *minicon = [[NSBitmapImageRep alloc]
                initWithBitmapDataPlanes:nil
							  pixelsWide:size.width
							  pixelsHigh:size.height
						   bitsPerSample:8
						 samplesPerPixel:3
								hasAlpha:NO
								isPlanar:NO
						  colorSpaceName:NSDeviceRGBColorSpace
							 bytesPerRow:rowbytes
							bitsPerPixel:32];
	
    [[NSOpenGLContext currentContext] makeCurrentContext];
    glFinish();                                                         // finish any pending OpenGL commands
	glPushAttrib(GL_ALL_ATTRIB_BITS);               // reset all properties that affect glReadPixels, in case app was using them
	glDisable(GL_COLOR_TABLE);
	glDisable(GL_CONVOLUTION_1D);
	glDisable(GL_CONVOLUTION_2D);
	glDisable(GL_HISTOGRAM);
	glDisable(GL_MINMAX);
	glDisable(GL_POST_COLOR_MATRIX_COLOR_TABLE);
	glDisable(GL_POST_CONVOLUTION_COLOR_TABLE);
	glDisable(GL_SEPARABLE_2D);
	
	glPixelMapfv(GL_PIXEL_MAP_R_TO_R, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_G_TO_G, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_B_TO_B, 1, &zero);
	glPixelMapfv(GL_PIXEL_MAP_A_TO_A, 1, &zero);
	
	glPixelStorei(GL_PACK_SWAP_BYTES, 0);
	glPixelStorei(GL_PACK_LSB_FIRST, 0);
	glPixelStorei(GL_PACK_IMAGE_HEIGHT, 0);
	glPixelStorei(GL_PACK_ALIGNMENT, 4);    // force 4-byte alignment from RGBA framebuffer
	glPixelStorei(GL_PACK_ROW_LENGTH, 0);
	glPixelStorei(GL_PACK_SKIP_PIXELS, 0);
	glPixelStorei(GL_PACK_SKIP_ROWS, 0);
	glPixelStorei(GL_PACK_SKIP_IMAGES, 0);
	
	glPixelTransferi(GL_MAP_COLOR, 0);
	glPixelTransferf(GL_RED_SCALE, 1.0f);
	glPixelTransferf(GL_RED_BIAS, 0.0f);
	glPixelTransferf(GL_GREEN_SCALE, 1.0f);
	glPixelTransferf(GL_GREEN_BIAS, 0.0f);
	glPixelTransferf(GL_BLUE_SCALE, 1.0f);
	glPixelTransferf(GL_BLUE_BIAS, 0.0f);
	glPixelTransferf(GL_ALPHA_SCALE, 1.0f);
	glPixelTransferf(GL_ALPHA_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_RED_SCALE, 1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_RED_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_GREEN_SCALE,   1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_GREEN_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_BLUE_SCALE, 1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_BLUE_BIAS, 0.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_ALPHA_SCALE,   1.0f);
	glPixelTransferf(GL_POST_COLOR_MATRIX_ALPHA_BIAS, 0.0f);
	glReadPixels(0, 0, size.width, size.height, GL_RGBA, GL_UNSIGNED_INT_8_8_8_8, [minicon bitmapData]);
	glPopAttrib();
	
	// http://www.macdevcenter.com/pub/a/mac/2001/06/29/cocoa.html?page=2
	NSString *fileName = [[NSString alloc] initWithFormat:@"frame.%03i.tiff", num];
	
	// We need to flip the image, so lets do that here.
	NSImage *theImage = [[NSImage alloc] initWithSize:[minicon size]];
	NSImage *theImage2 = [[NSImage alloc] initWithSize:[minicon size]];
	[theImage addRepresentation:minicon];
	[theImage setFlipped:YES];
	[theImage2 lockFocus];
	[theImage compositeToPoint:NSZeroPoint operation:NSCompositeCopy];
	[theImage2 unlockFocus];
	[[theImage2 TIFFRepresentation] writeToFile:fileName atomically:YES];
	[minicon release];
}

@end
