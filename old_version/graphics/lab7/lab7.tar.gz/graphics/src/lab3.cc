#include "graphic.h"

int main(int argc, char *argv[])
{
  /*
  image im = image(500, 500, Pixel(255, 255, 255));
  
  polygon p = polygon(4);
  p.addPoint(point(0, 0));
  p.addPoint(point(200, 200));
  p.addPoint(point(500, 200));
  p.addPoint(point(500, 0));
  im.setPenPattern(image("../images/wood.ppm"));
  im.drawFilledGraphic(p);
 

  p = polygon(4);
  p.addPoint(point(0, 0));
  p.addPoint(point(200, 200));
  p.addPoint(point(200, 500));
  p.addPoint(point(0, 500));
  im.setPenPattern(image("../images/greenstone.ppm"));
  im.drawFilledGraphic(p);


  p = polygon(4);
  p.addPoint(point(200, 200));
  p.addPoint(point(500, 200));
  p.addPoint(point(500, 500));
  p.addPoint(point(200, 500));
  im.drawFilledGraphic(p);
  
  im.setPenColor(Pixel(0, 0, 0));
  im.setPenPattern(image("../images/wood2.ppm"));
  
  p = polygon(4);
  p.addPoint(point(200, 100));
  p.addPoint(point(210, 100));
  p.addPoint(point(210, 200));
  p.addPoint(point(200, 200));
  im.drawFilledGraphic(p);
  im.disablePattern();
  im.drawGraphic(p);

  p = polygon(4);
  p.addPoint(point(380, 100));
  p.addPoint(point(390, 100));
  p.addPoint(point(390, 200));
  p.addPoint(point(380, 200));
  im.enablePattern();
  im.drawFilledGraphic(p);
  im.disablePattern();
  im.drawGraphic(p);

  p = polygon(4);
  p.addPoint(point(260, 160));
  p.addPoint(point(270, 160));
  p.addPoint(point(270, 260));
  p.addPoint(point(260, 260));
  im.enablePattern();
  im.drawFilledGraphic(p);
  im.disablePattern();
  im.drawGraphic(p);

  p = polygon(4);
  p.addPoint(point(440, 160));
  p.addPoint(point(450, 160));
  p.addPoint(point(450, 260));
  p.addPoint(point(440, 260));
  im.enablePattern();
  im.drawFilledGraphic(p);
  im.disablePattern();
  im.drawGraphic(p);

  im.enablePattern();
  ellipse e = ellipse(point(310, 240), 180, 50);
  im.drawFilledGraphic(e);
  im.disablePattern();
  im.drawGraphic(e);
  im.enablePattern();
  e = ellipse(point(310, 250), 180, 50);
  im.drawFilledGraphic(e);
  im.disablePattern();
  im.drawGraphic(e);

  
  im.setPenPattern(image("../images/pboard.ppm"));
  p = polygon(4);
  p.addPoint(point(330, 330));
  p.addPoint(point(330, 430));
  p.addPoint(point(430, 430));
  p.addPoint(point(430, 330));
  im.drawFilledGraphic(p);

  image imStewie = image("../images/stewie.ppm");
  im.drawImage(340, 370, imStewie.scale(.05));
  
  image imBrian = image("../images/brian.ppm");
  im.drawImage(370, 340, imBrian.scale(.14));

  im.setPenColor(Pixel(0, 0, 0));
  circle c = circle(point(340 + imStewie.scale(.05).cols / 2, 370 + imStewie.scale(.05).rows - 5), 3);
  im.drawFilledGraphic(c);
  c = circle(point(370 + imBrian.scale(.14).cols / 2, 340 + imBrian.scale(.14).rows - 5), 3);
  im.drawFilledGraphic(c);

  im.writeImage("../images/lab3-portfolio1.ppm");
  */

  /*  
  image im = image(500, 500, Pixel(255, 255, 255));
  polygon p = polygon(7);
  p.addPoint(point(30 + 50, 30 + 50));
  p.addPoint(point(100 + 50, 30 + 50));
  p.addPoint(point(200 + 50, 80 + 50));
  p.addPoint(point(300 + 50, 180 + 50));
  p.addPoint(point(200 + 50, 100 + 50));
  p.addPoint(point(100 + 50, 400 + 50));
  p.addPoint(point(50 + 50, 100 + 50));
  im.setPenPattern(image("../images/stewie_head.ppm"));
  im.drawFilledGraphic(p);
  im.writeImage("../images/stewie1.ppm");
  
  image im2 = image(500, 500, Pixel(255, 255, 255));
  p = polygon(7);
  p.addPoint(point(30, 30));
  p.addPoint(point(100, 30));
  p.addPoint(point(200, 80));
  p.addPoint(point(300, 180));
  p.addPoint(point(200, 100));
  p.addPoint(point(100, 400));
  p.addPoint(point(50, 100));
  im2.setPenPattern(image("../images/stewie_head.ppm"));
  im2.drawFilledGraphic(p);
  im2.writeImage("../images/stewie2.ppm");
  */

  /*
  //Required Image 1
  image im = image(100, 100, Pixel(255, 255, 255));
  polygon p = polygon(7);
  p.addPoint(point(30, 30));
  p.addPoint(point(80, 40));
  p.addPoint(point(50, 60));
  p.addPoint(point(80, 80));
  p.addPoint(point(50, 80));
  p.addPoint(point(40, 70));
  p.addPoint(point(30, 80));
  im.drawFilledGraphic(p);
  */
  /*  
  image im = image(10, 10, Pixel(255, 255, 255));
  polygon p = polygon(4);
  p.addPoint(point(0, 0));
  p.addPoint(point(5, 0));
  p.addPoint(point(5, 5));
  p.addPoint(point(0, 5));
  im.drawFilledGraphic(p);
  im.scale(50).writeImage("../images/lab3.ppm");
  */

  /*
  image im = image(400, 400, Pixel(255, 255, 255));

  circle c = circle(point(100, 100), 44);
  //rect r = rect(point(25, 25), point(75, 75));
  im.setGradColor(Pixel(255, 0, 0), Pixel(0,0,0));
  im.setGradDirection(point(100, 100), point(145, 100));
  im.setGradMode(3);
  im.drawFilledGraphic(c);
  im.writeImage("../images/lab3.ppm");
  */
}






