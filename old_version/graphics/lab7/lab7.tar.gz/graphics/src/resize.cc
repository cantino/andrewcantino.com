#include "image.h"
#include <math.h>

// Scale tool for lab 1
// Andrew Cantino
// Will Moss
// 2004

int main (int argc, char *argv[]) {
  if(argc < 4) {
    cout << "Usage: resize <input file> <output file> <scale percent>\n";
    exit(-1);
  }

  image a = image(argv[1]);
  int t = atoi(argv[3]);
  (a.scale(t/100.0)).writeImage(argv[2]);
}
