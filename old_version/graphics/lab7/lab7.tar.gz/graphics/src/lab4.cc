#include "graphic.h"
#include "matrix.h"
#include <sstream>
#include <math.h>

matrix getVTM(point lowerLeft, point upperRight, int rows)
{
  matrix VTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);

  VTM.translate3D(-lowerLeft.x, -lowerLeft.y, 0);
  VTM.scale3D(double(rows) / (upperRight.y - lowerLeft.y));

  return VTM;
}

int main(int argc, char *argv[])
{
  // Andrew's Enterprise Code
  //matrix I = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  point3D box[4] = {point3D(0, 0, 0), point3D(1, 0, 0), point3D(1, 1, 0), point3D(0, 1, 0)};
  point3D center = point3D(0, 0, 0);
  point3D radius = point3D(1, 0, 0);
  //int imageNum = 10;
  double position = 400, scale = 1;
  for (int imageNum = 1; imageNum < 15; imageNum++) {
    image im = image("../images/nebula.ppm");
    for (int iNum = 1; iNum < 5; iNum++) {
      int t = (255 - 15*(14 - imageNum) - 25*((15 - imageNum)/15.0)*(4 - iNum));
      if (t < 0)
	im.setPenAlpha((unsigned char) 0);
      else
	im.setPenAlpha(t);
      position = 450 - 10*imageNum - 10*((15 - imageNum)/15.0)*iNum;
      scale = (imageNum + iNum)/2.0;
      matrix VTM = matrix::I;
      matrix GTM = matrix::I;
      GTM.rotate3Dz(3.1415/4);
      GTM.scale3D(scale);
      GTM.translate3D(position, position, 0);
      //GTM.rotate3Dz(point3D(im.cols/2,im.rows/2,0), imageNum*2*3.1415/24);
      {
	//Connectors
	matrix LTM = matrix::I;
	LTM.scale3D(2, 4.2, 0);
	LTM.translate3D(0, -2.1, 0);
	polygon p = polygon(4);
	for (int i = 0; i < 4; i++) {
	  p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
	}
	im.setPenColor(Pixel(150,150,150));
	im.drawFilledGraphic(p);
	//im.setPenColor(Pixel(255,255,255));
	//im.drawGraphic(p);
	
	// North Necell
	LTM = matrix::I;
	LTM.scale3D(5.5, 2, 0);
	LTM.translate3D(-1, 2, 0);
	p = polygon(4);
	for (int i = 0; i < 4; i++) {
	  p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
	}
	im.setPenColor(Pixel(200,200,200));
	im.drawFilledGraphic(p);
	//im.setPenColor(Pixel(255,255,255));
	//im.drawGraphic(p);
	
	// South Necell
	LTM = matrix::I;
	LTM.scale3D(5.5, 2, 0);
	LTM.translate3D(-1, -4, 0);
	p = polygon(4);
	for (int i = 0; i < 4; i++) {
	  p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
	}
	im.setPenColor(Pixel(200,200,200));
	im.drawFilledGraphic(p);
	//im.setPenColor(Pixel(255,255,255));
	//im.drawGraphic(p);
	
	//Body
	LTM = matrix::I;
	LTM.scale3D(4, 2, 0);
	LTM.translate3D(-2, -1, 0);
	p = polygon(4);
	for (int i = 0; i < 4; i++) {
	  p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
	}
	im.setPenColor(Pixel(150,150,150));
	im.drawFilledGraphic(p);
	//im.setPenColor(Pixel(255,255,255));
	//im.drawGraphic(p);
	
	// Dish
	LTM = matrix::I;
	LTM.translate3D(-4, 0, 0);
	LTM.scale3D(point3D(-4, 0, 0), 3);
	point3D r = VTM * GTM * LTM * radius;
	point3D c = VTM * GTM * LTM * center;
	double rad = sqrt(pow(r.x() - c.x(), 2) + pow(r.y() - c.y(), 2));
	circle circ = circle(c.getPoint(), rad);
	im.setGradColor(Pixel(255, 255, 255), Pixel(75,75,75));
	im.setGradDirection(c.getPoint(), point(c.x() + rad + 1, c.y()));
	im.setGradMode(1);
	im.drawFilledGraphic(circ);
      }
    }
    ostringstream osData;
    osData << imageNum;
    im.writeImage("../images/enterprise/e" + osData.str() + ".ppm");
    //im.writeImage("../images/lab4.ppm");
    
    }

  // Will's Xwing code.
  /*
  image im;
  point3D box[4] = {point3D(0, 0, 0), point3D(1, 0, 0), point3D(1, 1, 0), point3D(0, 1, 0)};
  
  image imBackground = image("../images/moon.ppm").scale(.21);
  
  for (int j = 40; j > 0; j--) {
    im = image(imBackground.cols, imBackground.rows, Pixel(0, 0, 0));
    im.drawImage(22.25 * (40 - j) - 445,0,imBackground);
    
    matrix VTM = getVTM(point(2.225 * j - 44.5, 0), point(2.225 * j + 10, 43), 430);
    //matrix VTM = getVTM(point(0, 0), point(43, 43), 430);
    
    matrix GTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    GTM.translate3D(29.7, 2.5, 1);
    GTM.rotate3Dz(point3D(32.2, 21.5, 0), j * (3.1415926 / 20));
    //GTM.scale3D(430 / double(43));

    im.setPenColor(Pixel(195, 195, 195));
    matrix LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(2, 4, 0);
    LTM.sheer3Dx(-.25);
    LTM.translate3D(2, 0, 0);
    polygon p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(2, 4, 0);
    LTM.sheer3Dx(.25);
    LTM.translate3D(1, 5, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(2, 1, 0);
    LTM.translate3D(1, 4, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);

    
    im.setPenColor(Pixel(105, 105, 105));
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, .5, 0);
    LTM.translate3D(0, 3.75, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, .5, 0);
    LTM.translate3D(0, 4.75, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, .5, 0);
    LTM.translate3D(2, -.25, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, .5, 0);
    LTM.translate3D(2, 8.75, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(1, .5, 0);
    LTM.translate3D(3.5, 7.75, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(1, .5, 0);
    LTM.translate3D(3.5, .75, 0);
    p = polygon(4);
    for (int i = 0; i < 4; i++) {
      p.addPoint((VTM * GTM * LTM * box[i]).getPoint());
    }
    im.drawFilledGraphic(p);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, 0, 0);
    LTM.translate3D(4.5, 0, 0);
    line l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    im.drawFilledGraphic(l);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(3, 0, 0);
    LTM.translate3D(4.5, 9, 0);
    l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    im.drawFilledGraphic(l);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(2, 0, 0);
    LTM.translate3D(4.5, 8, 0);
    l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    im.drawFilledGraphic(l);
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(2, 0, 0);
    LTM.translate3D(4.5, 1, 0);
    l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    im.drawFilledGraphic(l);
    
    p = polygon(3);

    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(6, 0, 0);
    LTM.rotate3Dz(.09);
    LTM.translate3D(3, 4, 0);
    l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    //im.drawFilledGraphic(l);
    p.addPoint((VTM * GTM * LTM * box[0]).getPoint());
    p.addPoint((VTM * GTM * LTM * box[1]).getPoint());
    
    LTM = matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
    LTM.scale3D(6, 0, 0);
    LTM.rotate3Dz(-.09);
    LTM.translate3D(3, 5, 0);
    l = line((VTM * GTM * LTM * box[0]).getPoint(), (VTM * GTM * LTM * box[1]).getPoint());
    //im.drawFilledGraphic(l);
    p.addPoint((VTM * GTM * LTM * box[0]).getPoint());

    im.setPenColor(Pixel(195, 195, 195));
    im.drawFilledGraphic(p);
      
    ostringstream osData;
    osData << j;
    im.writeImage("../images/xwing/xwing" + osData.str() + ".ppm");
  }
  */
}
