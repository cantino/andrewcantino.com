#include "image.h"
#include <math.h>

// Lab 1
// Andrew Cantino
// Will Moss
// 2004

// Compare function from http://www.cplusplus.com/ref/cstdlib/qsort.html
int compare (const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}

image bluescreen (char *path, double threshold, int shrinks, int feather);

int main (int argc, char *argv[]) {
  //if(argc > 3) {
  cout << "Usage: lab1\n(Edit the source to modify functionality.\nIt's simple!)\n";
  //  exit(-1);
  //}

  // Generate the composite image here...
  //image a = bluescreen("../images/P9020460-small.ppm", 15, 0, 3);
  //image test = image("../images/haze-small.ppm");
  //test.drawImage(500,200,a.scale(.61));
  //test.writeImage("../images/test.ppm");

  // Generate the composite image here...
  //image me = bluescreen("../images/P9020460-small.ppm", 5, 0, 2);
  //image a = image(me);
  //for (int i = 0; i < a.cols; i++) {
  //  for (int j = a.rows * 1 / 2; j < a.rows; j++) {
  //    a.setAlpha(i, j, 0);
  //  }
  //}
  //image test = image("../images/IMG_3341-small.ppm");
  //test.drawImage(290,123,a.rotate(-.08).scale(.125));
  //image b = image(a);
  //for (int i = 0; i < b.cols; i++) {
  //  for (int j = b.rows * 9 / 32; j < b.rows; j++) {
  //    b.setAlpha(i, j, 0);
  //  }
  //}
  //test.drawImage(780,110,b.rotate(-.08).scale(.1201));
  //test.drawImage(900, 570, me.rotate(-.7).scale(.3));
  //test.writeImage("../images/test.ppm");
  


  // Generate the composite image here...
  //image a = bluescreen("../images/P9020458-small.ppm", 15, 0, 2);
  //image test = image("../images/woods.ppm");
  //test.drawImage(-175,-5,a.scale(.8));
  //test.writeImage("../images/test.ppm");


  // Generate the composite image here...
  //image a = bluescreen("../images/Rushmore.ppm", 25, 2, 2);
  //cout << "got a (Rushmore)" << endl;
  //image b = bluescreen("../images/P9020458-small.ppm", 15, 0, 2);
  //cout << "got b (P-small)" << endl;
  //image c = bluescreen("../images/P9020459-small.ppm", 15, 0, 2);
  //cout << "got c (P2-small)" << endl;
  //image test = image("../images/Rushmore.ppm");
  //cout << "got test (Rushmore)" << endl;
  //image test = image(c.cols, c.rows, Pixel(255,0,0));
  //test.drawImage(715,95,b.rotate(.2).scale(.3));
  //test.drawImage(50,9,c.scale(.3));
  //cout << "drew b onto test" << endl;
  //test.drawImage(0,0,a);
  //test.drawImage(0,0,b);
  //test.drawImage(840, 580, b.rotate(-.7).scale(.4));
  //test.writeImage("../images/test.ppm");
  //cout << "wrote test to disk." << endl;
}

image bluescreen (char *path, double threshold, int shrinks, int feather)
{
  int i,j,total = 0;
  int minBlue = 10000, maxBlue = -10000;
  int r = 0, g = 0, b = 0;
  Pixel c;

  cout << "Doing bluescreen on " << path << endl;
  image a = image(path);
  cout << "Image has width " << a.cols << " and height " << a.rows << ".\n";

  //for (i = 5; i < a.cols - 5; i++)
  for (i = 5; i < a.cols / 2; i++)
    for (j = 5; j < 50; j++)
      {
	c = a.getPixel(i, j);
	total++;
	r += int(c.r); g += int(c.g); b += int(c.b);
	if (c.b < minBlue)
	  minBlue = c.b;
	if (c.b > maxBlue)
	  maxBlue = c.b;
      }

  r = r / total; g = g / total; b = b / total;

  int rsum = 0, gsum = 0, bsum = 0;
  for (i = 5; i < a.cols - 5; i++)
    for (j = 5; j < 50; j++)
      {
	c = a.getPixel(i, j);
	rsum += int(pow((int(c.r) - r),2));
	gsum += int(pow((int(c.g) - g),2));
	bsum += int(pow((int(c.b) - b),2));
      }
  int sdr = rsum / total - 1;
  int sdg = gsum / total - 1;
  int sdb = bsum / total - 1;

  cout << "Average color: (" << r << "," << g << "," << b << ")\n";
  cout << "Standard Deviation: (" << sdr << "," << sdg << "," << sdb << ")\n";
  cout << "Min blue: " << minBlue << endl;
  cout << "Max blue: " << maxBlue << endl;

  // Do the blue screening
  int dr, dg, db;
  for (i = 0; i < a.cols; i++)
    for (j = 0; j < a.rows; j++)
      {
	dr = int(pow(int(a.getPixel(i, j).r) - r, 2)/sdr);
	dg = int(pow(int(a.getPixel(i, j).g) - g, 2)/sdg);
	db = int(pow(int(a.getPixel(i, j).b) - b, 2)/sdb);
	// Add a border to get rid of edge glitches.
	if (i > 50 && i < a.cols - 50 && j > 5)
	  if (sqrt(dr*dr + dg*dg + db*db) > threshold)
	    a.setAlpha(i, j, 255);
	  else
	    a.setAlpha(i, j, 0);
	else
	  a.setAlpha(i, j, 0);
      }
  cout << "Did base bluescreen...\n";


  // Shrink the alpha mask to get rid of speckle.
  for (i = 0; i < shrinks; i++)
    a.shrinkAlpha();

  cout << "...did " << shrinks << " shrink(s)...\n";

  // Lets run a median filter over the alpha channel.
  // (There is probably a much better way to write this filter.)
  /*
  int hold[4];
  int k = 0, l = 0, t = 0, s = 0, max, min;
  for (i = 0; i < a.cols; i++)
    for (j = 0; j < a.rows; j++)
      {
	int p = 0;
	if (a.inImage(i - 1, j))
	  hold[p++] = a.getAlpha(i - 1, j);
	if (a.inImage(i + 1, j))
	  hold[p++] = a.getAlpha(i + 1, j);
	if (a.inImage(i, j - 1))
	  hold[p++] = a.getAlpha(i, j - 1);
	if (a.inImage(i, j + 1))
	  hold[p++] = a.getAlpha(i, j + 1);
	qsort(hold, p, sizeof(int), compare);

	a.setAlpha(i, j, int((hold[1] + hold[2])/2));
      }
  */

  // Feather the image by blending the alpha channel.
  // (Who likes for-loops??)
  int k = 0, l = 0, t = 0, s = 0;
  for (i = 0; i < a.cols; i++)
    for (j = 0; j < a.rows; j++)
      {
	t = 0;
	s = 0;
	for (k = i - feather; k <= i + feather; k++)
	  for (l = j - feather; l <= j + feather; l++)
	    if (a.inImage(k, l))
	      {
		t++;
		s += int(a.getAlpha(k, l));
	      }
	if (a.getAlpha(i, j) != 0)
	  a.setAlpha(i, j, s/t);
      }

  cout << "....and did feather.\n";

  // Feather the image by blending pixels that touch 0 alpha pixels
  // Not using this right now, since the above method seems to work better.
  /*
  int found;
  for (i = 0; i < a.cols; i++)
    for (j = 0; j < a.rows; j++)
      {
	found = 0;
	if (a.inImage(i - 1, j) && a.getAlpha(i - 1, j) == 0)
	  found++;
	if (a.inImage(i + 1, j) && a.getAlpha(i + 1, j) == 0)
	  found++;
	if (a.inImage(i, j - 1) && a.getAlpha(i, j - 1) == 0)
	  found++;
	if (a.inImage(i, j + 1) && a.getAlpha(i, j + 1) == 0)
	  found++;
	if (found > 0)
	  a.setAlpha(i, j, a.getAlpha(i, j)*found*.20);
      }

  */

  return a;
  //image test = image("../images/P9020460.ppm");
  //image test = image(a.cols, a.rows, Pixel(255,0,0));
  //test.drawImage(0,0,a);
  //test.writeImage(argv[2]);
}







