#ifndef VIEW_H
#define VIEW_H

#include "model.h"

class view3D {
 private:
  point3D vrp, vpn, vup;
  double d, du, dv, F, B;
  int screenX, screenY;

 public:
  view3D();
  void setCamera(point3D vrp, point3D vpn, point3D vup);
  void setProjectionDistance(double d);
  void setCameraSize(double du, double dv);
  void setClipPlanes(double F, double B);
  void project(model &m, image &i);
  void parallelProject(model &m, image &i);
};

struct edgeRecord3D {
  int yStart, yEnd;
  double xIntersect, dxPerScan, zIntersect, dzPerScan, dzPerColumn;
};

class polygonRef3D {
 public:
  point3D **points;
  int pointCount, n;
  bool filled;
  polygonRef3D();
  polygonRef3D(int n);
  polygonRef3D(const polygonRef3D &p);
  virtual ~polygonRef3D();
  polygonRef3D& operator= (const polygonRef3D &rhs);
  
  void setFilled(bool m);
  Pixel getColor();

  void addPoint(point3D *p);

  void drawZBuffer(image &im);

  friend std::ostream& operator<< (std::ostream &out, const polygonRef3D &p);
};

#endif
