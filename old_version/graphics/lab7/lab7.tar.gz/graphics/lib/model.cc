#include "model.h"

model::model() : logicFunction(NULL) {}

model::model(const model &p) : logicFunction(NULL)
{
  data = p.data;
}

model& model::operator= (const model &rhs)
{
  cerr << "Warning: model::operator= called.  This shouldn't happen!" << endl;
  if (this != &rhs) {
    data = rhs.data;
  }
  return *this;
}

model::~model() {
  for(std::list<modelItem*>::iterator iter = data.begin(); iter != data.end(); iter++) {
    if ((**iter).getName() != 0) {
      delete *iter;
    } else {
      //cerr << "Warning: model::~model not recursivly deleting included model." << endl;
    }
  }
}

int model::getName() {
  return 0;
}

void model::addItem(modelItem *i) {
  std::map<string, double> m = std::map<string, double>();

  data.push_back(i);
  if (i->getName() == 0)
    childMemory.push_back(m);
}

void model::addLogic(void (*logicFunction)(model&, std::map<string, double>&, std::list<modelItem*>&))
{
  this->logicFunction = logicFunction;
}

matrix model::drawList(matrix &GTM, image &im, std::list<modelItem*> &dataList)
{
  matrix newGTM;
  matrix LTM = matrix::I;  

  std::vector< std::map<string, double> >::iterator memoryIter = childMemory.begin();

  for(std::list<modelItem*>::iterator iter = dataList.begin(); iter != dataList.end(); iter++) {
    switch ((**iter).getName()) {
    case 0:  //Model
      newGTM = GTM * LTM;
      reinterpret_cast<model*>(*iter)->draw(newGTM, im, *memoryIter);
      memoryIter++;
      break;
    case 1:  //Model Primative
      newGTM = GTM * LTM;
      reinterpret_cast<modelPrimative*>(*iter)->draw(newGTM, im);
      break;
    case 2:  //Model Transform
      reinterpret_cast<modelTransform*>(*iter)->apply(LTM);
      break;
    case 3:  //Model Image
      reinterpret_cast<modelImage*>(*iter)->apply(im);
      break;
    }
  }
  return LTM;
}

void model::draw(matrix &GTM, image &im) {
  if (logicFunction != NULL) {
    std::map<string, double> m;
    std::list<modelItem*> newData;
    
    (*logicFunction)(*this, m, newData);
    drawList(GTM, im, newData); 
  }
  drawList(GTM, im, data);
}

void model::draw(matrix &GTM, image &im, std::map<string, double> &memory)
{
  if (logicFunction != NULL) {
    std::list<modelItem*> newData;
    matrix oldLTM, newGTM;

    (*logicFunction)(*this, memory, newData);
    
    oldLTM = drawList(GTM, im, newData);
    newGTM = oldLTM * GTM;
    drawList(newGTM, im, data);
  } else {
    drawList(GTM, im, data);
  }
}

matrix model::renderList(matrix &GTM, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, std::list<modelItem*> &dataList)
{
  matrix newGTM;
  matrix LTM = matrix::I;  

  std::vector< std::map<string, double> >::iterator memoryIter = childMemory.begin();

  for(std::list<modelItem*>::iterator iter = dataList.begin(); iter != dataList.end(); iter++) {
    switch ((**iter).getName()) {
    case 0:  //Model
      newGTM = GTM * LTM;
      reinterpret_cast<model*>(*iter)->render(newGTM, pointList, polygonList, *memoryIter);
      memoryIter++;
      break;
    case 1:  //Model Primative
      newGTM = GTM * LTM;
      reinterpret_cast<modelPrimative*>(*iter)->render(newGTM, pointList, polygonList);
      break;
    case 2:  //Model Transform
      reinterpret_cast<modelTransform*>(*iter)->apply(LTM);
      break;
      /*
    case 3:  //Model Image
      reinterpret_cast<modelImage*>(*iter)->apply(im);
      break;
      */
    }
  }
  return LTM;
}

void model::render(matrix &GTM, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, std::map<string, double> &memory)
{
  if (logicFunction != NULL) {
    std::list<modelItem*> newData;
    matrix oldLTM, newGTM;

    (*logicFunction)(*this, memory, newData);
    
    oldLTM = renderList(GTM, pointList, polygonList, newData);
    newGTM = oldLTM * GTM;
    renderList(newGTM, pointList, polygonList, data);
  } else {
    renderList(GTM, pointList, polygonList, data);
  }
}

void model::render(matrix &GTM, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  if (logicFunction != NULL) {
    std::list<modelItem*> newData;
    std::map<string, double> memory;

    matrix oldLTM, newGTM;

    (*logicFunction)(*this, memory, newData);
    
    oldLTM = renderList(GTM, pointList, polygonList, newData);
    newGTM = oldLTM * GTM;
    renderList(newGTM, pointList, polygonList, data);
  } else {
    renderList(GTM, pointList, polygonList, data);
  }
}








