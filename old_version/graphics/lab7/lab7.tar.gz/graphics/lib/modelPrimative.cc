#include "model.h"
#include "graphic.h"
#include <math.h>
#include "view.h"

// ----------- modelPrimative ----------

int modelPrimative::getName()
{
  return 1;
}

// -------------- point3D --------------

point3D::point3D() {}

point3D::point3D(double x, double y, double z) : color(Pixel(0, 0, 0))
{ data[0] = x; data[1] = y; data[2] = z; data[3] = 1; }

point3D::point3D(double x, double y, double z, double h) : color(Pixel(0, 0, 0))
{ data[0] = x; data[1] = y; data[2] = z; data[3] = h; }

point3D::point3D(double x, double y, double z, Pixel color)
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = 1;
  this->color = color;
}
point3D::point3D(double x, double y, double z, double h, Pixel color)
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = h;
  this->color = color;
}

Pixel point3D::getColor()
{
  return color;
}

void point3D::setColor(Pixel c)
{
  color = c;
}

double point3D::x() { return data[0] / data[3]; }
double point3D::y() { return data[1] / data[3]; }
double point3D::z() { return data[2] / data[3]; }
double point3D::depth() { return data[2]; }

point point3D::getPoint()
{
  return point(x(), y());
}

void point3D::normalize()
{
  double l = sqrt(data[0]*data[0] + data[1]*data[1] + data[2]*data[2]);
  data[0] = data[0] / l;
  data[1] = data[1] / l;
  data[2] = data[2] / l;
}

point3D point3D::normalized()
{
  double l = sqrt(data[0]*data[0] + data[1]*data[1] + data[2]*data[2]);
  return point3D(data[0] / l, data[1] / l, data[2] / l, data[3], color);
}

void point3D::draw(matrix &m, image &i)
{
  point p = (m * (*this)).getPoint();
  i.drawGraphic(p);
}
void point3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(1);
  pRef3D.setFilled(false);
  point3D *p3D = new point3D(m * (*this));
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);
  polygonList.push_back(pRef3D);
}

void point3D::operator*= (const matrix &rhs)
{
  *this = rhs * (*this);
}

point3D crossProduct(point3D a, point3D b)
{
  return point3D(a.y()*b.z() - b.y()*a.z(),
		 a.z()*b.x() - b.z()*a.x(),
		 a.x()*b.y() - b.x()*a.y(),
		 1);
}

// -------------- line3D ---------------

line3D::line3D() {}
line3D::line3D(point3D s, point3D e) : start(s), end(e) {}
void line3D::draw(matrix &m, image &i)
{
  line l = line((m * start).getPoint(), (m * end).getPoint());
  i.drawGraphic(l);
}
void line3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(2);
  pRef3D.setFilled(false);

  point3D *p3D = new point3D(m * start);
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);

  p3D = new point3D(m * end);
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);

  polygonList.push_back(pRef3D);

}

// ------------- polygon3D -------------

polygon3D::polygon3D() : points(NULL), filled(true) {}
polygon3D::polygon3D(int n) : pointCount(0), n(n), filled(true)
{
  points = new point3D[n];
}

polygon3D::polygon3D(const polygon3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polygon3D& polygon3D::operator= (const polygon3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polygon3D::~polygon3D()
{
  delete[] points;
}

void polygon3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
  }
}

void polygon3D::setFilled(bool m) { filled = m; }

void polygon3D::draw(matrix &m, image &im)
{
  polygon p = polygon(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());

  if (filled)
    im.drawFilledGraphic(p);
  else
    im.drawGraphic(p);
}

void polygon3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(pointCount);
  point3D *p3D;

  for (int i = 0; i < pointCount; i++) {
    p3D = new point3D(m * points[i]);
    pointList.push_back(p3D);
    pRef3D.addPoint(p3D);
  }

  polygonList.push_back(pRef3D);

}

// ------------ polyline3D -------------

polyline3D::polyline3D() : points(NULL) {}
polyline3D::polyline3D(int n) : pointCount(0), n(n)
{
  points = new point3D[n];
}

polyline3D::polyline3D(const polyline3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polyline3D& polyline3D::operator= (const polyline3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polyline3D::~polyline3D()
{
  delete[] points;
}

void polyline3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polyline." << endl;
  }
}

void polyline3D::draw(matrix &m, image &im)
{
  polyline p = polyline(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());
  im.drawGraphic(p);
}

// ------------ pyramid3D -------------

pyramid3D::pyramid3D() {}

pyramid3D::pyramid3D(point3D top, polygon3D base)
{
  this->top = top;
  this->base = base;
}

void pyramid3D::draw(matrix &m, image &i) {}

void pyramid3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  point3D *theHead = new point3D(m * top);
  pointList.push_back(theHead);
  polygonRef3D container = polygonRef3D(base.pointCount);
  for (int i = 0; i < base.pointCount; i++) {
    point3D *p3D = new point3D(m * base.points[i]);
    container.addPoint(p3D);
    pointList.push_back(p3D);
  }
  polygonList.push_back(container);
  for (int i = 0; i < base.pointCount - 1; i++) {
    polygonRef3D pRef3D = polygonRef3D(3);
    pRef3D.addPoint(container.points[i]);
    pRef3D.addPoint(container.points[i+1]);
    pRef3D.addPoint(theHead);
    polygonList.push_back(pRef3D);
  }
  polygonRef3D pRef3D = polygonRef3D(3);
  pRef3D.addPoint(container.points[base.pointCount - 1]);
  pRef3D.addPoint(container.points[0]);
  pRef3D.addPoint(theHead);
  polygonList.push_back(pRef3D);
}
