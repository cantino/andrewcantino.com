#include "view.h"
#include <vector>
#include <list>
#include <algorithm>

view3D::view3D() {}

void view3D::setCamera(point3D vrp, point3D vpn, point3D vup)
{
  this->vrp = vrp;
  this->vpn = vpn;
  this->vup = vup;
}

void view3D::setProjectionDistance(double d)
{
  this->d = d;
}

void view3D::setCameraSize(double du, double dv)
{
  this->du = du;
  this->dv = dv;
}

void view3D::setClipPlanes(double F, double B)
{
  this->F = F;
  this->B = B;
}

// Comparison function to compare two polygonRef3Ds.
bool polygonRef3D_gt (const polygonRef3D &x, const polygonRef3D &y)
{
  return x.points[0]->z() > y.points[0]->z();
}

void view3D::project(model &m, image &i)
{
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  //cout << VTM << endl;
  d = d / B;
  VTM.PerspProject(d);
  VTM.scale3D( - screenX / (2 * d), screenY / (2 * d), 1.0);
  VTM.translate3D(screenX / 2, screenY / 2, 0);

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  matrix mx = matrix::I;

  // Sort the polygonList
  polygonList.sort(polygonRef3D_gt);

  m.render(mx, pointList, polygonList);

  i.makeZBuffer(1.0/B);
  //i.makeZBuffer(0);
  //cout << VTM << endl;
  // Apply VTM to all points.
  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    **iter *= VTM;
  }

  // Draw all of the polygons in polygonList to the screen.
  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    //cout << *iter << endl;
    i.setPenColor(iter->getColor());
    iter->drawZBuffer(i);
  }

  //Translate the VRP to the origin: VTM = T(- vrp.x, - vrp.y, - vrp.z).
  //Align the coordinate axes:
  //  Normalize the VPN and VUP.
  //  Create UVEC = VUP x VPN.
  //  Redo VUP' = VPN x UVEC.
  //  VTM = RotateXYZ(UVEC, VUP', VPN) * VTM.
  //Translate the COP (represented by the projection distance) to the origin: VTM = T(0, 0, d) * VTM.
  //Scale to the canonical view volume [CVV]:
  //  Let B = B + d.
  //  VTM = Scale( 2 * d / (du * B), 2 * d / (dv * B), 1 / B) * VTM.
  //Project onto the image plane:
  //  Let d = d / B.
  //  VTM = PROJpersp(d) * VTM.
  //Scale to the image size*: VTM = Scale( - screenX / (2 * d), - screenY / (2 * d), 1.0) * VTM.
  //* As given this equation is for PPM images. For TIFF images don't invert the y coordinate.
  //Translate the lower left corner to the origin: VTM = T(screenX/2, screenY/2) * VTM.
}

void view3D::parallelProject(model &m, image &i)
{
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  VTM.ParallelProject();
  VTM.scale3D(-screenX / 2, screenY / 2, 1);
  VTM.translate3D(screenX / 2, screenY / 2, 0);

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  matrix mx = matrix::I;

  m.render(mx, pointList, polygonList);

  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    **iter *= VTM;
  }

  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    iter->drawZBuffer(i);
  }

  //Clear Point List
  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    delete *iter;
  }



}

// ------------- polygonRef3D -------------

polygonRef3D::polygonRef3D() : points(NULL), filled(true) {}

polygonRef3D::polygonRef3D(int n) : pointCount(0), n(n), filled(true)
{
  points = new point3D*[n];
}

polygonRef3D::polygonRef3D(const polygonRef3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D*[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polygonRef3D& polygonRef3D::operator= (const polygonRef3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D*[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polygonRef3D::~polygonRef3D()
{
  delete[] points;
}

void polygonRef3D::addPoint(point3D *p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
  }
}

void polygonRef3D::setFilled(bool m) { filled = m; }

Pixel polygonRef3D::getColor()
{
  long r = 0, g = 0, b = 0;
  for (int i = 0; i < pointCount; i++) {
    r += points[i]->getColor().r;
    g += points[i]->getColor().g;
    b += points[i]->getColor().b;
  }
  r = r / pointCount;
  g = g / pointCount;
  b = b / pointCount;

  //cout << "(" << r << ", " << g << ", " << b << ")\n";
  return Pixel(r, g, b);
}

std::ostream& operator<< (std::ostream &out, const polygonRef3D &p)
{
  for (int i = 0; i < p.pointCount; i++)
    {
      out << "(" << p.points[i]->x() << ", " << p.points[i]->y() << ", " << p.points[i]->z() << ") -> ";
    }
   out << "(" << p.points[0]->x() << ", " << p.points[0]->y() << ", " << p.points[0]->z() << ")";
  return out;
}

bool edgeRecord3D_lt (const edgeRecord3D *x, const edgeRecord3D *y)
{
  return x->xIntersect < y->xIntersect;
}

bool edgeRecord3D_eq (const edgeRecord3D *x, const edgeRecord3D *y)
{
  return int(x->xIntersect + 0.5) == int(y->xIntersect + 0.5);
}

void polygonRef3D::drawZBuffer(image &im)
{
  if (pointCount < 3) {
    cerr << "Too few points in the polygon\n" << endl;
  } else {
    std::list<edgeRecord3D*> activeEdgeList;
    int yStart = im.getRows(), yEnd = 0;
    edgeRecord3D *edges = new edgeRecord3D[pointCount];

    int next_pt, prev_pt;
    int edgeCount = 0;
    for (int j = 0; j < pointCount; j++) {
      next_pt = j < pointCount - 1 ? j + 1 : 0;
      prev_pt = j > 0 ? j - 1 : pointCount - 1;
      if (points[j]->y() != points[next_pt]->y()) {
	if (points[j]->y() < points[next_pt]->y()) {
	  edges[edgeCount].yStart = int(points[j]->y());
	  edges[edgeCount].yEnd = int(points[next_pt]->y() - 1);
	  edges[edgeCount].xIntersect = points[j]->x();
	  edges[edgeCount].zIntersect = 1.0 / points[j]->depth();
	  edges[edgeCount].dxPerScan = double(points[next_pt]->x() - points[j]->x()) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dzPerScan =  double(1.0 / points[next_pt]->depth() - 1.0 / points[j]->depth()) / (points[next_pt]->y() - points[j]->y());
	} else {
	  edges[edgeCount].yStart = int(points[next_pt]->y());
	  edges[edgeCount].yEnd = int(points[j]->y() - 1);
	  edges[edgeCount].xIntersect = points[next_pt]->x();
	  edges[edgeCount].zIntersect = 1.0 / points[next_pt]->depth();
	  edges[edgeCount].dxPerScan = double(points[next_pt]->x() - points[j]->x()) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dzPerScan = double(1.0 / points[next_pt]->depth() - 1.0 / points[j]->depth()) / (points[next_pt]->y() - points[j]->y());
	}
	if (edges[edgeCount].yStart < yStart) { yStart = edges[edgeCount].yStart; }
	if (edges[edgeCount].yEnd > yEnd) { yEnd = edges[edgeCount].yEnd; }
	edgeCount++;
      }
    }
  
    for (int j = yStart; j <= yEnd; j++) {

      //Build Active Edge List
      for (int k = 0; k < edgeCount; k++) {
	if ((edges[k].yStart <= j) && (edges[k].yEnd >= j)) {
	  activeEdgeList.push_back(&edges[k]);
	}
      }

      //Sort Active Edge List
      activeEdgeList.sort(edgeRecord3D_lt);

      //Draw Scan Line
      std::list<edgeRecord3D*>::iterator iterEnd = activeEdgeList.end();
      std::list<edgeRecord3D*>::iterator iter = activeEdgeList.begin();
      std::list<edgeRecord3D*>::iterator iterNext = activeEdgeList.begin(); iterNext++;
      //Pixel curColor = im.getPenColor();
      while ((iterNext != iterEnd) && (iter != iterEnd)) {
	double z = (**iter).zIntersect;
	double dzPerColumn =  double((**iter).zIntersect - (**iterNext).zIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	for (int i = int((**iter).xIntersect); i < (**iterNext).xIntersect; i++) {
	  //cout << "z = " << z << endl;
	  if (z > im.getZValue(i, j)) {
	    // im.drawPixel(i, j, Pixel((unsigned char)max(0,curColor.r - int((1/z)*10)),(unsigned char)max(0,curColor.g - int((1/z)*10)),(unsigned char)max(0,curColor.b - int((1/z)*10))));
	    im.drawPixel(i, j);
	    im.setZValue(i, j, z);
	  }
	  z += dzPerColumn;
	}

	iter++; iterNext++;
	if (iter == iterEnd) { break; }
	iter++; iterNext++;
      }
    
      iter = activeEdgeList.begin();
      for (iter = activeEdgeList.begin(); iter != activeEdgeList.end(); iter++) {
	(**iter).xIntersect += (**iter).dxPerScan;
	(**iter).zIntersect += (**iter).dzPerScan;
      }

      activeEdgeList.clear();
    }
    delete [] edges;
   
  }
}







