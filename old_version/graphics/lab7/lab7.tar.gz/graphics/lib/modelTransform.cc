#include "model.h"

int modelTransform::getName()
{
  return 2;
}

modelTranslate3D::modelTranslate3D(double tx, double ty, double tz)
{
  this->tx = tx;
  this->ty = ty;
  this->tz = tz;
}
void modelTranslate3D::apply(matrix &m)
{
  m.translate3D(tx, ty, tz);
}

modelScale3D::modelScale3D(double s)
{
  mode = 0;
  sx = s;
}
modelScale3D::modelScale3D(double sx, double sy, double sz)
{
  mode = 1;
  this->sx = sx;
  this->sy = sy;
  this->sz = sz;
}
modelScale3D::modelScale3D(point3D center, double s)
{
  mode = 2;
  this->center = center;
  sx = s;
}
modelScale3D::modelScale3D(point3D center, double sx, double sy, double sz)
{
  mode = 3;
  this->center = center;
  this->sx = sx;
  this->sy = sy;
  this->sz = sz;
}
void modelScale3D::apply(matrix &m)
{
  switch (mode) {
  case 0:
    m.scale3D(sx);
    break;
  case 1:
    m.scale3D(sx, sy, sz);
    break;
  case 2:
    m.scale3D(center, sx);
    break;
  case 3:
    m.scale3D(center, sx, sy, sz);
    break;
  }
}

modelRotate3Dx::modelRotate3Dx(double theta)
{
  mode = 0;
  this->theta = theta;
}
modelRotate3Dx::modelRotate3Dx(point3D center, double theta)
{
  mode = 1;
  this->center = center;
  this->theta = theta;
}
void modelRotate3Dx::apply(matrix &m)
{
  switch (mode) {
  case 0:
    m.rotate3Dx(theta);
    break;
  case 1:
    m.rotate3Dx(center, theta);
    break;
  }
}

modelRotate3Dy::modelRotate3Dy(double theta)
{
  mode = 0;
  this->theta = theta;
}
modelRotate3Dy::modelRotate3Dy(point3D center, double theta)
{
  mode = 1;
  this->center = center;
  this->theta = theta;
}
void modelRotate3Dy::apply(matrix &m)
{
  switch (mode) {
  case 0:
    m.rotate3Dy(theta);
    break;
  case 1:
    m.rotate3Dy(center, theta);
    break;
  }
}

modelRotate3Dz::modelRotate3Dz(double theta)
{
  mode = 0;
  this->theta = theta;
}
modelRotate3Dz::modelRotate3Dz(point3D center, double theta)
{
  mode = 1;
  this->center = center;
  this->theta = theta;
}
void modelRotate3Dz::apply(matrix &m)
{
  switch (mode) {
  case 0:
    m.rotate3Dz(theta);
    break;
  case 1:
    m.rotate3Dz(center, theta);
    break;
  }
}

modelAlignAxes3D::modelAlignAxes3D(point3D newX, point3D newY, point3D newZ)
{
  this->newX = newX;
  this->newY = newY;
  this->newZ = newZ;
}
void modelAlignAxes3D::apply(matrix &m)
{
  m.alignAxes3D(newX, newY, newZ);
}

modelSheer3Dx::modelSheer3Dx(double shy, double shxz)
{
  this->shy = shy;
  this->shz = shz;
}
void modelSheer3Dx::apply(matrix &m)
{
  m.sheer3Dx(shy, shz);  
}

modelSheer3Dy::modelSheer3Dy(double shx, double shz)
{
  this->shx = shx;
  this->shz = shz;
}
void modelSheer3Dy::apply(matrix &m)
{
  m.sheer3Dy(shx, shz);  
}

modelSheer3Dz::modelSheer3Dz(double shx, double shy)
{
  this->shx = shx;
  this->shy = shy;
}
void modelSheer3Dz::apply(matrix &m)
{
  m.sheer3Dz(shx, shy);  
}

modelMatrixReset::modelMatrixReset() {}
void modelMatrixReset::apply(matrix &m) { m = matrix::I; }
