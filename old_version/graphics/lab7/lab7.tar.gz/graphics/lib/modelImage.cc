#include "model.h"

int modelImage::getName()
{
  return 3;
}

modelSetPenColor::modelSetPenColor() {}
modelSetPenColor::modelSetPenColor(Pixel c) : color(c) {}
void modelSetPenColor::apply(image &i) { i.setPenColor(color); }

modelSetPenAlpha::modelSetPenAlpha() {}
modelSetPenAlpha::modelSetPenAlpha(unsigned char a) : alpha(a) {}
void modelSetPenAlpha::apply(image &i) { i.setPenAlpha(alpha); }

modelSetGradColor::modelSetGradColor() {}
modelSetGradColor::modelSetGradColor(Pixel c1, Pixel c2) : color1(c1), color2(c2) {}
void modelSetGradColor::apply(image &i) { i.setGradColor(color1, color2); }

modelSetGradDirection::modelSetGradDirection() {}
modelSetGradDirection::modelSetGradDirection(point d1, point d2) : d1(d1), d2(d2) {}
void modelSetGradDirection::apply(image &i) { i.setGradDirection(d1, d2); }

modelSetGradMode::modelSetGradMode() {}
modelSetGradMode::modelSetGradMode(int m) : m(m) {}
void modelSetGradMode::apply(image &i) { i.setGradMode(m); }

modelClearGradient::modelClearGradient() {}
void modelClearGradient::apply(image &i) { i.clearGradient(); }

modelSetPenPattern::modelSetPenPattern(image *im)
{
  this->im = im;
}
void modelSetPenPattern::apply(image &i)
{
  i.setPenPattern(*im);
}

modelSetPatternOrigin::modelSetPatternOrigin(point p)
{
  this->p = p;
}
void modelSetPatternOrigin::apply(image &i)
{
  i.setPatternOrigin(p);
}

modelDisablePattern::modelDisablePattern() {}
void modelDisablePattern::apply(image &i)
{
  i.disablePattern();
}

modelEnablePattern::modelEnablePattern() {}
void modelEnablePattern::apply(image &i)
{
  i.enablePattern();
}

modelClearPattern::modelClearPattern() {}
void modelClearPattern::apply(image &i)
{
  i.clearPattern();
}

modelDrawImage::modelDrawImage() {}
void modelDrawImage::apply(image &i)
{
  cerr << "Warning: modelDrawImage::apply not written yet, duffus." << endl;
}
