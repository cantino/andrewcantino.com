#include "graphic.h"

int main(int argc, char *argv[])
{
  image im = image(400, 400, Pixel(255, 255, 255));

  line l = line(point(0,160), point(86,160)); im.drawGraphic(l);
  l = line(point(380,160), point(400,160)); im.drawGraphic(l);
 
  polygon p = polygon(8);
  p.addPoint(point(60, 80));
  p.addPoint(point(340, 80));
  p.addPoint(point(340, 120));
  p.addPoint(point(280, 120));
  p.addPoint(point(240, 160));
  p.addPoint(point(160, 160));
  p.addPoint(point(120, 120));
  p.addPoint(point(60, 120));
  im.drawGraphic(p);

  p = polygon(4);
  p.addPoint(point(134, 120));
  p.addPoint(point(194, 120));
  p.addPoint(point(194, 150));
  p.addPoint(point(164, 150));
  im.drawGraphic(p);
  
  p = polygon(4);
  p.addPoint(point(208, 120));
  p.addPoint(point(268, 120));
  p.addPoint(point(238, 150));
  p.addPoint(point(208, 150));
  im.drawGraphic(p);

  polyline pl = polyline(4);
  pl.addPoint(point(340, 80));
  pl.addPoint(point(380, 140));
  pl.addPoint(point(380, 180));
  pl.addPoint(point(340, 120));
  im.drawGraphic(pl);

  pl = polyline(7);
  pl.addPoint(point(380, 180));
  pl.addPoint(point(320, 180));
  pl.addPoint(point(280, 220));
  pl.addPoint(point(200, 220));
  pl.addPoint(point(160, 180));
  pl.addPoint(point(100, 180));
  pl.addPoint(point(60, 120));
  im.drawGraphic(pl);

  im.gradFill(point(100, 150), Pixel(1, 1, 1));

  l  = line(point(280, 120), point(320, 180));
  im.drawGraphic(l);

  l  = line(point(240, 160), point(280, 220));
  im.drawGraphic(l);

  l  = line(point(200, 220), point(160, 160));
  im.drawGraphic(l);

  l  = line(point(160, 180), point(120, 120));
  im.drawGraphic(l);

  circle c = circle(point(120, 80), 20);
  im.drawFilledGraphic(c);
  c = circle(point(280, 80), 20);
  im.drawFilledGraphic(c);

  im.setPenColor(Pixel(200, 200, 200));
  c = circle(point(120, 80), 6);
  im.drawFilledGraphic(c);
  c = circle(point(280, 80), 6);
  im.drawFilledGraphic(c);

  im.setPenColor(Pixel(150, 150, 150));
  im.fill(point(62, 82), Pixel(0, 0, 0));
  im.fill(point(62, 122), Pixel(0, 0, 0));
  im.fill(point(210, 180), Pixel(0, 0, 0));
  im.fill(point(320, 140), Pixel(0, 0, 0));
  im.fill(point(350, 120), Pixel(0, 0, 0));
  

  im.gradFill(point(2, 180), Pixel(0, 0, 1));
  im.gradFill(point(2, 2), Pixel(1, 1, 0));
  im.gradFill(point(170, 140), Pixel(1, 1, 1));
  im.gradFill(point(220, 140), Pixel(1, 1, 1));

  im.writeImage("../images/3Dcar.ppm");
}
