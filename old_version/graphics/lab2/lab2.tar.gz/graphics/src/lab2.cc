#include "graphic.h"

int main(int argc, char *argv[])
{  
  // Required Image 1
  image im = image(120, 110, Pixel(255, 255, 255));
  line l = line(point(10, 10), point(50, 50)); im.drawGraphic(l);
  l = line(point(20, 10), point(50, 30)); im.drawGraphic(l);
  l = line(point(30, 10), point(60, 10)); im.drawGraphic(l);
  l = line(point(100, 100), point(50, 100)); im.drawGraphic(l);
  l = line(point(10, 100), point(10, 20)); im.drawGraphic(l);
  l = line(point(110, 10), point(110, 100)); im.drawGraphic(l);
  l = line(point(15, 20), point(36, 50)); im.drawGraphic(l);
  l = line(point(20, 20), point(40, 51)); im.drawGraphic(l);



  /*
  //Required Image 2
  image im = image(339, 160, Pixel(255, 255, 255));
  circle c = circle(point(100, 80), 20); im.drawGraphic(c);
  c = circle(point(100, 80), 42); im.drawGraphic(c);
  c = circle(point(100, 80), 51); im.drawGraphic(c);

  ellipse e = ellipse(point(250, 80), 20, 10); im.drawGraphic(e);
  e = ellipse(point(250, 80), 30, 20); im.drawGraphic(e);
  e = ellipse(point(250, 80), 40, 60); im.drawGraphic(e);
  */
  /*
  //Will's Portfolio Image 1
  image im = image(400, 400, Pixel(255, 255, 255));
  
  polygon p = polygon(6);
  p.addPoint(point(40, 100));
  p.addPoint(point(160, 40));
  p.addPoint(point(360, 82));
  p.addPoint(point(370, 360));
  p.addPoint(point(300, 370));
  p.addPoint(point(30, 320));
  im.drawGraphic(p);

  p = polygon(3);
  p.addPoint(point(240, 275));
  p.addPoint(point(310, 285));
  p.addPoint(point(290, 350));
  im.drawGraphic(p);
  circle c = circle(point(280, 300), 10);
  im.drawGraphic(c);
  im.gradFill(point(280,311), Pixel(1,0,0));

  c = circle(point(120, 270), 40);
  im.drawGraphic(c);
  p = polygon(3);
  p.addPoint(point(100, 250));
  p.addPoint(point(120, 255));
  p.addPoint(point(110, 270));
  im.drawGraphic(p); 
  im.gradFill(point(120,270), Pixel(0,1,0));

  p = polygon(7);
  p.addPoint(point(100, 150));
  p.addPoint(point(150, 110));
  p.addPoint(point(310, 165));
  p.addPoint(point(310, 190));
  p.addPoint(point(280, 190));
  p.addPoint(point(130, 150));
  p.addPoint(point(90, 185));
  im.drawGraphic(p);

  polyline pl = polyline(3);
  pl.addPoint(point(180, 200));
  pl.addPoint(point(210, 200));
  pl.addPoint(point(200, 250));
  im.drawGraphic(pl);
  
  im.setPenColor(Pixel(255, 222, 173));
  im.fill(point(50, 110), Pixel(0, 0, 0));
  //im.gradFill(point(1,1), Pixel(0,0,1));
  */

  /*
  // Will's Portfolio Image 2
  image im = image(480, 410, Pixel(255, 255, 255));
  rect r; line l;
  int k = 0;
  for (int j = 0; j < 410; j += 41) {
    if (k > 20) { k = 0; }
    im.setPenColor(Pixel(100, 100, 100));
    l = line(point(0, j - 1), point(480, j - 1));
    im.drawGraphic(l);
    im.setPenColor(Pixel(0, 0, 0));
    for (int i = 0; i < 480; i += 80) {
      r = rect(point(i + k, j), 40, 40);
      im.drawFilledGraphic(r);
    }
    k += 10;
  }
  */
  /*
  image im = image(400, 400, Pixel(255, 255, 255));

    // Andrew's portfolio 1
  im.gradFill(point(27, 30), Pixel(0, 10, 5));
  
  polygon p = polygon(7);
  p.addPoint(point(20,20));
  p.addPoint(point(350,70));
  p.addPoint(point(310,205));
  p.addPoint(point(205,385));
  p.addPoint(point(75,320));
  p.addPoint(point(20,50));
  im.setPenColor(Pixel(255,255,0));
  im.drawGraphic(p);
  im.setPenColor(Pixel(0,0,200));
  im.fill(point(200,200), Pixel(255,255,0));
  p = polygon(7);
  p.addPoint(point(40,40));
  p.addPoint(point(300,100));
  p.addPoint(point(250,105));
  p.addPoint(point(105,100));
  im.setPenColor(Pixel(0,0,255));
  im.drawGraphic(p);
  im.setPenColor(Pixel(0,200,200));
  im.gradFill(point(100,70), Pixel(255,0,0));
  circle c = circle(point(220,175), 35);
  im.drawFilledGraphic(c);
  im.setPenColor(Pixel(255,255,0));
  c = circle(point(400,400), 35);
  im.drawFilledGraphic(c);
  */

  /*
  // Andrew's portfolio 2
  image im = image(400, 400, Pixel(255,255,255));
  im.gradFill(point(27, 30), Pixel(0, 0, 5));
  circle c = circle(point(200, 200), 200);
  im.setPenColor(Pixel(255,255,0));
  im.drawFilledGraphic(c);
  ellipse e = ellipse(point(125, 250), 50, 20);
  im.setPenColor(Pixel(176, 226, 255));
  im.drawFilledGraphic(e);
  e = ellipse(point(275, 250), 50, 20);
  im.drawFilledGraphic(e);
  c = circle(point(125, 250), 20);
  im.setPenColor(Pixel(248, 248, 255));
  im.drawFilledGraphic(c);
  c = circle(point(275, 250), 20);
  im.drawFilledGraphic(c);
  polyline p = polyline(4);
  p.addPoint(point(200, 230));
  p.addPoint(point(175, 150));
  p.addPoint(point(200, 150));
  p.addPoint(point(200, 155));
  im.setPenColor(Pixel(47, 79, 79));
  im.drawGraphic(p);
  polygon n = polygon(10);
  n.addPoint(point(100, 120));
  n.addPoint(point(200, 100));
  n.addPoint(point(300, 120));
  im.drawGraphic(n);
  im.setPenColor(Pixel(255, 255, 240));
  im.fill(point(200,102), Pixel(47, 79, 79));
  */


  im.writeImage("../images/lab2.ppm");
}






