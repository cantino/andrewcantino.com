#include "graphic.h"
#include "image.h"

point::point()
{
  //cerr << "You should never be constructing an empty point!" << endl;
}

point::point(long x, long y)
{
  this->x = x;
  this->y = y;
}

point::point(const point &p)
{
  x = p.x;
  y = p.y;
}

inline bool point::operator== (point p) const
{
  return (p.x == x && p.y == y);
}

void point::draw(image &i)
{
  i.drawPixel(x, y);
}

void point::drawFilled(image &i)
{
  this->draw(i);
}

line::line()
{
  //cerr << "You should never be constructing an empty line!" << endl;
}

line::line(point start, point end) : start(start), end(end) {}

line::line(int x1, int y1, int x2, int y2) : start(point(x1, y1)), end(point(x2, y2)) {}

line::line(const line &l)
{
  start = l.start;
  end = l.end;
}

void line::draw(image &i)
{
  long x, y, dx, dy;

  if (start.x == end.x) {
    if (start.y < end.y) {
      for (int j = start.y; j < end.y; j++) {
	i.drawPixel(start.x - 1, j);
      }
    } else {
      for (int j = end.y; j < start.y; j++) {
	i.drawPixel(start.x, j);
      } 
    }
  } else if (start.y == end.y) {
    if (start.x < end.x) {
      for (int j = start.x; j < end.x; j++) {
	i.drawPixel(j, start.y);
      } 
    } else {
      for (int j = end.x; j < start.x; j++) {
	i.drawPixel(j, start.y - 1);
      }
    }
  } else {
    if (end.x > start.x) {
      x = start.x;
      y = start.y;
      dx = end.x - start.x;
      dy = end.y - start.y;
    } else {
      if (start.y < end.y) {
	start.y--;  end.y--;
      }
      x = end.x;
      y = end.y;
      dx = start.x - end.x;
      dy = start.y - end.y;
    }
    
    if (dy > 0) {
      if ((dy / dx) <= .5) {
	long e = 3 * dy - 2 * dx;
	for (int j = 0; j < dx; j++) {
	  i.drawPixel(x, y);
	  if (e > 0) {
	    y++;
	    e = e - 2 * dx;
	  }
	  x++;
	  e = e + 2 * dy;
	}
      } else if ((dy / dx) > .5) {
	long e = 3 * dx - 2 * dy;
	for (int j = 0; j < dy; j++) {
	  i.drawPixel(x, y);
	  if (e > 0) {
	    x++;
	    e = e - 2 * dy;
	  }
	  y++;
	  e = e + 2 * dx;
	}
      }
    } else {
      dy = -dy;
      if ((dy / dx) <= .5) {
	long e = 3 * dy - 2 * dx;
	for (int j = 0; j < dx; j++) {
	  i.drawPixel(x, y);
	  if (e > 0) {
	    y--;
	    e = e - 2 * dx;
	  }
	  x++;
	  e = e + 2 * dy;
	}
      } else if ((dy / dx) > .5) {
	long e = 3 * dx - 2 * dy;
	for (int j = 0; j < dy; j++) {
	  i.drawPixel(x, y);
	  if (e > 0) {
	    x++;
	    e = e - 2 * dy;
	  }
	  y--;
	  e = e + 2 * dx;
	}
      }
    }
  }
}

void line::drawFilled(image &i)
{
  this->draw(i);
}

rect::rect()
{
  cerr << "You should never be constructing an empty rectangle!" << endl;
}

rect::rect(point ll, point ur) : lowerL(ll), upperR(ur) {}

rect::rect(point ll, int width, int height) : lowerL(ll)
{
  upperR = point(ll.x + width, ll.y + height);
}

void rect::draw(image &i)
{
  line l = line(lowerL.x, lowerL.y, upperR.x, lowerL.y);
  i.drawGraphic(l);
  l = line(upperR.x, lowerL.y, upperR.x, upperR.y);
  i.drawGraphic(l);
  l = line(upperR.x, upperR.y, lowerL.x, upperR.y);
  i.drawGraphic(l);
  l = line(lowerL.x, upperR.y, lowerL.x, lowerL.y);
  i.drawGraphic(l);
}

void rect::drawFilled(image &i)
{
  int y = upperR.y - lowerL.y;
  line l;
  for (int j = 0; j < y; j++)
    {
      l = line(lowerL.x, lowerL.y + j, upperR.x, lowerL.y + j);
      i.drawGraphic(l);
    }
}

circle::circle()
{
  cerr << "You should never be constructing an empty circle!" << endl;
}
 
circle::circle(point c, double r) : center(c), r(r) {}

void circle::draw(image &i)
{
  // Modified code from Hearn and Baker, chapter 3, p. 102
  int x = -1;
  int y = -1*int(r);
  int p = int(1 - r);

  i.drawPixel(center.x + x, center.y + y);
  i.drawPixel(center.x - x - 1, center.y + y);
  i.drawPixel(center.x + x, center.y - y - 1);
  i.drawPixel(center.x - x - 1, center.y - y - 1);
  i.drawPixel(center.x + y, center.y + x);
  i.drawPixel(center.x - y - 1, center.y + x);
  i.drawPixel(center.x + y, center.y - x - 1);
  i.drawPixel(center.x - y - 1, center.y - x - 1);
  
  while (x > y) {
    x--;
    if (p < 0) { 
      p += -2 * x + 1;
    } else {
      y++;
      p += 2 * (y - x) + 1;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
    i.drawPixel(center.x + y, center.y + x);
    i.drawPixel(center.x - y - 1, center.y + x);
    i.drawPixel(center.x + y, center.y - x - 1);
    i.drawPixel(center.x - y - 1, center.y - x - 1);
  }
}

void circle::drawFilled(image &i)
{
  // Modified code from Hearn and Baker, chapter 3, p. 102
  int x = -1;
  int y = -1*int(r);
  int p = int(1 - r);

  i.drawPixel(center.x + x, center.y + y);
  i.drawPixel(center.x - x - 1, center.y + y);
  i.drawPixel(center.x + x, center.y - y - 1);
  i.drawPixel(center.x - x - 1, center.y - y - 1);
  i.drawPixel(center.x + y, center.y + x);
  i.drawPixel(center.x - y - 1, center.y + x);
  i.drawPixel(center.x + y, center.y - x - 1);
  i.drawPixel(center.x - y - 1, center.y - x - 1);

  line l = line(center.x + y + 1, center.y - x - 1, center.x - y - 1, center.y - x - 1);
  i.drawGraphic(l);
  
  l = line(center.x + y + 1, center.y + x, center.x - y - 1, center.y + x);
  i.drawGraphic(l);
  
  while (x > y) {
    x--;
    if (p < 0) { 
      p += -2 * x + 1;
    } else {
      y++;
      p += 2 * (y - x) + 1;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
    i.drawPixel(center.x + y, center.y + x);
    i.drawPixel(center.x - y - 1, center.y + x);
    i.drawPixel(center.x + y, center.y - x - 1);
    i.drawPixel(center.x - y - 1, center.y - x - 1);
    
    line l = line(center.x + x + 1, center.y + y, center.x - x - 1, center.y + y);
    i.drawGraphic(l);
    
    l = line(center.x + x + 1, center.y - y - 1, center.x - x - 1, center.y - y - 1);
    i.drawGraphic(l);
    
    l = line(center.x + y + 1, center.y - x - 1, center.x - y - 1, center.y - x - 1);
    i.drawGraphic(l);
    
    l = line(center.x + y + 1, center.y + x, center.x - y - 1, center.y + x);
    i.drawGraphic(l);
  }
}

ellipse::ellipse()
{
  cerr << "You should never be constructing an empty elipse!" << endl;
}

ellipse::ellipse(point c, int rx, int ry) : center(c), rx(rx), ry(ry) {}

void ellipse::draw(image &i)
{
  // Modified code from Hearn and Baker. chapter 3, p. 109-110
  int rx2 = rx*rx;
  int ry2 = ry*ry;
  int twoRx2 = 2*rx2;
  int twoRy2 = 2*ry2;
  int p;
  int x = -1;
  int y = -1*ry;
  int px = twoRy2;
  int py = twoRx2 * -y;

  /* Plot the first set of points */
  i.drawPixel(center.x + x, center.y + y);
  i.drawPixel(center.x - x - 1, center.y + y);
  i.drawPixel(center.x + x, center.y - y - 1);
  i.drawPixel(center.x - x - 1, center.y - y - 1);

  /* Region 1 */
  p = (int)((ry2 - (rx2 * ry) + (0.25 * rx2)) + .5);
  p += ry2 + px;
  while (px < py) {
    x--;
    px += twoRy2;
    if (p < 0)
      p += ry2 + px;
    else {
      y++;
      py -= twoRx2;
      p += ry2 + px - py;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
  }

  /* Region 2 */
  p = (int)((ry2*(x+0.5)*(x+0.5) + rx2*(y-1)*(y-1) - rx2*ry2) + .5);
  p += rx2 - py;
  while (y < 0) {
    y++;
    py -= twoRx2;
    if (p > 0) 
      p += rx2 - py;
    else {
      x--;
      px += twoRy2;
      p += rx2 - py + px;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
  }
}

void ellipse::drawFilled(image &i)
{
  // Modified code from Hearn and Baker. chapter 3, p. 109-110
  int rx2 = rx*rx;
  int ry2 = ry*ry;
  int twoRx2 = 2*rx2;
  int twoRy2 = 2*ry2;
  int p;
  int x = -1;
  int y = -1*ry;
  int px = twoRy2;
  int py = twoRx2 * -y;

  /* Plot the first set of points */
  i.drawPixel(center.x + x, center.y + y);
  i.drawPixel(center.x - x - 1, center.y + y);
  i.drawPixel(center.x + x, center.y - y - 1);
  i.drawPixel(center.x - x - 1, center.y - y - 1);

  /* Region 1 */
  p = (int)((ry2 - (rx2 * ry) + (0.25 * rx2)) + .5);
  p += ry2 + px;
  while (px < py) {
    x--;
    px += twoRy2;
    if (p < 0)
      p += ry2 + px;
    else {
      y++;
      py -= twoRx2;
      p += ry2 + px - py;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
    line l = line(center.x + x + 1, center.y + y, center.x - x - 1, center.y + y);
    i.drawGraphic(l);
    l = line(center.x + x + 1, center.y - y - 1, center.x - x - 1, center.y - y - 1);
    i.drawGraphic(l);
  }

  /* Region 2 */
  p = (int)((ry2*(x+0.5)*(x+0.5) + rx2*(y-1)*(y-1) - rx2*ry2) + .5);
  p += rx2 - py;
  while (y < 0) {
    y++;
    py -= twoRx2;
    if (p > 0) 
      p += rx2 - py;
    else {
      x--;
      px += twoRy2;
      p += rx2 - py + px;
    }
    i.drawPixel(center.x + x, center.y + y);
    i.drawPixel(center.x - x - 1, center.y + y);
    i.drawPixel(center.x + x, center.y - y - 1);
    i.drawPixel(center.x - x - 1, center.y - y - 1);
    line l = line(center.x + x + 1, center.y + y, center.x - x - 1, center.y + y);
    i.drawGraphic(l);
    l = line(center.x + x + 1, center.y - y - 1, center.x - x - 1, center.y - y - 1);
    i.drawGraphic(l);
  }
}

polyline::polyline()
{
  cerr << cerr << "You should never be constructing an empty polyline!" << endl;
}

polyline::polyline(int n) : pointCount(0), n(n)
{
  points = new point[n];
}

polyline::~polyline()
{
  free(points);
}

void polyline::addPoint(point p)
{
  if (pointCount < n) {
    points[pointCount++] = point(p.x, p.y);
  } else {
    cerr << "You cannot add more than " << n << " points to this polyline." << endl;
  }
}

void polyline::draw(image &i)
{
  line l;
  for (int j = 0; j < pointCount - 1; j++) {
    l = line(points[j], points[j + 1]);
    i.drawGraphic(l);
  }
}

void polyline::drawFilled(image &i)
{
  cerr << "Filled Polyline not yet implemented" << endl;
}

polygon::polygon()
{
  cerr << cerr << "You should never be constructing an empty polygon!" << endl;
}

polygon::polygon(int n) : pointCount(0), n(n)
{
  points = new point[n];
}

polygon::~polygon()
{
  free(points);
}

void polygon::addPoint(point p)
{
  if (pointCount < n) {
    points[pointCount++] = point(p.x, p.y);
  } else {
    cerr << "You cannot add more than " << n << " points to this polygon." << endl;
  }
}

void polygon::draw(image &i)
{
  line l;
  for (int j = 0; j < pointCount - 1; j++) {
    l = line(points[j], points[j + 1]);
    i.drawGraphic(l);
  }
  l = line(points[pointCount - 1], points[0]);
  i.drawGraphic(l);
}

void polygon::drawFilled(image &i)
{
  cerr << "Filled Polygon not yet implemented" << endl;
}
