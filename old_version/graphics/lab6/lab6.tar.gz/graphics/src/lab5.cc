#include "model.h"
#include <math.h>
#include <sstream>

matrix getVTM(point lowerLeft, point upperRight, int rows)
{
  matrix VTM = matrix::I;

  VTM.translate3D(-lowerLeft.x, -lowerLeft.y, 0);
  VTM.scale3D(double(rows) / (upperRight.y - lowerLeft.y));

  return VTM;
}

int main(int argc, char *argv[])
{
  model plane;
  // Used outline of http://www.owls.lib.wi.us/services/graphic_arts/diecuts/airplane.gif
  // Coords gathered in Photoshop manually.
  polygon3D *p = new polygon3D(37);
  p->addPoint(point3D(16, 400 - 125, 0));
  p->addPoint(point3D(19, 400 - 139, 0));
  p->addPoint(point3D(60, 400 - 161, 0));
  p->addPoint(point3D(97, 400 - 178, 0));
  p->addPoint(point3D(142, 400 - 192, 0));
  p->addPoint(point3D(279, 400 - 359, 0));
  p->addPoint(point3D(319, 400 - 356, 0));
  p->addPoint(point3D(222, 400 - 198, 0));
  p->addPoint(point3D(353, 400 - 218, 0));
  p->addPoint(point3D(366, 400 - 215, 0));
  p->addPoint(point3D(378, 400 - 204, 0));
  p->addPoint(point3D(415, 400 - 234, 0));
  p->addPoint(point3D(432, 400 - 233, 0));
  p->addPoint(point3D(387, 400 - 192, 0));
  p->addPoint(point3D(413, 400 - 160, 0));
  p->addPoint(point3D(399, 400 - 153, 0));
  p->addPoint(point3D(388, 400 - 154, 0));
  p->addPoint(point3D(365, 400 - 169, 0));
  p->addPoint(point3D(349, 400 - 135, 0));
  p->addPoint(point3D(339, 400 - 134, 0));
  p->addPoint(point3D(348, 400 - 176, 0));
  p->addPoint(point3D(341, 400 - 183, 0));
  p->addPoint(point3D(230, 400 - 147, 0));
  p->addPoint(point3D(188, 400 - 127, 0));
  p->addPoint(point3D(182, 400 - 89, 0));
  p->addPoint(point3D(182, 400 - 50, 0));
  p->addPoint(point3D(184, 400 - 30, 0));
  p->addPoint(point3D(166, 400 - 22, 0));
  p->addPoint(point3D(133, 400 - 104, 0));
  p->addPoint(point3D(113, 400 - 98, 0));
  p->addPoint(point3D(94, 400 - 100, 0));
  p->addPoint(point3D(81, 400 - 105, 0));
  p->addPoint(point3D(56, 400 - 106, 0));
  p->addPoint(point3D(28, 400 - 113, 0));
  p->addPoint(point3D(18, 400 - 121, 0));
  plane.addItem(p);
  
  // Balloon traces from http://www.launchyourlife.com/hot%20air%20balloon%202.gif
  model balloon;
  polygon3D *c = new polygon3D(27);
  c->addPoint(point3D(126, 400 - 1, 0));
  c->addPoint(point3D(103, 400 - 5, 0));
  c->addPoint(point3D(76, 400 - 11, 0));
  c->addPoint(point3D(45, 400 - 27, 0));
  c->addPoint(point3D(19, 400 - 51, 0));
  c->addPoint(point3D(4, 400 - 83, 0));
  c->addPoint(point3D(1, 400 - 112, 0));
  c->addPoint(point3D(10, 400 - 152, 0));
  c->addPoint(point3D(38, 400 - 206, 0));
  c->addPoint(point3D(80, 400 - 260, 0));
  c->addPoint(point3D(109, 400 - 299, 0));
  c->addPoint(point3D(123, 400 - 303, 0));
  c->addPoint(point3D(152, 400 - 303, 0));
  c->addPoint(point3D(159, 400 - 294, 0));
  c->addPoint(point3D(169, 400 - 277, 0));
  c->addPoint(point3D(197, 400 - 241, 0));
  c->addPoint(point3D(232, 400 - 191, 0));
  c->addPoint(point3D(250, 400 - 152, 0));
  c->addPoint(point3D(256, 400 - 124, 0));
  c->addPoint(point3D(257, 400 - 93, 0));
  c->addPoint(point3D(247, 400 - 61, 0));
  c->addPoint(point3D(224, 400 - 33, 0));
  c->addPoint(point3D(184, 400 - 10, 0));
  c->addPoint(point3D(156, 400 - 4, 0));
  c->addPoint(point3D(134, 400 - 1, 0));
  balloon.addItem(c);

  model basket;
  polygon3D *b = new polygon3D(5);
  b->addPoint(point3D(121, 400 - 355, 0));
  b->addPoint(point3D(146, 400 - 355, 0));
  b->addPoint(point3D(147, 400 - 337, 0));
  b->addPoint(point3D(133, 400 - 312, 0));
  b->addPoint(point3D(121, 400 - 335, 0));
  basket.addItem(b);


  model balloons;
  balloons.addItem(new modelSetPenColor(Pixel(255,0,0)));
  balloons.addItem(new modelScale3D(.4));
  balloons.addItem(&balloon);
  balloons.addItem(new modelSetPenColor(Pixel(250,200,200)));
  balloons.addItem(&basket);
  balloons.addItem(new modelTranslate3D(100,50,0));
  balloons.addItem(new modelSetPenColor(Pixel(0,255,0)));
  balloons.addItem(&balloon);
  balloons.addItem(new modelSetPenColor(Pixel(200,250,200)));
  balloons.addItem(&basket);
  balloons.addItem(new modelTranslate3D(-25, 150, 0));
  balloons.addItem(new modelSetPenColor(Pixel(0,0,255)));
  balloons.addItem(&balloon);
  balloons.addItem(new modelSetPenColor(Pixel(200,200,250)));
  balloons.addItem(&basket);

  model planes;
  planes.addItem(new modelSetPenColor(Pixel(255,0,0)));
  planes.addItem(new modelScale3D(.25));
  planes.addItem(&plane);
  planes.addItem(new modelMatrixReset());
  planes.addItem(new modelSetPenColor(Pixel(255,255,0)));
  planes.addItem(new modelScale3D(.2));
  planes.addItem(new modelTranslate3D(120, 5, 0));
  planes.addItem(&plane);
  planes.addItem(new modelMatrixReset());
  planes.addItem(new modelSetPenColor(Pixel(0,0,255)));
  planes.addItem(new modelScale3D(.18));
  planes.addItem(new modelTranslate3D(220, 20, 0));
  planes.addItem(&plane);

  model planes2;
  planes2.addItem(new modelSetPenColor(Pixel(255,0,0)));
  planes2.addItem(new modelScale3D(-.25, .25, 1));
  planes2.addItem(&plane);
  planes2.addItem(new modelMatrixReset());
  planes2.addItem(new modelSetPenColor(Pixel(255,255,0)));
  planes2.addItem(new modelScale3D(-.19, .19, 1));
  planes2.addItem(new modelTranslate3D(120, 50, 0));
  planes2.addItem(&plane);
  planes2.addItem(new modelMatrixReset());
  planes2.addItem(new modelSetPenColor(Pixel(0,0,255)));
  planes2.addItem(new modelScale3D(-.28, .28, 1));
  planes2.addItem(new modelTranslate3D(200, -50, 0));
  planes2.addItem(&plane);

  image im = image(400, 400, Pixel(255,255,255));
  matrix VTM = getVTM(point(0, 0), point(400, 400), im.getRows());
  model scene;
  scene.addItem(new modelScale3D(.8));
  scene.addItem(new modelTranslate3D(100, 20, 0));
  scene.addItem(new modelSetPenColor(Pixel(255,0,0)));
  scene.addItem(&balloon);
  scene.addItem(new modelSetPenColor(Pixel(250,200,200)));
  scene.addItem(&basket);
  scene.draw(VTM, im);
  im.writeImage("../images/lab5.ppm");

  /*
  for (int imageNum = 0; imageNum < 30; imageNum++)
    {
      // Clouds from http://www.bigfoto.com/sites/galery/sky/08_sky-clouds-x.jpg
      image im = image("../images/clouds.ppm");
      matrix VTM = getVTM(point(0, 0), point(400, 400), im.getRows());
      model scene;
      
      scene.addItem(new modelTranslate3D(620 - imageNum*35, 200 - imageNum, 0));
      scene.addItem(&planes);
      
      scene.addItem(new modelMatrixReset());
      scene.addItem(new modelTranslate3D(-200 + imageNum*32, 100 + imageNum/2.0, 0));
      scene.addItem(&planes2);
      
      scene.addItem(new modelMatrixReset());
      scene.addItem(new modelScale3D(.5 - imageNum/70.0));
      scene.addItem(new modelTranslate3D(100 + imageNum/2.0, -200 + imageNum*25, 0));
      scene.addItem(&balloons);
      
      
      scene.draw(VTM, im);
      ostringstream osData;
      osData.width(2);
      osData.fill('0');
      osData.setf(ios::right, ios::adjustfield);
      osData << imageNum;
      im.writeImage("../images/animation/" + osData.str() + ".ppm");
      //im.writeImage("../images/lab5.ppm");
    }
  */
}
