#ifndef VIEW_H
#define VIEW_H

#include "model.h"

class view3D {
 private:
  point3D vrp, vpn, vup;
  double d, du, dv, F, B;
  int screenX, screenY;

 public:
  view3D();
  void setCamera(point3D vrp, point3D vpn, point3D vup);
  void setProjectionDistance(double d);
  void setCameraSize(double du, double dv);
  void setClipPlanes(double F, double B);
  void project(model &m, image &i);
  void parallelProject(model &m, image &i);
};

#endif
