#include "view.h"

view3D::view3D() {}

void view3D::setCamera(point3D vrp, point3D vpn, point3D vup)
{
  this->vrp = vrp;
  this->vpn = vpn;
  this->vup = vup;
}

void view3D::setProjectionDistance(double d)
{
  this->d = d;
}

void view3D::setCameraSize(double du, double dv)
{
  this->du = du;
  this->dv = dv;
}

void view3D::setClipPlanes(double F, double B)
{
  this->F = F;
  this->B = B;
}

void view3D::project(model &m, image &i)
{
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  cout << VTM << endl;
  cout << VTM << endl;
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  cout << VTM << endl;
  d = d / B;
  VTM.PerspProject(d);
  cout << VTM << endl;
  VTM.scale3D( - screenX / (2 * d), screenY / (2 * d), 1.0);
  VTM.translate3D(screenX / 2, screenY / 2, 0);
  cout << VTM << endl;

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  matrix mx = matrix::I;

  m.render(mx, pointList, polygonList);

  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    //cout << **iter << " --> ";
    **iter *= VTM;
    //cout << **iter << endl;
  }

  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    iter->draw(i);
  }


  //Translate the VRP to the origin: VTM = T(- vrp.x, - vrp.y, - vrp.z).
  //Align the coordinate axes:
  //  Normalize the VPN and VUP.
  //  Create UVEC = VUP x VPN.
  //  Redo VUP' = VPN x UVEC.
  //  VTM = RotateXYZ(UVEC, VUP', VPN) * VTM.
  //Translate the COP (represented by the projection distance) to the origin: VTM = T(0, 0, d) * VTM.
  //Scale to the canonical view volume [CVV]:
  //  Let B = B + d.
  //  VTM = Scale( 2 * d / (du * B), 2 * d / (dv * B), 1 / B) * VTM.
  //Project onto the image plane:
  //  Let d = d / B.
  //  VTM = PROJpersp(d) * VTM.
  //Scale to the image size*: VTM = Scale( - screenX / (2 * d), - screenY / (2 * d), 1.0) * VTM.
  //* As given this equation is for PPM images. For TIFF images don't invert the y coordinate.
  //Translate the lower left corner to the origin: VTM = T(screenX/2, screenY/2) * VTM.
}

void view3D::parallelProject(model &m, image &i)
{
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  cout << VTM << endl;
  cout << VTM << endl;
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  cout << VTM << endl;
  VTM.ParallelProject();
  cout << VTM << endl;
  VTM.scale3D(-screenX / 2, screenY / 2, 1);
  VTM.translate3D(screenX / 2, screenY / 2, 0);
  cout << VTM << endl;

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  matrix mx = matrix::I;

  m.render(mx, pointList, polygonList);

  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    **iter *= VTM;
  }

  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    iter->draw(i);
  }

}





