#include "view.h"
#include <vector>
#include <list>
#include <algorithm>
#include <math.h>

view3D::view3D() {}

void view3D::setCamera(point3D vrp, point3D vpn, point3D vup)
{
  this->vrp = vrp;
  this->vpn = vpn;
  this->vup = vup;
}

void view3D::setProjectionDistance(double d)
{
  this->d = d;
}

void view3D::setCameraSize(double du, double dv)
{
  this->du = du;
  this->dv = dv;
}

void view3D::setClipPlanes(double F, double B)
{
  this->F = F;
  this->B = B;
}

void view3D::setAmbientLight(colorVector Ia)
{
  this->Ia = Ia;
}

// Comparison function to compare two polygonRef3Ds.
bool polygonRef3D_gt (const polygonRef3D &x, const polygonRef3D &y)
{
  return x.points[0]->z() > y.points[0]->z();
}

void view3D::project(model &m, image &i)
{
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  d = d / B;

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  list<modelLight> lightList;
  matrix mx = matrix::I;

  m.render(mx, pointList, polygonList, lightList);

  // Sort the polygonList
  polygonList.sort(polygonRef3D_gt);

  i.makeZBuffer(1.0/B);

  // Apply VTM to all points.
  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    cout << "point before: " << (**iter) << endl;
    **iter *= VTM;
    cout << "point: " << (**iter) << endl;
    (**iter).archive();
  }

  for (list<modelLight>::iterator iter = lightList.begin(); iter != lightList.end(); iter++) {
    cout << "light before: " << iter->loc << endl;
    iter->loc *= VTM;
    cout << "light: " << iter->loc << endl;
    iter->loc.archive();
  }

  // Find a normal for all polygons, using the now transformed points.
  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {  
    cout << "poly: " << *iter << endl;
    iter->findNormal();
  }

  VTM = matrix::I;
  VTM.PerspProject(d);
  VTM.scale3D( - screenX / (2 * d), screenY / (2 * d), 1.0);
  VTM.translate3D(screenX / 2, screenY / 2, 0);
  // Apply VTM to all points, performing the perspective projection.
  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    **iter *= VTM;
  }

  // Draw all of the polygons in polygonList to the screen.
  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    //cout << *iter << endl;
    //i.setPenColor(iter->getColor());
    iter->drawZBuffer(i, lightList, polygonList, vrp, Ia);
    //iter->drawZBuffer(i);
  }

  //Translate the VRP to the origin: VTM = T(- vrp.x, - vrp.y, - vrp.z).
  //Align the coordinate axes:
  //  Normalize the VPN and VUP.
  //  Create UVEC = VUP x VPN.
  //  Redo VUP' = VPN x UVEC.
  //  VTM = RotateXYZ(UVEC, VUP', VPN) * VTM.
  //Translate the COP (represented by the projection distance) to the origin: VTM = T(0, 0, d) * VTM.
  //Scale to the canonical view volume [CVV]:
  //  Let B = B + d.
  //  VTM = Scale( 2 * d / (du * B), 2 * d / (dv * B), 1 / B) * VTM.
  //Project onto the image plane:
  //  Let d = d / B.
  //  VTM = PROJpersp(d) * VTM.
  //Scale to the image size*: VTM = Scale( - screenX / (2 * d), - screenY / (2 * d), 1.0) * VTM.
  //* As given this equation is for PPM images. For TIFF images don't invert the y coordinate.
  //Translate the lower left corner to the origin: VTM = T(screenX/2, screenY/2) * VTM.
}

void view3D::parallelProject(model &m, image &i)
{
  cerr << "No parallel projection for you!" << endl;
  /*
  screenX = i.getCols();
  screenY = i.getRows();
  matrix VTM = matrix::I;
  VTM.translate3D(-vrp.x(), -vrp.y(), -vrp.z());
  vpn.normalize();
  vup.normalize();
  point3D uvec = crossProduct(vup, vpn);
  vup = crossProduct(vpn, uvec);
  VTM.alignAxes3D(uvec, vup, vpn);
  VTM.translate3D(0, 0, d);
  B = B + d;
  VTM.scale3D(2 * d / (du * B), 2 * d / (dv * B), 1 / B);
  VTM.ParallelProject();
  VTM.scale3D(-screenX / 2, screenY / 2, 1);
  VTM.translate3D(screenX / 2, screenY / 2, 0);

  vector<point3D*> pointList;
  list<polygonRef3D> polygonList;
  list<modelLight> lightList;
  matrix mx = matrix::I;

  m.render(mx, pointList, polygonList, lightList);

  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    **iter *= VTM;
  }

  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    iter->drawZBuffer(i);
  }

  //Clear Point List
  for (vector<point3D*>::iterator iter = pointList.begin(); iter != pointList.end(); iter++) {
    delete *iter;
  }
  */
}


// ----------- Assorted Functions ---------
colorVector lambertian(vector3D L, vector3D N, colorVector l, colorVector kD) 
{
  double d = dotProduct(N, L);
  return colorVector(l.r * kD.r * d, l.g * kD.g * d, l.b * kD.b * d);
}

colorVector phong(vector3D L, vector3D N, vector3D v, colorVector l, colorVector kS, double n)
{
  vector3D R = (dotProduct(2 * N, L) * N - L).normalized();
  double d = pow(dotProduct(R, v), n);
  return colorVector(l.r * kS.r * d, l.g * kS.g * d, l.b * kS.b * d);
}

Pixel shade(list<modelLight> lights, vector3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia) 
{
  colorVector c = colorVector(Ia.r * kD.r, Ia.g * kD.g, Ia.b * kD.b);
 
  for (list<modelLight>::iterator iter = lights.begin(); iter != lights.end(); iter++) {
    vector3D L = vector3D(iter->loc.x() - P.x, iter->loc.y() - P.y, iter->loc.z() - P.z).normalized();
    colorVector l = iter->l;

    if (dotProduct(N, L) > 0) {
      c = c + lambertian(L, N, l, kD) + phong(L, N, v, l, kS, n);
    }  
  }
  return Pixel(255 * c.r, 255 * c.g, 255 * c.b);
}

Pixel shadeWithShadows(list<modelLight> lights, list<polygonRef3D> &polygonList, point3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia) 
{
  // Ambient lighting
  colorVector c = colorVector(Ia.r * kD.r, Ia.g * kD.g, Ia.b * kD.b);
 
  for (list<modelLight>::iterator iter = lights.begin(); iter != lights.end(); iter++) {
    // Do shadows (for each light)
    if (! intersect(P, iter->loc, polygonList)) {
      vector3D L = vector3D(iter->loc.x() - P.x(), iter->loc.y() - P.y(), iter->loc.z() - P.z()).normalized();
      colorVector l = iter->l;
      
      if (dotProduct(N, L) > 0) {
	c = c + lambertian(L, N, l, kD) + phong(L, N, v, l, kS, n);
      }
      }
  }
  return Pixel(255 * c.r, 255 * c.g, 255 * c.b);
}

bool intersect(point3D start, point3D light, list<polygonRef3D> & polygonList)
{
  for (list<polygonRef3D>::iterator iter = polygonList.begin(); iter != polygonList.end(); iter++) {
    if (iter->pointCount > 2) {
      point3D v = light - start;
      double t1 = v.magnitude();
      v.normalize();
      
      double xa = iter->points[0]->worldX();
      double ya = iter->points[0]->worldY();
      double za = iter->points[0]->worldZ();
      double xb = iter->points[1]->worldX();
      double yb = iter->points[1]->worldY();
      double zb = iter->points[1]->worldZ();
      double xc = iter->points[2]->worldX();
      double yc = iter->points[2]->worldY();
      double zc = iter->points[2]->worldZ();
      double xd = v.x();
      double yd = v.y();
      double zd = v.z();
      double xe = start.x();
      double ye = start.y();
      double ze = start.z();

      double a = xa - xb;
      double b = ya - yb;
      double c = za - zb;
      double d = xa - xc;
      double e = ya - yc;
      double f = za - zc;
      double g = xd;
      double h = yd;
      double i = zd;
      double j = xa - xe;
      double k = ya - ye;
      double l = za - ze;
      
      double eiMinushf = e*i - h*f;
      double gfMinusdi = g*f - d*i;
      double dhMinuseg = d*h - e*g;
      double akMinusjb = a*k - j*b;
      double jcMinusal = j*c - a*l;
      double blMinuskc = b*l - k*c;
      
      double M = a*eiMinushf + b*gfMinusdi + c*dhMinuseg;
      double t = (f*akMinusjb + e*jcMinusal + d*blMinuskc)/M;
      double B = (j*eiMinushf + k*gfMinusdi + l*dhMinuseg)/M;
      double G = (i*akMinusjb + h*jcMinusal + g*blMinuskc)/M;
      
      if (t < 0 || t > t1)
	continue;
      if (G < 0 || G > 1)
	continue;
      if (B < 0 || B > 1 - G)
	continue;
      return true;
    }
  }
  return false;
}

// ------------- polygonRef3D -------------

polygonRef3D::polygonRef3D() : points(NULL), filled(true), flat(false) {}

polygonRef3D::polygonRef3D(int n) : pointCount(0), n(n), filled(true), flat(false)
{
  points = new point3D*[n];
}

polygonRef3D::polygonRef3D(const polygonRef3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D*[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
  flat = p.flat;
  filled = p.filled;
  kD = p.kD;
  kS = p.kS;
  nS = p.nS;
}

polygonRef3D& polygonRef3D::operator= (const polygonRef3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D*[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
    flat = rhs.flat;
    filled = rhs.filled;
    kD = rhs.kD;
    kS = rhs.kS;
    nS = rhs.nS;
  }
  return *this;
}

polygonRef3D::~polygonRef3D()
{
  delete[] points;
}

void polygonRef3D::addPoint(point3D *p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
  }
}

void polygonRef3D::findNormal()
{
  point3D norm = crossProduct(*points[1] - *points[0], *points[2] - *points[0]).normalized();

  normal.x = norm.x();
  normal.y = norm.y();
  normal.z = norm.z();
}

void polygonRef3D::setFilled(bool m) { filled = m; }
void polygonRef3D::setFlat(bool m) { flat = m; }

Pixel polygonRef3D::getColor()
{
  long r = 0, g = 0, b = 0;
  for (int i = 0; i < pointCount; i++) {
    r += points[i]->getColor().r;
    g += points[i]->getColor().g;
    b += points[i]->getColor().b;
  }
  r = r / pointCount;
  g = g / pointCount;
  b = b / pointCount;

  //cout << "(" << r << ", " << g << ", " << b << ")\n";
  return Pixel(r, g, b);
}

std::ostream& operator<< (std::ostream &out, const polygonRef3D &p)
{
  for (int i = 0; i < p.pointCount; i++)
    {
      out << "(" << p.points[i]->x() << ", " << p.points[i]->y() << ", " << p.points[i]->z() << ") -> ";
    }
   out << "(" << p.points[0]->x() << ", " << p.points[0]->y() << ", " << p.points[0]->z() << ")";
  return out;
}

bool edgeRecord3D_lt (const edgeRecord3D *x, const edgeRecord3D *y)
{
  return x->xIntersect < y->xIntersect;
}

bool edgeRecord3D_eq (const edgeRecord3D *x, const edgeRecord3D *y)
{
  return int(x->xIntersect + 0.5) == int(y->xIntersect + 0.5);
}

void polygonRef3D::drawZBuffer(image &im, list<modelLight> &lightList, list<polygonRef3D> &polygonList, point3D vrp, colorVector Ia)
{
  if (pointCount < 3) {
    cerr << "Too few points in the polygon\n" << endl;
  } else {
    std::list<edgeRecord3D*> activeEdgeList;
    int yStart = im.getRows(), yEnd = 0;
    edgeRecord3D *edges = new edgeRecord3D[pointCount];

    int next_pt, prev_pt;
    int edgeCount = 0;
    for (int j = 0; j < pointCount; j++) {
      next_pt = j < pointCount - 1 ? j + 1 : 0;
      prev_pt = j > 0 ? j - 1 : pointCount - 1;
      if (points[j]->y() != points[next_pt]->y()) {
	if (points[j]->y() < points[next_pt]->y()) {
	  edges[edgeCount].yStart = int(points[j]->y());
	  edges[edgeCount].yEnd = int(points[next_pt]->y() - 1);
	  edges[edgeCount].xIntersect = points[j]->x();
	  edges[edgeCount].zIntersect = 1.0 / points[j]->depth();
	  edges[edgeCount].dxPerScan = double(points[next_pt]->x() - points[j]->x()) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dzPerScan =  double(1.0 / points[next_pt]->depth() - 1.0 / points[j]->depth()) / (points[next_pt]->y() - points[j]->y());

	  edges[edgeCount].worldXIntersect = points[j]->worldX() * edges[edgeCount].zIntersect;
	  edges[edgeCount].worldYIntersect = points[j]->worldY() * edges[edgeCount].zIntersect;
	  edges[edgeCount].dWorldXPerScan = double(points[next_pt]->worldX() * edges[edgeCount].zIntersect - points[j]->worldX() * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dWorldYPerScan = double(points[next_pt]->worldY() * edges[edgeCount].zIntersect - points[j]->worldY() * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  if (flat) {
	    edges[edgeCount].normalXIntersect = normal.x * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalYIntersect = normal.y * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalZIntersect = normal.z * edges[edgeCount].zIntersect;
	    edges[edgeCount].dNormalXPerScan = 0;
	    edges[edgeCount].dNormalYPerScan = 0;
	    edges[edgeCount].dNormalZPerScan = 0;
	  } else {
	    edges[edgeCount].normalXIntersect = points[j]->normal.x * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalYIntersect = points[j]->normal.y * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalZIntersect = points[j]->normal.z * edges[edgeCount].zIntersect;
	    edges[edgeCount].dNormalXPerScan = double(points[next_pt]->normal.x * edges[edgeCount].zIntersect - points[j]->normal.x * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	    edges[edgeCount].dNormalYPerScan = double(points[next_pt]->normal.y * edges[edgeCount].zIntersect - points[j]->normal.y * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	    edges[edgeCount].dNormalZPerScan = double(points[next_pt]->normal.z * edges[edgeCount].zIntersect - points[j]->normal.z * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  }
	} else {
	  edges[edgeCount].yStart = int(points[next_pt]->y());
	  edges[edgeCount].yEnd = int(points[j]->y() - 1);
	  edges[edgeCount].xIntersect = points[next_pt]->x();
	  edges[edgeCount].zIntersect = 1.0 / points[next_pt]->depth();
	  edges[edgeCount].dxPerScan = double(points[next_pt]->x() - points[j]->x()) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dzPerScan = double(1.0 / points[next_pt]->depth() - 1.0 / points[j]->depth()) / (points[next_pt]->y() - points[j]->y());

	  edges[edgeCount].worldXIntersect = points[next_pt]->worldX() * edges[edgeCount].zIntersect;
	  edges[edgeCount].worldYIntersect = points[next_pt]->worldY() * edges[edgeCount].zIntersect;
	  edges[edgeCount].dWorldXPerScan = double(points[next_pt]->worldX() * edges[edgeCount].zIntersect - points[j]->worldX() * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  edges[edgeCount].dWorldYPerScan = double(points[next_pt]->worldY() * edges[edgeCount].zIntersect - points[j]->worldY() * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  if (flat) {
	    edges[edgeCount].normalXIntersect = normal.x * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalYIntersect = normal.y * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalZIntersect = normal.z * edges[edgeCount].zIntersect;
	    edges[edgeCount].dNormalXPerScan = 0;
	    edges[edgeCount].dNormalYPerScan = 0;
	    edges[edgeCount].dNormalZPerScan = 0;
	  } else {
	    edges[edgeCount].normalXIntersect = points[next_pt]->normal.x * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalYIntersect = points[next_pt]->normal.y * edges[edgeCount].zIntersect;
	    edges[edgeCount].normalZIntersect = points[next_pt]->normal.z * edges[edgeCount].zIntersect;
	    edges[edgeCount].dNormalXPerScan = double(points[next_pt]->normal.x * edges[edgeCount].zIntersect - points[j]->normal.x * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	    edges[edgeCount].dNormalYPerScan = double(points[next_pt]->normal.y * edges[edgeCount].zIntersect - points[j]->normal.y * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	    edges[edgeCount].dNormalZPerScan = double(points[next_pt]->normal.z * edges[edgeCount].zIntersect - points[j]->normal.z * edges[edgeCount].zIntersect) / (points[next_pt]->y() - points[j]->y());
	  }
	}
	if (edges[edgeCount].yStart < yStart) { yStart = edges[edgeCount].yStart; }
	if (edges[edgeCount].yEnd > yEnd) { yEnd = edges[edgeCount].yEnd; }
	edgeCount++;
      }
    }
  
    for (int j = yStart; j <= yEnd; j++) {

      //Build Active Edge List
      for (int k = 0; k < edgeCount; k++) {
	if ((edges[k].yStart <= j) && (edges[k].yEnd >= j)) {
	  activeEdgeList.push_back(&edges[k]);
	}
      }

      //Sort Active Edge List
      activeEdgeList.sort(edgeRecord3D_lt);

      //Draw Scan Line
      std::list<edgeRecord3D*>::iterator iterEnd = activeEdgeList.end();
      std::list<edgeRecord3D*>::iterator iter = activeEdgeList.begin();
      std::list<edgeRecord3D*>::iterator iterNext = activeEdgeList.begin(); iterNext++;

      while ((iterNext != iterEnd) && (iter != iterEnd)) {
	double z = (**iter).zIntersect;
	double worldX = (**iter).worldXIntersect;
	double worldY = (**iter).worldYIntersect;
	double normalX = (**iter).normalXIntersect;
	double normalY = (**iter).normalYIntersect;
	double normalZ = (**iter).normalZIntersect;

	double dzPerColumn = double((**iter).zIntersect - (**iterNext).zIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);

	double dWorldXPerColumn = double((**iter).worldXIntersect - (**iterNext).worldXIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dWorldYPerColumn = double((**iter).worldYIntersect - (**iterNext).worldYIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dNormalXPerColumn = double((**iter).normalXIntersect - (**iterNext).normalXIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dNormalYPerColumn = double((**iter).normalYIntersect - (**iterNext).normalYIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);
	double dNormalZPerColumn = double((**iter).normalZIntersect - (**iterNext).normalZIntersect) / ((**iter).xIntersect - (**iterNext).xIntersect);

	for (int i = int((**iter).xIntersect); i < (**iterNext).xIntersect; i++) {
	  if (z > im.getZValue(i, j)) {
	    point3D worldPoint = point3D(worldX, worldY, z);
	    vector3D viewV = vector3D(vrp.x() - worldPoint.x(), vrp.y() - worldPoint.y(), vrp.z() - worldPoint.z()).normalized();
	    im.drawPixel(i, j, shadeWithShadows(lightList, polygonList, worldPoint, vector3D(normalX, normalY, normalZ).normalized(), viewV, kD, kS, nS, Ia));
	    //im.drawPixel(i, j);
	    im.setZValue(i, j, z);
	  }
	  z += dzPerColumn;
	  worldX += dWorldXPerColumn;
	  worldY += dWorldYPerColumn;
	  normalX += dNormalXPerColumn;
	  normalY += dNormalYPerColumn;
	  normalZ += dNormalZPerColumn;
	}

	iter++; iterNext++;
	if (iter == iterEnd) { break; }
	iter++; iterNext++;
      }
    
      iter = activeEdgeList.begin();
      for (iter = activeEdgeList.begin(); iter != activeEdgeList.end(); iter++) {
	(**iter).xIntersect += (**iter).dxPerScan;
	(**iter).zIntersect += (**iter).dzPerScan;

	(**iter).worldXIntersect += (**iter).dWorldXPerScan;
	(**iter).worldYIntersect += (**iter).dWorldYPerScan;
	(**iter).normalXIntersect += (**iter).dNormalXPerScan;
	(**iter).normalYIntersect += (**iter).dNormalYPerScan;
	(**iter).normalZIntersect += (**iter).dNormalZPerScan;
      }

      activeEdgeList.clear();
    }
    delete [] edges;
   
  }
}




