#include "model.h"

modelLight::modelLight() {}

int modelLight::getName()
{
  return 4;
}

void modelLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, list<modelLight> &lightList)
{
  cerr << "Render should always be overloaded by the child.\n";
}

pointLight::pointLight() {}

pointLight::pointLight(colorVector l) {
  this->l = l;
  loc = point3D(0, 0, 0);
}

void pointLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, list<modelLight> &lightList)
{
  loc *= m;
  lightList.push_back(*this);
}

spotLight::spotLight() {}

spotLight::spotLight(colorVector l, vector3D D, double a) {
  this->l = l;
  this->D = D;
  this->a = a;
  loc = point3D(0, 0, 0);
}

void spotLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, list<modelLight> &lightList)
{
  loc *= m;
  lightList.push_back(*this);
}
