#ifndef VECTOR3D_H
#define VECTOR3D_H

#include <ostream.h>

class vector3D {
 public:
  double x, y, z;

  vector3D();
  vector3D(double x, double y, double z);

  void normalize();
  vector3D normalized();
  double magnitude();

  friend vector3D crossProduct(vector3D a, vector3D b);
  friend double dotProduct(vector3D a, vector3D b);

  friend std::ostream& operator<< (std::ostream & out, const vector3D &v);
 
  friend vector3D operator+ (const vector3D &x, const vector3D &y);
  friend vector3D operator- (const vector3D &x, const vector3D &y);
  friend vector3D operator* (const double &d, const vector3D &y);
};

class colorVector {
 public:
  double r, g, b;
  
  colorVector();
  colorVector(double r, double g, double b);

  friend colorVector operator+ (const colorVector &x, const colorVector &y);
};

#endif
