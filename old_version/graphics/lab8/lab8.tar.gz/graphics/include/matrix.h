#ifndef MATRIX_H
#define MATRIX_H

#include <iostream.h>

class point3D;

class matrix {
  double data[4][4];
  
 public:
  matrix();
  matrix(const matrix &copy);
  matrix(const double copy[][4]);
  // Useful constructor to make a matrix from 16 doubles.
  matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33);

  void translate3D(double tx, double ty, double tz);

  void scale3D(double s); // Scale the same amount (s) in all directions.
  void scale3D(double sx, double sy, double sz);
  void scale3D(point3D center, double s); // Scale uniformly around a point.
  void scale3D(point3D center, double sx, double sy, double sz); // Scale around a point.
  void scale3D(point3D center, point3D direction, double sx, double sy, double sz); // Scale in an arbitrary direction around a point.

  void rotate3Dx(double theta);
  void rotate3Dx(point3D center, double theta);
  void rotate3Dy(double theta);
  void rotate3Dy(point3D center, double theta);
  void rotate3Dz(double theta);
  void rotate3Dz(point3D center, double theta);
  
  void alignAxes3D(point3D newX, point3D newY, point3D newZ);

  void sheer3Dx(double shy, double shz);
  void sheer3Dy(double shx, double shz);
  void sheer3Dz(double shx, double shy);

  void PerspProject(double d);
  void ParallelProject();

  friend matrix operator* (const matrix &x, const matrix &y);
  friend matrix operator+ (const matrix &x, const matrix &y);
  friend point3D operator* (const matrix &x, const point3D &y);

  void operator*= (const matrix &rhs);

  friend std::ostream& operator<< (std::ostream & out, const matrix &p);

  matrix& operator= (const double rhs[][4]);
  static const double I[][4];
};

#endif







