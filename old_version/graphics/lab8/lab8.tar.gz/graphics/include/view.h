#ifndef VIEW_H
#define VIEW_H

#include "model.h"

class view3D {
 private:
  point3D vrp, vpn, vup;
  double d, du, dv, F, B;
  int screenX, screenY;
  colorVector Ia;

 public:
  view3D();
  void setCamera(point3D vrp, point3D vpn, point3D vup);
  void setProjectionDistance(double d);
  void setCameraSize(double du, double dv);
  void setClipPlanes(double F, double B);
  void setAmbientLight(colorVector Ia);
  void project(model &m, image &i);
  void parallelProject(model &m, image &i);
};

bool intersect(point3D start, point3D vector, list<polygonRef3D> & polygonList);
colorVector lambertian(vector3D L, vector3D N, colorVector l, colorVector C);
colorVector phong(vector3D L, vector3D N, vector3D v, colorVector l, colorVector C, double n);
Pixel shade(list<modelLight> lights, vector3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia);
Pixel shadeWithShadows(list<modelLight> lights, list<polygonRef3D> &polygonList, point3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia);


struct edgeRecord3D {
  int yStart, yEnd;
  double xIntersect, dxPerScan, zIntersect, dzPerScan;

  double worldXIntersect, worldYIntersect;
  double dWorldXPerScan, dWorldYPerScan;
  double normalXIntersect, normalYIntersect, normalZIntersect;
  double dNormalXPerScan, dNormalYPerScan, dNormalZPerScan;
};

class polygonRef3D {
 public:
  point3D **points;
  vector3D normal;
  int pointCount, n;
  bool filled, flat;
  colorVector kD, kS;
  double nS;

  polygonRef3D();
  polygonRef3D(int n);
  polygonRef3D(const polygonRef3D &p);
  virtual ~polygonRef3D();
  polygonRef3D& operator= (const polygonRef3D &rhs);
  void findNormal();
  void setFilled(bool m);
  void setFlat(bool m);
  Pixel getColor();

  void addPoint(point3D *p);

  //void drawZBuffer(image &im);
  void drawZBuffer(image &im, list<modelLight> &lightList, list<polygonRef3D> &polygonList, point3D vrp, colorVector Ia);

  friend std::ostream& operator<< (std::ostream &out, const polygonRef3D &p);
};

#endif
