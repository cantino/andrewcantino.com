pushd . > /dev/null

cd ~/graphics/lib
make clean
make
cd ~/graphics/src
make clean
make $1

echo ""
echo "Running $1..."
~/graphics/bin/$1 #~/graphics/$2 ~/graphics/$3
echo "Completed Execution..."

#if ! [ -z $4 ]; then 
#    echo "Opening in xzgv..."
#    if [ -z $5 ]; then
#	xzgv ~/graphics/$3 &
#    else
#        xzgv -z ~/graphics/$3 &
#    fi
#fi
popd > /dev/null
