#include "view.h"
#include <sstream>

int main() {
  /*
  model scene;
  polygon3D *p = new polygon3D(4);
  p->addPoint(point3D(-1, 0, 0));
  p->addPoint(point3D(1, 0, 0));
  p->addPoint(point3D(1, 1, 0));
  p->addPoint(point3D(0, 1, 0));
  p->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 64);
  p->setFlat(true);
  scene.addItem(p);
  polygon3D *a = new polygon3D(3);
  a->addPoint(point3D(.5, 0, 1));
  a->addPoint(point3D(1, 0, 1));
  a->addPoint(point3D(.75, 1, 1));
  a->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 64);
  a->setFlat(true);
  scene.addItem(a);
  scene.addItem(new modelMatrixReset());
  scene.addItem(new modelTranslate3D(14, 0, 5));
  scene.addItem(new pointLight(colorVector(0,0,1)));
  
  view3D v;
  image im = image(500, 500, Pixel(255, 255, 255));
  
  v.setCamera(point3D(0, 0, 2), point3D(0, 0, -1), point3D(0, 1, 0));
  v.setProjectionDistance(2);
  v.setCameraSize(2, 2);
  v.setClipPlanes(0, 10);
  v.setAmbientLight(colorVector(10/255.0, 10/255.0, 10/255.0));
  v.project(scene, im);
  im.writeImage("../images/lab8.ppm");
  */

 
  // Using pyramid3D
  model pyramid;

  polygon3D p = polygon3D(4);
  p.addPoint(point3D(-1, -1, 0, Pixel(255,0,0)));
  p.addPoint(point3D(1, -1, 0, Pixel(255, 0, 0)));
  p.addPoint(point3D(1, 1, 0, Pixel(0,0,255)));
  p.addPoint(point3D(-1, 1, 0, Pixel(0, 0, 255)));

  pyramid3D *pyr = new pyramid3D(point3D(0, 0, 1, Pixel(0, 0, 0)), p);
  pyr->setMaterial(colorVector(.8, .8, .8), colorVector(.8, .8, .8), 64);
  pyr->setFlat(true);
  pyramid.addItem(pyr);

  for (int i = 0; i < 80; i++) {
    model scene;
    scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, -2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, 2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(5, 5, 1));
    scene.addItem(new pointLight(colorVector(0,0,1)));

    view3D v;
    image im = image(500, 500, Pixel(255, 255, 255));
    
    v.setCamera(point3D(5, 5, 1), point3D(-1, -1, -.2), point3D(-1, -1, .2));
    v.setProjectionDistance(2);
    v.setCameraSize(2, 2);
    v.setClipPlanes(0, 10);
    v.setAmbientLight(colorVector(10/255.0, 10/255.0, 10/255.0));
    v.project(scene, im);
    
    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
 
    im.writeImage("../images/lab8-ani1/" + osData.str() + ".ppm");
  }

}
