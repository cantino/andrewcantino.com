#include "image.h"
#include <math.h>

// A's portfolio for lab 3
// 2004

int main (int argc, char *argv[]) {

  image test = image(400, 400, Pixel(255,255,255));
  test.setPenPattern(image("../images/bark.ppm"));
  {
    int x = 75, y = 100, scale = 3;
    polygon p = polygon(7);
    p.addPoint(point(x, y));
    p.addPoint(point(x + 10*scale, y));
    p.addPoint(point(x + 17*scale, y + 25*scale));
    p.addPoint(point(x + 43*scale, y + 25*scale));
    p.addPoint(point(x + 50*scale, y));
    p.addPoint(point(x + 60*scale, y));
    p.addPoint(point(x + 30*scale, y + 90*scale));
    test.drawFilledGraphic(p);
    
    polygon p2 = polygon(3);
    p2.addPoint(point(x + 20*scale, y + 35*scale));
    p2.addPoint(point(x + 40*scale, y + 35*scale));
    p2.addPoint(point(x + 30*scale, y + 75*scale));
    test.disablePattern();
    test.setPenColor(Pixel(255,255,255));
    test.drawFilledGraphic(p2);
  }
  test.setPenPattern(image("../images/clouds.ppm"));
  {
    int x = 230, y = 20, scale = 2.5;
    ellipse e = ellipse(point(x + 35*scale, y + 45*scale), 35*scale, 45*scale);
    test.enablePattern();
    test.drawFilledGraphic(e);
    test.disablePattern();
    ellipse e2 = ellipse(point(x + 35*scale, y + 45*scale), 25*scale, 35*scale);
    test.drawFilledGraphic(e2);
    polygon p = polygon(5);
    p.addPoint(point(x + 35*scale, y + 45*scale));
    p.addPoint(point(x + 55*scale, y));
    p.addPoint(point(x + 100*scale, y));
    p.addPoint(point(x + 100*scale, y + 100*scale));
    p.addPoint(point(x + 55*scale, y + 90*scale));
    test.drawFilledGraphic(p);
  }
  test.setPenPattern(image("../images/ivy.ppm"));
  test.setPatternOrigin(point(0,0));
  test.gradFill(point(1,1), Pixel(0,0,0));
  test.gradFill(point(150,220), Pixel(0,0,0));


//test.drawImage(0,0,a);


  

  /*
  int dr, dg, db;
  for (i = 0; i < a.cols; i++)
    for (j = 0; j < a.rows; j++)
      {
	dr = int(pow(int(a.getPixel(i, j).r) - r, 2)/sdr);
	dg = int(pow(int(a.getPixel(i, j).g) - g, 2)/sdg);
	db = int(pow(int(a.getPixel(i, j).b) - b, 2)/sdb);
	// Add a border to get rid of edge glitches.
	if (i > 50 && i < a.cols - 50 && j > 5)
	  if (sqrt(dr*dr + dg*dg + db*db) > threshold)
	    a.setAlpha(i, j, 255);
	  else
	    a.setAlpha(i, j, 0);
	else
	  a.setAlpha(i, j, 0);
      }
  */

  test.writeImage("../images/test.ppm");
}







