#include "image.h"
#include <math.h>
#include "fractal.h"
#include <sstream>

int main (int argc, char *argv[]) {
  /*
  double x0, y0, x1, y1;
  x0 = -1; y0 = -1; x1 = 1.5; y1 = 1;
  for (int x = 0; x < 25; x++) {
    cout << "Writting image " << x << "...\n";
    mandelbrot m = mandelbrot(x0, y0, x1, y1, 600); 
    image a = m.drawImage();

    stringstream ss;
    ss << x;
    a.writeImage("../images/mand/" + ss.str() + ".ppm");
    x0 = .96 * x0;
    x1 = .96 * x1;
    y0 = .9409 * y0;
  }
  */
  /*
  double x0, y0, x1, y1;
  x0 = -1.55; y0 = -1; x1 = 1.55; y1 = 1;
  for (int x = 0; x < 100; x++) {
    cout << "Writting image " << x << "...\n";
    julia j = julia(x0, y0, x1, y1, 0.7454054, 0.1130063, 700);
    image a = j.drawImage();

    stringstream ss;
    ss << x;
    a.writeImage("../images/julia/" + ss.str() + ".ppm");
    x0 = .97 * x0;
    x1 = .97 * x1;
    y0 = .97 * y0;
    y1 = .97 * y1;
  }
  */
  
  //julia j = julia(-1.55, -1, 1.55, 1, 0.7454054, 0.1130063, 700);
  //mandelbrot m = mandelbrot(-.6, -1.2, 1.8, 1.2, 1000);
  //julia j = julia(.8, -.2, 1.2, .2, 0.7454054, 0.1130063, 700);
  julia j = julia(-.1, -.5, 1, .1, 0.7454054, 0.1130063, 700);
  //mandelbrot m = mandelbrot(1.2, -.5, 2.2, .5, 700);
  image a = j.drawImage();
  a.writeImage(argv[2]);
}








