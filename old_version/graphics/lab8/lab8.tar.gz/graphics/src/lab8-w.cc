#include "view.h"
#include "model.h"
#include <math.h>
#include <list>

int main () {
  image im = image(200, 200, Pixel(255, 255, 255));

  list<modelLight> lights;
 
  pointLight light = pointLight(colorVector(1, 1, 1));
  light.loc = point3D(-5, 0, 0);
  lights.push_back(light);

  light = pointLight(colorVector(0, 0, 1));
  light.loc = point3D(10, 3, 0);
  // lights.push_back(light);

  for (int row = 0; row < im.getRows(); row++) {
    for (int col = 0; col < im.getCols(); col++) {
      vector3D p = vector3D(double(col - im.getCols() / 2) / (im.getCols()/2), double(row - im.getCols()/2) / (im.getCols()/2), -sqrt(1 - (double(col - im.getCols() / 2) / (im.getCols()/2))*(double(col - im.getCols() / 2) / (im.getCols()/2))) + 10);

      vector3D v = (vector3D(0, 0, 0) - p).normalized();
      vector3D N = vector3D(p.x, 0, p.z - 10).normalized();
      //vector3D L = (vector3D(-5, 0, 0) - p).normalized();
      
      colorVector kS = colorVector(1, 1, 1);
      colorVector kD = colorVector(0.3, 0.8, 0.3);
      //colorVector l = colorVector(1, 1, 1);
      colorVector Ia = colorVector(10.0 / 255, 10.0 / 255, 10.0 / 255);
    
      im.drawPixel(col, row, shade(lights, p, N, v, kD, kS, 64, Ia));
    }
  }
  
  im.writeImage("../images/lab8.ppm");
}
