#ifndef MODEL_H
#define MODEL_H

#include <list>
#include <vector>
#include <map>
#include "matrix.h"
#include "image.h"
#include "graphic.h"

/*
Class Hierarchy

  modelItem
     model

     modelPrimative
        point3D
	line3D
	polygon3D
	polyline3D

     modelTransform
         modelTranslate3D
	 modelScale3D
	 modelRotate3Dx
	 modelRotate3Dy
	 modelRotate3Dz
	 modelSheer3Dx
	 modelSheer3Dy
	 modelSheer3Dz
	 modelMatrixReset

     modelImage
         modelSetPenColor
	 modelSetGradColor
	 modelSetPenAlpha
	 modelSetGradDirection
	 modelSetGradMode
	 modelClearGradient
	 modelSetPenPattern
	 modelSetPatternOrigin
	 modelDisablePattern
	 modelEnablePattern
	 modelClearPattern
	 modelDrawImage

*/

class modelItem {
 public:
  virtual int getName() = 0;
};

class model : public modelItem {
 private:
  std::list<modelItem*> data;
  std::vector< std::map<string, double> > childMemory;
  void (*logicFunction)(model&, std::map<string, double>&, std::list<modelItem*>&);

  void drawList(matrix &GTM, image &im, std::list<modelItem*> &dataList);
  void drawList(matrix &GTM, image &im, std::list<modelItem*> &dataList, std::list< std::map<string, double> >& childMemory);

 public:
  model();
  model(const model &p);
  model& operator= (const model &rhs);
  virtual ~model();
  
  virtual int getName();
  void addItem(modelItem *i);
  void addLogic(void (*logicFunction)(model&, std::map<string, double>&, std::list<modelItem*>&));
  void draw(matrix &GTM, image &im);
  void draw(matrix &GTM, image &im, std::map<string, double> &memory);
};

class modelPrimative : public modelItem {
 public:
  virtual int getName();
  virtual void draw(matrix &m, image &i) = 0;
};

class point3D {
  double data[4];
 public:
  point3D();
  point3D(double x, double y, double z);
  point3D(double x, double y, double z, double h);

  // Accessors
  double x();
  double y();
  double z();
  point getPoint();

  friend std::ostream& operator<< (std::ostream & out, const point3D &p);

  friend point3D operator+ (const point3D &x, const point3D &y);
  // Multiply a point by a matrix (i.e., transform it with a transformation matrix.)
  friend point3D operator* (const matrix &x, const point3D &y);

  virtual void draw(matrix &m, image &i);
};

class line3D : public modelPrimative {
 public:
  point3D start, end;
  line3D();
  line3D(point3D s, point3D e);
  virtual void draw(matrix &m, image &i);
};

class polygon3D : public modelPrimative {
 public:
  point3D *points;
  int pointCount, n;
  bool filled;
  polygon3D();
  polygon3D(int n);
  polygon3D(const polygon3D &p);
  polygon3D& operator= (const polygon3D &rhs);
  void setFilled(bool m);
  virtual ~polygon3D();
  void addPoint(point3D p);
  virtual void draw(matrix &m, image &im);
};

class polyline3D : public modelPrimative {
 public:
  point3D *points;
  int pointCount, n;
  polyline3D();
  polyline3D(int n);
  polyline3D(const polyline3D &p);
  polyline3D& operator= (const polyline3D &rhs);
  virtual ~polyline3D();
  void addPoint(point3D p);
  virtual void draw(matrix &m, image &im);
};

class modelTransform : public modelItem {
 public:
  virtual int getName();
  virtual void apply(matrix &m) = 0;
};

class modelTranslate3D : public modelTransform {
  double tx, ty, tz;
  
 public:
  modelTranslate3D(double tx, double ty, double tz);

  virtual void apply(matrix &m);
};
class modelScale3D : public modelTransform {
  double sx, sy, sz;
  point3D center;
  int mode;

 public:
  modelScale3D(double s);
  modelScale3D(double sx, double sy, double sz);
  modelScale3D(point3D center, double s);
  modelScale3D(point3D center, double sx, double sy, double sz);
  //modelScale3D(point3D center, double theta, double sx, double sy, double sz);

  virtual void apply(matrix &m);
};
class modelRotate3Dx : public modelTransform {
  point3D center;
  double theta;
  int mode;

 public:
  modelRotate3Dx(double theta);
  modelRotate3Dx(point3D center, double theta);

  virtual void apply(matrix &m);
};
class modelRotate3Dy : public modelTransform {
  point3D center;
  double theta;
  int mode;

 public:
  modelRotate3Dy(double theta);
  modelRotate3Dy(point3D center, double theta);

  virtual void apply(matrix &m);
};
class modelRotate3Dz : public modelTransform {
  point3D center;
  double theta;
  int mode;

 public:
  modelRotate3Dz(double theta);
  modelRotate3Dz(point3D center, double theta);

  virtual void apply(matrix &m);
};
class modelSheer3Dx : public modelTransform {
  double shy, shz;
  
 public:
  modelSheer3Dx(double shx, double shy);

  virtual void apply(matrix &m);
};
class modelSheer3Dy : public modelTransform {
  double shx, shz;
  
 public:
  modelSheer3Dy(double shx, double shz);

  virtual void apply(matrix &m);
};
class modelSheer3Dz : public modelTransform {
  double shx, shy;
  
 public:
  modelSheer3Dz(double shx, double shy);

  virtual void apply(matrix &m);
};
class modelMatrixReset : public modelTransform {
 public:
  modelMatrixReset();
  virtual void apply(matrix &m);
};

class modelImage : public modelItem {
 public:
  virtual int getName();
  virtual void apply(image &i) = 0;
};

class modelSetPenColor : public modelImage {
 public:
  Pixel color;
  modelSetPenColor();
  modelSetPenColor(Pixel c);
  virtual void apply(image &i);
};
class modelSetPenAlpha : public modelImage {
 public:
  unsigned char alpha;
  modelSetPenAlpha();
  modelSetPenAlpha(unsigned char a);
  virtual void apply(image &i);
};
class modelSetGradColor : public modelImage {
 public:
  Pixel color1, color2;
  modelSetGradColor();
  modelSetGradColor(Pixel c1, Pixel c2);
  virtual void apply(image &i);
};
class modelSetGradDirection : public modelImage {
 public:
  point d1, d2;
  modelSetGradDirection();
  modelSetGradDirection(point d1, point d2);
  virtual void apply(image &i);
};
class modelSetGradMode : public modelImage {
 public:
  int m;
  modelSetGradMode();
  modelSetGradMode(int m);
  virtual void apply(image &i);
};
class modelClearGradient : public modelImage {
 public:
  modelClearGradient();
  virtual void apply(image &i);
};
class modelSetPenPattern : public modelImage {
  image *im;
  
 public:
  modelSetPenPattern(image *im);
  virtual void apply(image &i);
};
class modelSetPatternOrigin : public modelImage {
  point p;
  
 public:
  modelSetPatternOrigin(point p);
  virtual void apply(image &i);
};
class modelDisablePattern : public modelImage {
 public:
  modelDisablePattern();
  virtual void apply(image &i);
};
class modelEnablePattern : public modelImage {
 public:
  modelEnablePattern();
  virtual void apply(image &i);
};
class modelClearPattern : public modelImage {
 public:
  modelClearPattern();
  virtual void apply(image &i);
};
class modelDrawImage : public modelImage {
 public:
  modelDrawImage();
  virtual void apply(image &i);
};

#endif
