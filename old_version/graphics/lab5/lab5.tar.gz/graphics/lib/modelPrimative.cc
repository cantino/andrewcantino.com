#include "model.h"
#include "graphic.h"

// ----------- modelPrimative ----------

int modelPrimative::getName()
{
  return 1;
}

// -------------- point3D --------------

point3D::point3D() {}

point3D::point3D(double x, double y, double z)
{ data[0] = x; data[1] = y; data[2] = z; data[3] = 1; }

point3D::point3D(double x, double y, double z, double h)
{ data[0] = x; data[1] = y; data[2] = z; data[3] = h; }

point point3D::getPoint()
{
  return point(data[0], data[1]);
}

double point3D::x() { return data[0]; }
double point3D::y() { return data[1]; }
double point3D::z() { return data[2]; }

void point3D::draw(matrix &m, image &i)
{
  point p = (m * (*this)).getPoint();
  i.drawGraphic(p);
}

// -------------- line3D ---------------

line3D::line3D() {}
line3D::line3D(point3D s, point3D e) : start(s), end(e) {}
void line3D::draw(matrix &m, image &i)
{
  line l = line((m * start).getPoint(), (m * end).getPoint());
  i.drawGraphic(l);
}

// ------------- polygon3D -------------

polygon3D::polygon3D() : points(NULL), filled(true) {}
polygon3D::polygon3D(int n) : pointCount(0), n(n), filled(true)
{
  points = new point3D[n];
}

polygon3D::polygon3D(const polygon3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polygon3D& polygon3D::operator= (const polygon3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polygon3D::~polygon3D()
{
  delete[] points;
}

void polygon3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
  }
}

void polygon3D::setFilled(bool m) { filled = m; }

void polygon3D::draw(matrix &m, image &im)
{
  polygon p = polygon(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());
  if (filled)
    im.drawFilledGraphic(p);
  else
    im.drawGraphic(p);
}

// ------------ polyline3D -------------

polyline3D::polyline3D() : points(NULL) {}
polyline3D::polyline3D(int n) : pointCount(0), n(n)
{
  points = new point3D[n];
}

polyline3D::polyline3D(const polyline3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polyline3D& polyline3D::operator= (const polyline3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polyline3D::~polyline3D()
{
  delete[] points;
}

void polyline3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polyline." << endl;
  }
}

void polyline3D::draw(matrix &m, image &im)
{
  polyline p = polyline(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());
  im.drawGraphic(p);
}
