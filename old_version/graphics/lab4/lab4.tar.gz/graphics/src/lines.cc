#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "graphic.h"

#define NUMLINES 100
#define TIMING 5
#define ROWS 200
#define COLS 200

/*
  This C program draw lines for 5 seconds (set above in TIMING
  constant).  It executes this by repeatedly drawing NUMLINES (set
  above) lines which are randomly selected (both color and position).

  This final image is written out to the file lines.ppm.  */

int main() {
  point start[NUMLINES], end[NUMLINES];
  Pixel color[NUMLINES];
  int length[NUMLINES];
  long j;
  Pixel white = Pixel(255, 255, 255);
  unsigned long starttime;
  long numLines;
  double sum, dx, dy;

  // allocate an image ROWS by COLS
  image i = image(ROWS, COLS, white);
  
  // Pre-calculate the line endpoints and colors so we don't have to
  // call the random() function inside the main drawing loop.
  sum = 0.0;

  for(j=0;j<NUMLINES;j++) {
    start[j] = point((int)(drand48() * ROWS), (int)(drand48() * COLS));
    end[j] = point((int)(drand48() * ROWS), (int)(drand48() * COLS));
    color[j] = Pixel((unsigned char)(drand48() * 255), (unsigned char)(drand48() * 255), (unsigned char)(drand48() * 255));
    dy = start[j].y - end[j].y;
    dx = start[j].x - end[j].x;
    length[j] = sqrt(dx * dx + dy * dy);
    sum += sqrt(dx * dx + dy * dy);
  }
  sum /= NUMLINES;
  printf("Average line length = %.1lf\n", sum);

  // Start drawing lines
  starttime = time(NULL);
  //line l;
  circle c;
  for(j=0,numLines=0;time(NULL) < starttime + TIMING;numLines++, j++) {
    if(j == NUMLINES)
      j = 0;
    c = circle(start[j], length[j]);
    i.setPenColor(color[j]);
    i.drawGraphic(c);
  }

  // print out the result
  printf("%ld lines per second\n", numLines / TIMING);

  // write out the image
  i.writeImage("../images/circles.ppm");
}

