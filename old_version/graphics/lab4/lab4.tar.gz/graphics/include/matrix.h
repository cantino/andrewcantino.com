#ifndef MATRIX_H
#define MATRIX_H

#include <iostream.h>

class point;
class matrix;

class point3D {
  double data[4];

 public:
  point3D();
  point3D(double x, double y, double z);
  point3D(double x, double y, double z, double h);
  point3D(const point3D &copy);

  // Accessors
  double x();
  double y();
  double z();

  point getPoint();

  friend std::ostream& operator<< (std::ostream & out, const point3D &p);

  friend point3D operator+ (const point3D &x, const point3D &y);
  // Multiply a point by a matrix (i.e., transform it with a transformation matrix.)
  friend point3D operator* (const matrix &x, const point3D &y);
};

class matrix {
  double data[4][4];
  
 public:
  matrix();
  matrix(const matrix &copy);
  // Useful constructor to make a matrix from 16 doubles.
  matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33);

  void translate3D(double tx, double ty, double tz);

  void scale3D(double s); // Scale the same amount (s) in all directions.
  void scale3D(double sx, double sy, double sz);
  void scale3D(point3D center, double s); // Scale uniformly around a point.
  void scale3D(point3D center, double sx, double sy, double sz); // Scale around a point.
  void scale3D(point3D center, double theta, double sx, double sy, double sz); // Scale in an arbitrary direction around a point.

  void rotate3Dz(double theta);
  void rotate3Dz(point3D center, double theta); // Rotate around the z-axis around a point.

  void sheer3Dx(double shx);
  void sheer3Dy(double shy);

  friend matrix operator* (const matrix &x, const matrix &y);
  friend matrix operator+ (const matrix &x, const matrix &y);
  friend point3D operator* (const matrix &x, const point3D &y);

  void operator*= (const matrix &rhs);

  friend std::ostream& operator<< (std::ostream & out, const matrix &p);

  matrix& operator= (const double rhs[]);
  static const double I[];
};

#include "graphic.h"

#endif







