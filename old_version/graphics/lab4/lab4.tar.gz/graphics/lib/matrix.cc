#include "matrix.h"
#include <math.h>

// [rows][cols]

matrix::matrix()
{
}

matrix::matrix(const matrix &copy)
{
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      data[i][j] = copy.data[i][j];
}

matrix::matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33)
{
  data[0][0] = m00; data[0][1] = m01; data[0][2] = m02; data[0][3] = m03;
  data[1][0] = m10; data[1][1] = m11; data[1][2] = m12; data[1][3] = m13;
  data[2][0] = m20; data[2][1] = m21; data[2][2] = m22; data[2][3] = m23;
  data[3][0] = m30; data[3][1] = m31; data[3][2] = m32; data[3][3] = m33;
}

void matrix::translate3D(double tx, double ty, double tz)
{
  // 1 0 0 tx
  // 0 1 0 ty
  // 0 0 1 tz
  // 0 0 0 1
  // We know that this could be simplified algebraically for speed and
  // memory optimization, but this is easier to think about.  If we end up
  // needing the speed, or turn this into a game engine or something, then
  // this optimization is in order.  The same goes for the following transformations.
  matrix t = matrix(1, 0, 0, tx, 0, 1, 0, ty, 0, 0, 1, tz, 0, 0, 0, 1);
  *this *= t;
}

void matrix::scale3D(double s)
{
  scale3D(s, s, s);
}

void matrix::scale3D(double sx, double sy, double sz)
{
  matrix s = matrix(sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1);
  *this *= s;
}

void matrix::scale3D(point3D center, double s)
{
  scale3D(center, s, s, s);
}

void matrix::scale3D(point3D center, double sx, double sy, double sz)
{
  translate3D(-center.x(), -center.y(), -center.z());
  scale3D(sx, sy, sz);
  translate3D(center.x(), center.y(), center.z());
}

void matrix::scale3D(point3D center, double theta, double sx, double sy, double sz)
{
  translate3D(-center.x(), -center.y(), -center.z());
  rotate3Dz(-theta);
  scale3D(sx, sy, sz);
  rotate3Dz(theta);
  translate3D(center.x(), center.y(), center.z());
}

void matrix::rotate3Dz(double theta)
{
  matrix r = matrix(cos(theta), -sin(theta), 0, 0, sin(theta), cos(theta), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  *this *= r;
}

void matrix::sheer3Dx(double shx)
{
  matrix sh = matrix(1, shx, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  *this *= sh;
}

void matrix::sheer3Dy(double shy)
{
  matrix sh = matrix(1, 0, 0, 0, shy, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  *this *= sh;
}

void matrix::rotate3Dz(point3D center, double theta)
{
  translate3D(-center.x(), -center.y(), 0);
  rotate3Dz(theta);
  translate3D(center.x(), center.y(), 0);
}

matrix operator* (const matrix &x, const matrix &y)
{
  matrix m = matrix();
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      {
	m.data[i][j] = 0;
	for (int k = 0; k < 4; k++) {
	  m.data[i][j] += x.data[i][k] * y.data[k][j];
	}
      }
  return m;
}

void matrix::operator*= (const matrix &rhs)
{
  matrix m = *this;
  *this = rhs*m;
}

matrix operator+ (const matrix &x, const matrix &y)
{
  matrix m = matrix();
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      m.data[i][j] = x.data[i][j] + y.data[i][j];
    }
  }
  return m;
}

ostream& operator<< (ostream & out, const matrix &p)
{
  out << "matrix:" << endl;
  for (int i = 0; i < 4; i++)
    {
      out << "     ";
      for (int j = 0; j < 4; j++)
	out << "[" << p.data[i][j] << "] ";
      out << endl;
    }
  return out;
}

point3D operator+ (const point3D &x, const point3D &y)
{
  point3D p = point3D();
  for (int i = 0; i < 4; i++) {
    p.data[i] = x.data[i] + y.data[i];
  }
  return p;
}

point3D::point3D() {}

point3D::point3D(double x, double y, double z)
{
  data[0] = x;
  data[1] = y;
  data[2] = z;
  data[3] = 1;
}

point3D::point3D(double x, double y, double z, double h)
{
  data[0] = x;
  data[1] = y;
  data[2] = z;
  data[3] = h;
}

point3D::point3D(const point3D &copy)
{
  for (int i = 0; i < 4; i++) {
    data[i] = copy.data[i];
  }
}

point point3D::getPoint()
{
  return point(data[0], data[1]);
}

std::ostream& operator<< (std::ostream & out, const point3D &p)
{
  out << "(";
  for (int i = 0; i < 3; i++)
    {
      out << p.data[i] << ", ";
    }
  out << p.data[3] << ")";
  return out;
}

double point3D::x() { return data[0]; }
double point3D::y() { return data[1]; }
double point3D::z() { return data[2]; }

point3D operator* (const matrix &x, const point3D &y)
{
  point3D p = point3D();
  for (int i = 0; i < 4; i++) {
    p.data[i] = 0;
    for (int j = 0; j < 4; j++) {
      p.data[i] += x.data[i][j] * y.data[j];
    }
  }
  return p;
}

matrix& matrix::operator= (const double rhs[])
{
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      data[i][j] = rhs[j * 4 + 1];
    }
  }
  return *this;
}

const double matrix::I[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
