#include <math.h>
#include "fractal.h"

julia::julia()
{
  cerr << "You should never be constructing an empty Julia set!" << endl;
  data = NULL;
}

julia::julia(double x0, double y0, double x1, double y1, double cx, double cy, int sampleWidth)
{
  double x, y, xOld, yOld;
  int threshold = 100;

  if ((x0 > x1) || (y0 > y1))
    cerr << "Please make sure you define the lower left corner followed by the upper left corner." << endl;

  cols = sampleWidth; rows = int(sampleWidth * fabs(y1 - y0) / fabs(x1 - x0));

  data = new int[rows * cols];

  int n;
  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      xOld = i / double(cols) * (x1 - x0) + x0;
      yOld = j / double(rows) * (y1 - y0) + y0;
      for (n = 0; n < 255; n++) {
	x = xOld * xOld - yOld * yOld - cx;
	y = 2 * xOld * yOld - cy;
	if (sqrt(x * x + y * y) > threshold) {
	  break;
	}
	xOld = x; yOld = y;
      }
      data[j * cols + i] = n;
    }
  }
}

julia::~julia()
{
  if (data != NULL)
    free(data);
}

image julia::drawImage()
{
  image out = image(cols, rows);
  int n;

  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      n = data[j * cols + i];
      out.drawPoint(i, j, Pixel(n, 0, 0));
    }
  }
  
  return out;
}




mandelbrot::mandelbrot()
{
  cerr << "You should never be constructing an empty Mandelbrot set!" << endl;
  data = NULL;
}

mandelbrot::mandelbrot(double x0, double y0, double x1, double y1, int sampleWidth)
{
  double x, y, xOld, yOld;
  int threshold = 100;
  double cx, cy;

  if ((x0 > x1) || (y0 > y1))
    cerr << "Please make sure you define the lower left corner followed by the upper left corner." << endl;

  cols = sampleWidth; rows = int(sampleWidth * (y1 - y0) / (x1 - x0));

  data = new int[rows * cols];

  int n;
  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      cx = i / double(cols) * (x1 - x0) + x0;
      cy = j / double(rows) * (y1 - y0) + y0;
      xOld = yOld = 0;
      for (n = 0; n < 32; n++) {
	x = xOld * xOld - yOld * yOld - cx;
	y = 2 * xOld * yOld - cy;
	if (sqrt(x * x + y * y) > threshold) {
	  break;
	}
	xOld = x; yOld = y;
      }
      data[j * cols + i] = n * 8;
    }
  }
}

mandelbrot::~mandelbrot()
{
  if (data != NULL)
    free(data);
}

image mandelbrot::drawImage()
{
  image out = image(cols, rows);
  int n;

  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      n = data[j * cols + i];
      out.drawPoint(i, j, Pixel(n, 0, 0));
    }
  }
  
  return out;
}




