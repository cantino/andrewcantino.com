#include "image.h"
#include <math.h>

image::image()
{
  data = NULL;
  alpha = NULL;
  color = Pixel(255,255,255);
}

image::image(string file)
{
  color = Pixel(255,255,255);
  readImage(file);
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
}

image::image(const image &copy)
{

  rows = copy.rows; cols = copy.cols; colors = copy.colors;
  color = copy.color;
  
  data = new Pixel[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    data[i] = copy.data[i];
  alpha = new unsigned char[rows * cols]; 
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = copy.alpha[i];
}

image::image(int cols, int rows)
{
  color = Pixel(255,255,255);
  data = new Pixel[rows * cols];
  this->rows = rows; this->cols = cols; colors = 255;
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
}

image::image(int cols, int rows, Pixel c)
{
  color = c;
  data = new Pixel[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    data[i] = color;
  this->rows = rows; this->cols = cols; colors = 255;
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
}

image::~image()
{
  if (data != NULL) {
    free(data);
  }
  if (alpha != NULL) {
    free(alpha);
  }
}

void image::readImage(string file)
{
  data = readPPM(&rows, &cols, &colors, file.c_str());
}

void image::writeImage(string file)
{
  writePPM(data, rows, cols, colors, file.c_str());
}

bool image::inImage(int x, int y)
{
  return (x > -1) && (y > -1) && (x < cols) && (y < rows);
}

void image::drawPoint(int x, int y)
{
  if (inImage(x, y)) {
    data[y * cols + x] = color;
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

void image::drawPoint(int x, int y, Pixel color)
{
  if (inImage(x, y)) {
    data[y * cols + x] = color;
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

void image::drawPoint(int x, int y, Pixel color, unsigned char a)
{
  if (inImage(x, y)) {
    data[y * cols + x].r = int((a/255.0)*color.r + (1 - a/255.0)*data[y * cols + x].r);
    data[y * cols + x].g = int((a/255.0)*color.g + (1 - a/255.0)*data[y * cols + x].g);
    data[y * cols + x].b = int((a/255.0)*color.b + (1 - a/255.0)*data[y * cols + x].b);
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

Pixel image::getPoint(int x, int y)
{
  if (inImage(x, y) && data != NULL)
    {
      return data[y * cols + x];
    } else {
      cerr << "Range or data error in getPoint" << endl;
    }
  return Pixel();
}

image image::rotate(double rad)
{
  image out = image(cols, rows);
  
  double x, y;
  double r, g, b, a;
  double distance, totalDist;
  int k, l;
  for (int i = -cols / 2; i < cols / 2; i++) {
    for (int j = -rows / 2; j < rows / 2; j++) {
      x = i * cos(-rad) - j * sin(-rad) + cols / 2.0;
      y = j * cos(-rad) + i * sin(-rad) + rows / 2.0;
      totalDist = 0;
      r = 0; g = 0; b = 0; a = 0;
       if (inImage(x, y)) {
      	for (k = int(x - 1); k <= int(x + 1); k++) {
	  for (l = int(y - 1); l <= int(y + 1); l++) {
	    if (inImage(k, l)) {
	      distance = 1 / dist(x, y, k, l);
	      totalDist += distance;
	      Pixel p = getPoint(k, l);
	      a = a + distance * getAlpha(k, l);
	      r = r + distance * p.r;
	      g = g + distance * p.g;
	      b = b + distance * p.b;
	    }
	  }
	}
	out.setAlpha(i + cols / 2, j + rows / 2, a / totalDist);
	out.drawPoint(i + cols / 2, j + rows / 2, Pixel(r / totalDist, g / totalDist, b / totalDist));
      //out.setAlpha(i + cols / 2, j + rows / 2, getAlpha(x, y));
      //out.drawPoint(i + cols / 2, j + rows / 2, getPoint(x, y));
      } else {
	out.drawPoint(i + cols / 2, j + rows / 2, Pixel(255, 255, 255));
	out.setAlpha(i + cols / 2, j + rows / 2, 0);
      }
    }
  }
  
  return out;
}

image image::scale(double factor)
{
  int newRows = int(rows * factor);
  int newCols = int(cols * factor);

  image out = image(newCols, newRows);
  
  double r, g, b, a;
  int k, l;
  double invFactor;
  double distance, totalDist;

  invFactor = 1.0 / factor;
  for (int i = 0; i < newCols; i++) {
    for (int j = 0; j < newRows; j++) {
      totalDist = 0;
      r = 0; g = 0; b = 0; a = 0;
      if (invFactor > 1) {
	
	for (k = int(invFactor * i); k < int(invFactor * (i + 1)); k++) {
	  for (l = int(invFactor * j); l < int(invFactor * (j + 1)); l++) {
	    distance = 1 / dist(invFactor * (i + 0.5), invFactor * (j + 0.5), k + 0.5, l + 0.5);
	    totalDist += distance;
	    Pixel p = getPoint(k, l);
	    a = a + distance * getAlpha(k, l);
	    r = r + distance * p.r;
	    g = g + distance * p.g;
	    b = b + distance * p.b;
	  }
	}
	out.setAlpha(i, j, a / totalDist);
	out.drawPoint(i, j, Pixel(r / totalDist, g / totalDist, b / totalDist));
      
	//out.setAlpha(i, j, getAlpha(invFactor * i, invFactor * j));
	//out.drawPoint(i, j, getPoint(invFactor * i, invFactor * j));
	} else {
	out.setAlpha(i, j, getAlpha(invFactor * i, invFactor * j));
	out.drawPoint(i, j, getPoint(invFactor * i, invFactor * j));
	/*totalDist = 0;
	r = 0; g = 0; b = 0; a = 0;
	  for (k = int(invFactor * i - 20); k <= int(invFactor * i + 20); k++) {
	    for (l = int(invFactor * j - 20); l <= int(invFactor * j + 20); l++) {
	      if (inImage(k, l)) {
		distance = 1 / dist(invFactor * i, invFactor * j, k, l);
		totalDist += distance;
		Pixel p = getPoint(k, l);
		a = a + distance * getAlpha(k, l);
		r = r + distance * p.r;
		g = g + distance * p.g;
		b = b + distance * p.b;
	      }
	    }
	  }
	out.setAlpha(i, j, a / totalDist);
	out.drawPoint(i, j, Pixel(r / totalDist, g / totalDist, b / totalDist));*/
      }
    }
  }
  return out;
}

double image::dist(double x1, double y1, double x2, double y2)
{
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

unsigned char image::getAlpha(int x, int y)
{
  if (inImage(x, y) && data != NULL)
    {
      return alpha[y * cols + x];
    } else {
      cerr << "Range or data error in getAlpha" << endl;
    }
    return 0;
}

void image::setAlpha(int x, int y, unsigned char a)
{
  if (inImage(x, y) && alpha != NULL)
    {
      alpha[y * cols + x] = a;
    } else {
      cerr << "Range or data error in setAlpha" << endl;
    }
}

void image::medianFilterAlpha()
{
}

void image::medianFilter()
{
}

void image::drawImage(int x, int y, image i)
{
  for (int a = 0; a < i.cols; a++)
    for (int b = 0; b < i.rows; b++)
      if (inImage(x + a, y + b))
	// This is silly because drawPoint calls inImage too, but this helps
	// to hide the cerr messages.  We should just inline inImage here
	// at some point for speed.
	{
	  drawPoint(x + a, y + b, i.getPoint(a, b), i.getAlpha(a, b));
	}
}

// 4-connected shrink (hacked from Andrew's old vision code)
// (Uses the fact that the second boolean in an anded if sequence
// will not be run if the first fails.)
// Also, assumes that it's a boolean alpha mask with 1 as 255 and 0 as 0.
void image::shrinkAlpha() {
  unsigned char *buffer = new unsigned char[rows * cols];
  int toggle = 0, i, j;
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      buffer[i*cols+j] = alpha[i*cols+j];
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      if (buffer[i*cols+j] == 255)
	{
	  toggle = 0;
	  if ((i-1 > -1) && (buffer[(i-1)*cols+j] == 0))
	    toggle = 1;
	  if ((i+1 < rows) && (buffer[(i+1)*cols+j] == 0))
	    toggle = 1;
	  if ((j+1 < cols) && (buffer[i*cols+j+1] == 0))
	    toggle = 1;
	  if ((j-1 > -1) && (buffer[i*cols+j-1] == 0))
	    toggle = 1;
	  if (toggle)
	    alpha[i*cols+j] = 0;
	}
}

















































