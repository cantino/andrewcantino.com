#ifndef PPMIO_H

#define PPMIO_H

struct Pixel {
  unsigned char r;
  unsigned char g;
  unsigned char b;
  Pixel();
  Pixel(unsigned char r, unsigned char g, unsigned char b);
};

Pixel *readPPM(int *rows, int *cols, int * colors, const char *filename);
void writePPM(Pixel *image, int rows, int cols, int colors, const char *filename);

unsigned char *readPGM(int *rows, int *cols, int *intensities, char *filename);
void writePGM(unsigned char *image, long rows, long cols, int intensities, char *filename);

#endif

