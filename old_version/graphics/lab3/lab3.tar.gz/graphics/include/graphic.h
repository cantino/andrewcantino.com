#ifndef GRAPHIC_H
#define GRAPHIC_H

#include "image.h"
#include "ppmIO.h"

class graphic {
 public:
  virtual void draw(image &i) = 0;
  virtual void drawFilled(image &i) = 0;
};

class point : public graphic {
 public:
  long x, y;
  point();
  point(long x, long y);
  point(const point &p);
  inline bool operator== (point p) const;
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

class line : public graphic {
 public:
  point start, end;
  line();
  line(point start, point end);
  line(int x1, int y1, int x2, int y2);
  line(const line &l);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

class rect : public graphic {
 public:
  point lowerL, upperR;
  rect();
  rect(point ll, point ur);
  rect(point ll, int width, int height);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

class circle : public graphic {
 public:
  point center;
  double r;
  circle();
  circle(point c, double r);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

class ellipse : public graphic {
 public:
  point center;
  int rx, ry;
  ellipse();
  ellipse(point c, int rx, int ry);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

class polyline : public graphic {
 public:
  point *points;
  int pointCount, n;
  polyline();
  polyline(int n);
  virtual ~polyline();
  void addPoint(point p);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

struct edgeRecord {
  int yStart, yEnd;
  double xIntersect, dxPerScan;
};

class polygon : public graphic {
 public:
  point *points;
  int pointCount, n;
  polygon();
  polygon(int n);
  polygon(const polygon &p);
  polygon& operator= (const polygon &rhs);
  virtual ~polygon();
  void addPoint(point p);
  virtual void draw(image &i);
  virtual void drawFilled(image &i);
};

#endif
