#ifndef FRACTAL_H
#define FRACTAL_H

#include "image.h"

class julia {
 public:
  int *data;
  int rows, cols;

  julia();
  julia(double x0, double y0, double x1, double y1, double cx, double cy, int sampleWidth);
  ~julia();

  image drawImage();
};

class mandelbrot {
 public:
  int *data;
  int rows, cols;

  mandelbrot();
  mandelbrot(double x0, double y0, double x1, double y1, int sampleWidth);
  ~mandelbrot();

  image drawImage();
};

#endif
