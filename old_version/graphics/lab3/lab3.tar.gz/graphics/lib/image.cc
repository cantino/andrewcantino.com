#include "image.h"
#include "ppmIO.h"
#include <math.h>
#include <list>

image::image()
{
  data = NULL;
  alpha = NULL;
  color = Pixel(255,255,255);
  clearGradient();
  disablePattern();
  setPatternOrigin(point(0, 0));
}

image::image(string file)
{
  color = Pixel(255,255,255);
  readImage(file);
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
  clearGradient();
  disablePattern();
  setPatternOrigin(point(0, 0));
}

image::image(const image &copy)
{

  rows = copy.rows; cols = copy.cols; colors = copy.colors;
  color = copy.color;
  
  data = new Pixel[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    data[i] = copy.data[i];
  alpha = new unsigned char[rows * cols]; 
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = copy.alpha[i];
  clearGradient();
  disablePattern();
  setPatternOrigin(point(0, 0));
}

image::image(int cols, int rows)
{
  color = Pixel(255,255,255);
  data = new Pixel[rows * cols];
  this->rows = rows; this->cols = cols; colors = 255;
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
  clearGradient();
  disablePattern();
  setPatternOrigin(point(0, 0));
}

image::image(int cols, int rows, Pixel c)
{
  color = Pixel(0, 0, 0);
  data = new Pixel[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    data[i] = c;
  this->rows = rows; this->cols = cols; colors = 255;
  alpha = new unsigned char[rows * cols];
  for (int i = 0; i < rows * cols; i++)
    alpha[i] = 255;
  clearGradient();
  disablePattern();
  setPatternOrigin(point(0, 0));
}

image::~image()
{
  if (data != NULL) {
    //free(data);
  }
  if (alpha != NULL) {
    //delete [] alpha;
  }
}

int image::getRows() { return rows; }
int image::getCols() { return cols; }
Pixel image::getPenColor() { return color; }
void image::setPenColor(Pixel p) {
  color = p;
  clearGradient();
  disablePattern();
}

void image::readImage(string file)
{
  data = readPPM(&rows, &cols, &colors, file.c_str());
}

void image::writeImage(string file)
{
  writePPM(data, rows, cols, colors, file.c_str());
}

bool image::inImage(int x, int y)
{
  return (x > -1) && (y > -1) && (x < cols) && (y < rows);
}

void image::drawPixel(int x, int y)
{
  if (inImage(x, y)) {
    if (doGrad)
      {
	if (gradMode == 0)
	  {
	    double t = fabs((gradX*(x - gradStartX) + gradY*(y - gradStartY))/magGrad2);
	    double scale = (t*magGrad)/gradMaxLength;
	    drawPixel(x, y, Pixel(gradColor1.r + gradCr*scale*abs(gradColor2.r - gradColor1.r), gradColor1.g + gradCg*scale*abs(gradColor2.g - gradColor1.g), gradColor1.b + gradCb*scale*abs(gradColor2.b - gradColor1.b)));
	  }
	else if (gradMode == 1)
	  {
	    // Circular gradients
	    double scale = sqrt(pow(gradStartX - x, 2) + pow(gradStartY - y, 2))/gradMaxLength;
	    drawPixel(x, y, Pixel(gradColor1.r + gradCr*scale*abs(gradColor2.r - gradColor1.r), gradColor1.g + gradCg*scale*abs(gradColor2.g - gradColor1.g), gradColor1.b + gradCb*scale*abs(gradColor2.b - gradColor1.b)));
	  }
	else if (gradMode == 2)
	  {
	    

	  }
	else if (gradMode == 3)
	  {
	    // Circular Alpha gradients
	    double scale = sqrt(pow(gradStartX - x, 2) + pow(gradStartY - y, 2))/gradMaxLength;
	    drawPixel(x, y, gradColor1, (1 - scale) * 255);
	  }
      }
    else if (doPattern) {
      drawPixel(x, y, imPattern->getPixel(abs((x - patternOriginX) % imPattern->getCols()), abs((y - patternOriginY) % imPattern->getRows())));
    } else {
      data[(rows - y - 1) * cols + x] = color;
    }
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

void image::drawPixel(int x, int y, Pixel color)
{
  if (inImage(x, y)) {
    data[(rows - y - 1) * cols + x] = color;
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

void image::drawPixel(int x, int y, Pixel color, unsigned char a)
{
  if (inImage(x, y)) {
    data[(rows - y - 1) * cols + x].r = int((a/255.0)*color.r + (1 - a/255.0)*data[(rows - y - 1) * cols + x].r);
    data[(rows - y - 1) * cols + x].g = int((a/255.0)*color.g + (1 - a/255.0)*data[(rows - y - 1) * cols + x].g);
    data[(rows - y - 1) * cols + x].b = int((a/255.0)*color.b + (1 - a/255.0)*data[(rows - y - 1) * cols + x].b);
  } else {
    cerr << "(" << x << ", " << y << ") is not within the bounds of the image\n";
  }
}

Pixel image::getPixel(int x, int y)
{
  if (inImage(x, y) && data != NULL)
    {
      return data[(rows - y - 1) * cols + x];
    } else {
      cerr << "Range or data error in getPixel" << endl;
    }
  return Pixel();
}

void image::setGradColor(Pixel c1, Pixel c2)
{
  gradColor1 = c1;
  gradColor2 = c2;
  gradCr = (gradColor2.r - gradColor1.r)/255.0;
  gradCg = (gradColor2.g - gradColor1.g)/255.0;
  gradCb = (gradColor2.b - gradColor1.b)/255.0;
  //cout << "gradColor1: " << gradColor1 << " gradColor2: " << gradColor2 << endl;
  //cout << "gradCr: " << gradCr << "  gradCg: " << gradCg << "  gradCb: " << gradCb << endl;
  doGrad = true;
}

void image::setGradDirection(point d1, point d2)
{
  double mag = sqrt(pow(d2.x - d1.x, 2) + pow(d2.y - d1.y, 2));
  gradStartX = d1.x; gradStartY = d1.y;
  gradX = (d2.x - d1.x)/mag;
  gradY = (d2.y - d1.y)/mag;
  magGrad2 = gradX*gradX + gradY*gradY;
  magGrad = sqrt(magGrad2);
  //gradMaxLength = sqrt(rows*rows + cols*cols);
  gradMaxLength = mag;
  //cout << "gradX: " << gradX << " gradY: " << gradY << endl;
  //cout << "magGrad: " << magGrad << " gradMaxLength: " << gradMaxLength << endl;
  doGrad = true;
}

void image::setGradMode(int m)
{
  gradMode = m;
}

void image::clearGradient()
{
  doGrad = false;
  setGradMode(0);
}
 
void image::setPenPattern(const image &i)
{
  imPattern = new image(i);
  doPattern = true;
}
void image::setPatternOrigin(const point &p)
{
  patternOriginX = p.x;
  patternOriginY = p.y;
}
void image::disablePattern() { doPattern = false; }
void image::enablePattern() { doPattern = true; }
void image::clearPattern()
{
  free(imPattern);
  doPattern = false;
}


image image::rotate(double rad)
{
  image out = image(cols, rows);
  
  double x, y;
  double r, g, b, a;
  double distance, totalDist;
  int k, l;
  for (int i = -cols / 2; i < cols / 2; i++) {
    for (int j = -rows / 2; j < rows / 2; j++) {
      x = i * cos(-rad) - j * sin(-rad) + cols / 2.0;
      y = j * cos(-rad) + i * sin(-rad) + rows / 2.0;
      totalDist = 0;
      r = 0; g = 0; b = 0; a = 0;
       if (inImage(x, y)) {
      	for (k = int(x - 1); k <= int(x + 1); k++) {
	  for (l = int(y - 1); l <= int(y + 1); l++) {
	    if (inImage(k, l)) {
	      distance = 1 / dist(x, y, k, l);
	      totalDist += distance;
	      Pixel p = getPixel(k, l);
	      a = a + distance * getAlpha(k, l);
	      r = r + distance * p.r;
	      g = g + distance * p.g;
	      b = b + distance * p.b;
	    }
	  }
	}
	out.setAlpha(i + cols / 2, j + rows / 2, a / totalDist);
	out.drawPixel(i + cols / 2, j + rows / 2, Pixel(r / totalDist, g / totalDist, b / totalDist));
      //out.setAlpha(i + cols / 2, j + rows / 2, getAlpha(x, y));
      //out.drawPixel(i + cols / 2, j + rows / 2, getPixel(x, y));
      } else {
	out.drawPixel(i + cols / 2, j + rows / 2, Pixel(255, 255, 255));
	out.setAlpha(i + cols / 2, j + rows / 2, 0);
      }
    }
  }
  
  return out;
}

image image::scale(double factor)
{
  int newRows = int(rows * factor);
  int newCols = int(cols * factor);

  image out = image(newCols, newRows);
  
  double r, g, b, a;
  int k, l;
  double invFactor;
  double distance, totalDist;

  invFactor = 1.0 / factor;
  for (int i = 0; i < newCols; i++) {
    for (int j = 0; j < newRows; j++) {
      totalDist = 0;
      r = 0; g = 0; b = 0; a = 0;
      if (invFactor > 1) {
	
	for (k = int(invFactor * i); k < int(invFactor * (i + 1)); k++) {
	  for (l = int(invFactor * j); l < int(invFactor * (j + 1)); l++) {
	    distance = 1 / dist(invFactor * (i + 0.5), invFactor * (j + 0.5), k + 0.5, l + 0.5);
	    totalDist += distance;
	    Pixel p = getPixel(k, l);
	    a = a + distance * getAlpha(k, l);
	    r = r + distance * p.r;
	    g = g + distance * p.g;
	    b = b + distance * p.b;
	  }
	}
	out.setAlpha(i, j, a / totalDist);
	out.drawPixel(i, j, Pixel(r / totalDist, g / totalDist, b / totalDist));
      
	//out.setAlpha(i, j, getAlpha(invFactor * i, invFactor * j));
	//out.drawPixel(i, j, getPixel(invFactor * i, invFactor * j));
	} else {
	out.setAlpha(i, j, getAlpha(invFactor * i, invFactor * j));
	out.drawPixel(i, j, getPixel(invFactor * i, invFactor * j));
	/*totalDist = 0;
	r = 0; g = 0; b = 0; a = 0;
	  for (k = int(invFactor * i - 20); k <= int(invFactor * i + 20); k++) {
	    for (l = int(invFactor * j - 20); l <= int(invFactor * j + 20); l++) {
	      if (inImage(k, l)) {
		distance = 1 / dist(invFactor * i, invFactor * j, k, l);
		totalDist += distance;
		Pixel p = getPixel(k, l);
		a = a + distance * getAlpha(k, l);
		r = r + distance * p.r;
		g = g + distance * p.g;
		b = b + distance * p.b;
	      }
	    }
	  }
	out.setAlpha(i, j, a / totalDist);
	out.drawPixel(i, j, Pixel(r / totalDist, g / totalDist, b / totalDist));*/
      }
    }
  }
  return out;
}

double image::dist(double x1, double y1, double x2, double y2)
{
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

unsigned char image::getAlpha(int x, int y)
{
  if (inImage(x, y) && data != NULL)
    {
      return alpha[(rows - y - 1) * cols + x];
    } else {
      cerr << "Range or data error in getAlpha" << endl;
    }
    return 0;
}

void image::setAlpha(int x, int y, unsigned char a)
{
  if (inImage(x, y) && alpha != NULL)
    {
      alpha[(rows - y - 1) * cols + x] = a;
    } else {
      cerr << "Range or data error in setAlpha" << endl;
    }
}

void image::medianFilterAlpha()
{
}

void image::medianFilter()
{
}

void image::drawImage(int x, int y, image i)
{
  for (int a = 0; a < i.cols; a++)
    for (int b = 0; b < i.rows; b++)
      if (inImage(x + a, y + b))
	// This is silly because drawPixel calls inImage too, but this helps
	// to hide the cerr messages.  We should just inline inImage here
	// at some point for speed.
	{
	  drawPixel(x + a, y + b, i.getPixel(a, b), i.getAlpha(a, b));
	}
}

// 4-connected shrink (hacked from Andrew's old vision code)
// (Uses the fact that the second boolean in an anded if sequence
// will not be run if the first fails.)
// Also, assumes that it's a boolean alpha mask with 1 as 255 and 0 as 0.
void image::shrinkAlpha() {
  unsigned char *buffer = new unsigned char[rows * cols];
  int toggle = 0, i, j;
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      buffer[i*cols+j] = alpha[i*cols+j];
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
      if (buffer[i*cols+j] == 255)
	{
	  toggle = 0;
	  if ((i-1 > -1) && (buffer[(i-1)*cols+j] == 0))
	    toggle = 1;
	  if ((i+1 < rows) && (buffer[(i+1)*cols+j] == 0))
	    toggle = 1;
	  if ((j+1 < cols) && (buffer[i*cols+j+1] == 0))
	    toggle = 1;
	  if ((j-1 > -1) && (buffer[i*cols+j-1] == 0))
	    toggle = 1;
	  if (toggle)
	    alpha[i*cols+j] = 0;
	}
}

void image::drawGraphic(graphic &g)
{
  g.draw(*this);
}

void image::drawFilledGraphic(graphic &g)
{
  g.drawFilled(*this);
}

void image::gradFill(point l, Pixel grad)
{
  // Useful: http://www.msoe.edu/eecs/ce/courseinfo/stl/list.htm
  // This flood fill algorithm fills by lines, walking horizontially.
  // This version does a gradient fill, which means that it needs a
  // consitent background color to be able to fill in-place.
  // It would be worth making a non-inplace version that uses a buffer
  // at some point.  For now, we assume the color of l is the background.
  Pixel c = getPixel(l.x, l.y);
  bool openUp, openDown;
  std::list<point> s;
  s.push_back(l);

  double r = grad.r, g = grad.g, b = grad.b;
  // For now, lets just scale the gradient to the image width.
  double mag = sqrt((int) grad.r*grad.r + (int) grad.g*grad.g + (int) grad.b*grad.b);
  r /= mag; g /= mag; b /= mag;

  while (! s.empty())
    {
      point p = s.back();
      s.pop_back();
      // Walk all the way to the left.
      while (inImage(p.x - 1, p.y) && (Pixel) getPixel(p.x - 1, p.y) == c)
	p.x--;
      // Now walk right, coloring pixels and planting seeds as needed.
      openUp = openDown = false;
      while (inImage(p.x, p.y) && (Pixel) getPixel(p.x, p.y) == c)
	{
	  //drawPixel(p.x, p.y, Pixel(r*(p.x/double(cols))*200 + 55, g*(p.x/double(cols))*200 + 55, b*(p.x/double(cols))*200 + 55));
	  drawPixel(p.x, p.y);
	  
	  if (openUp && (Pixel) getPixel(p.x, p.y + 1) != c)
	    {
	      // This was an open region, because openUp is true, but now it's
	      // closed, so we should plant a seed up and back one to the left.
	      s.push_back(point(p.x - 1, p.y + 1));
	      openUp = false;
	    }
	  if (openDown && (Pixel) getPixel(p.x, p.y - 1) != c)
	    {
	      // This was an open region, because openDown is true, but now it's
	      // closed, so we should plant a seed down and back one to the left.
	      s.push_back(point(p.x - 1, p.y - 1));
	      openDown = false;
	    }
	  
	  if (inImage(p.x, p.y + 1) && (Pixel) getPixel(p.x, p.y + 1) == c)
	    openUp = true;
	  if (inImage(p.x, p.y - 1) && (Pixel) getPixel(p.x, p.y - 1) == c)
	    openDown = true;
	  
	  p.x++;
	}
      if (openUp && inImage(p.x - 1, p.y + 1))
	s.push_back(point(p.x - 1, p.y + 1));
      if (openDown && inImage(p.x - 1, p.y - 1))
	s.push_back(point(p.x - 1, p.y - 1));
    }
}

void image::fill(point l, Pixel c)
{
  // Useful: http://www.msoe.edu/eecs/ce/courseinfo/stl/list.htm
  // This flood fill algorithm fills by lines, walking horizontially.
  Pixel c2 = getPenColor();
  bool openUp, openDown;
  std::list<point> s;
  s.push_back(l);

  while (! s.empty())
    {
      point p = s.back();
      s.pop_back();
      // Walk all the way to the left.
      while (inImage(p.x - 1, p.y) && (Pixel) getPixel(p.x - 1, p.y) != c2 && (Pixel) getPixel(p.x - 1, p.y) != c)
	p.x--;
      // Now walk right, coloring pixels and planting seeds as needed.
      openUp = openDown = false;
      while (inImage(p.x, p.y) && (Pixel) getPixel(p.x, p.y) != c && (Pixel) getPixel(p.x, p.y) != c2)
	{
	  drawPixel(p.x, p.y);

	  if (openUp && ((Pixel) getPixel(p.x, p.y + 1) == c || (Pixel) getPixel(p.x, p.y + 1) == c2))
	    {
	      // This was an open region, because openUp is true, but now it's
	      // closed, so we should plant a seed up and back one to the left.
	      s.push_back(point(p.x - 1, p.y + 1));
	      openUp = false;
	    }
	  if (openDown && ((Pixel) getPixel(p.x, p.y - 1) == c || (Pixel) getPixel(p.x, p.y - 1) == c2))
	    {
	      // This was an open region, because openDown is true, but now it's
	      // closed, so we should plant a seed down and back one to the left.
	      s.push_back(point(p.x - 1, p.y - 1));
	      openDown = false;
	    }
	  
	  if (inImage(p.x, p.y + 1) && (Pixel) getPixel(p.x, p.y + 1) != c && (Pixel) getPixel(p.x, p.y + 1) != c2)
	    openUp = true;
	  if (inImage(p.x, p.y - 1) && (Pixel) getPixel(p.x, p.y - 1) != c && (Pixel) getPixel(p.x, p.y - 1) != c2)
	    openDown = true;

	  p.x++;
	}
      if (openUp && inImage(p.x - 1, p.y + 1))
	s.push_back(point(p.x - 1, p.y + 1));
      if (openDown && inImage(p.x - 1, p.y - 1))
	s.push_back(point(p.x - 1, p.y - 1));
    }
}









































