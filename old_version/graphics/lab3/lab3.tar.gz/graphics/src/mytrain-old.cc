#include "graphic.h"


int main(int argc, char *argv[])
{ 
  image im = image(700, 400, Pixel(255,255,255));
  line ll = line(point(0,150), point(700,150));
  im.setPenColor(Pixel(0,0,0));
  im.drawGraphic(ll);
  im.setGradDirection(point(0,150),point(700, 0));
  im.setGradColor(Pixel(0,75,0), Pixel(0,255,0));
  im.gradFill(point(0,0),Pixel(0,0,0));

  im.setGradDirection(point(0,150),point(0, 400));
  im.setGradColor(Pixel(135,206,235), Pixel(0,191,255));
  im.gradFill(point(5, 395),Pixel(0,0,0));

  //im.setPenColor(Pixel(0,0,0));
  //ll = line(point(0,130), point(700,130));  im.drawGraphic(ll);
  //ll = line(point(0,80), point(700,80));  im.drawGraphic(ll);
  rect r = rect(point(0,71), point(700,81));
  im.setGradDirection(point(0,71),point(0, 81));
  im.setGradColor(Pixel(20,20,20), Pixel(150,150,150));
  im.drawFilledGraphic(r);

  r = rect(point(0,97), point(700,105));
  im.setGradDirection(point(0,97),point(0, 105));
  im.setGradColor(Pixel(20,20,20), Pixel(150,150,150));
  im.drawFilledGraphic(r);

  for (int spacing = 0; spacing < 700; spacing += 40)
  {
    polygon p = polygon(5);
   
    p.addPoint(point(spacing + 5, 81));
    p.addPoint(point(spacing + 19, 81));
    p.addPoint(point(spacing + 35, 97));
    p.addPoint(point(spacing + 35, 105));
    p.addPoint(point(spacing + 30, 105));
    //im.setPenColor(Pixel(100,100,100));
    im.setGradDirection(point(spacing + 20,81),point(spacing, 100));
    im.setGradColor(Pixel(20,20,20), Pixel(150,150,150));
    im.drawFilledGraphic(p);
  }


  {
    Pixel carColor = Pixel(0,0,255);
    int width = 160, height = 80, bevel = 20;
    point o = point(500,100);
    im.setGradDirection(point(o.x,o.y),point(o.x + width, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    rect r = rect(o, point(o.x + width, o.y + height));  im.drawFilledGraphic(r);
    
    // Right side
    polygon p = polygon(4);
    p.addPoint(point(o.x + width + bevel, o.y + bevel));
    p.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    p.addPoint(point(o.x + width, o.y + height));
    p.addPoint(point(o.x + width, o.y));
    im.setGradDirection(point(o.x + width, o.y + height), point(o.x + width + bevel + 50,o.y));
    im.setGradColor(carColor, Pixel(0,0,0));
    im.drawFilledGraphic(p);
    
    // Top
    polygon g = polygon(4);
    g.addPoint(point(o.x, o.y + height));
    g.addPoint(point(o.x + width, o.y + height));
    g.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    g.addPoint(point(o.x + bevel, o.y + height + bevel));
    im.setGradDirection(point(o.x + bevel, o.y + height + bevel), point(o.x + width + 16, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    im.drawFilledGraphic(g);
    
    // Wheels
    circle c = circle(point(o.x + width/4.0, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + width/4.0, o.y), point(o.x + width/4.0 + (width/4.0)/2.0 + 1, o.y));
    im.setGradColor(Pixel(255,255,255),Pixel(0,0,0));
    im.setGradMode(1);
    im.drawFilledGraphic(c);
    c = circle(point(o.x + (width/4.0)*3, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + (width/4.0)*3, o.y), point(o.x + (width/4.0)*3 + (width/4.0)/2.0 + 1, o.y));
    im.drawFilledGraphic(c);
  }

  {
    Pixel carColor = Pixel(255,0,0);
    int width = 160, height = 80, bevel = 20;
    point o = point(275,100);
    im.setGradDirection(point(o.x,o.y),point(o.x + width, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    rect r = rect(o, point(o.x + width, o.y + height));  im.drawFilledGraphic(r);
    
    // Right side
    polygon p = polygon(4);
    p.addPoint(point(o.x + width + bevel, o.y + bevel));
    p.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    p.addPoint(point(o.x + width, o.y + height));
    p.addPoint(point(o.x + width, o.y));
    im.setGradDirection(point(o.x + width, o.y + height), point(o.x + width + bevel + 50,o.y));
    im.setGradColor(carColor, Pixel(0,0,0));
    im.drawFilledGraphic(p);
    
    // Top
    polygon g = polygon(4);
    g.addPoint(point(o.x, o.y + height));
    g.addPoint(point(o.x + width, o.y + height));
    g.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    g.addPoint(point(o.x + bevel, o.y + height + bevel));
    im.setGradDirection(point(o.x + bevel, o.y + height + bevel), point(o.x + width + 16, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    im.drawFilledGraphic(g);
    
    // Wheels
    circle c = circle(point(o.x + width/4.0, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + width/4.0, o.y), point(o.x + width/4.0 + (width/4.0)/2.0 + 1, o.y));
    im.setGradColor(Pixel(255,255,255),Pixel(0,0,0));
    im.setGradMode(1);
    im.drawFilledGraphic(c);
    c = circle(point(o.x + (width/4.0)*3, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + (width/4.0)*3, o.y), point(o.x + (width/4.0)*3 + (width/4.0)/2.0 + 1, o.y));
    im.drawFilledGraphic(c);
  }


{
    Pixel carColor = Pixel(0,255,0);
    int width = 160, height = 80, bevel = 20;
    point o = point(50,100);
 
    // Right side
    polygon h = polygon(4);
    h.addPoint(point(o.x, o.y));
    h.addPoint(point(o.x + width, o.y));
    h.addPoint(point(o.x + width, o.y + height));
    h.addPoint(point(o.x, o.y + height*.6));
    im.setGradDirection(point(o.x,o.y),point(o.x + width, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    im.drawFilledGraphic(h);
    
    // Right side
    polygon p = polygon(4);
    p.addPoint(point(o.x + width + bevel, o.y + bevel));
    p.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    p.addPoint(point(o.x + width, o.y + height));
    p.addPoint(point(o.x + width, o.y));
    im.setGradDirection(point(o.x + width, o.y + height), point(o.x + width + bevel + 50,o.y));
    im.setGradColor(carColor, Pixel(0,0,0));
    im.drawFilledGraphic(p);
    
    // Top
    polygon g = polygon(4);
    g.addPoint(point(o.x, o.y + height*.6));
    g.addPoint(point(o.x + width, o.y + height));
    g.addPoint(point(o.x + width + bevel, o.y + height + bevel));
    g.addPoint(point(o.x + bevel, o.y + height*.6 + bevel));
    im.setGradDirection(point(o.x + bevel, o.y + height*.6 + bevel), point(o.x + width + 25, o.y + height));
    im.setGradColor(Pixel(0,0,0), carColor);
    im.drawFilledGraphic(g);
    
    // Wheels
    circle c = circle(point(o.x + width/4.0, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + width/4.0, o.y), point(o.x + width/4.0 + (width/4.0)/2.0 + 1, o.y));
    im.setGradColor(Pixel(255,255,255),Pixel(0,0,0));
    im.setGradMode(1);
    im.drawFilledGraphic(c);
    c = circle(point(o.x + (width/4.0)*3, o.y), (width/4.0)/2.0);
    im.setGradDirection(point(o.x + (width/4.0)*3, o.y), point(o.x + (width/4.0)*3 + (width/4.0)/2.0 + 1, o.y));
    im.drawFilledGraphic(c);
  }

  
  //im.setGradDirection(point(0,0),point(400,400));
  //im.setGradColor(Pixel(0,0,255), Pixel(0,0,0));
  //rect r = rect(point(0,0),point(400,400));
  //im.drawFilledGraphic(r);

  /*
  line l = line(point(50,20), point(50,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,0,255), Pixel(255,0,0));
  l = line(point(100,20), point(100,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(255,255,0), Pixel(255,0,0));
  l = line(point(150,20), point(150,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,0,0), Pixel(0,0,255));
  l = line(point(200,20), point(200,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,255,0), Pixel(0,0,0));
  l = line(point(250,20), point(250,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(255,255,255), Pixel(0,255,0));
  l = line(point(300,20), point(300,380)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,255,255), Pixel(50,50,50));
  l = line(point(350,20), point(350,380)); im.drawGraphic(l);

  im.setGradDirection(point(0,0),point(400,0));
  
  im.setGradColor(Pixel(0,255,255), Pixel(50,50,50));
  l = line(point(20,50), point(380,50)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,0,255), Pixel(255,0,0));
  l = line(point(20,100), point(380,100)); im.drawGraphic(l);

  im.setGradColor(Pixel(255,0,0), Pixel(255,255,0));
  l = line(point(20,150), point(380,150)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,0,0), Pixel(0,0,255));
  l = line(point(20,200), point(380,200)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,255,0), Pixel(0,0,0));
  l = line(point(20,250), point(380,250)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,255,0), Pixel(255,255,255));
  l = line(point(20,300), point(380,300)); im.drawGraphic(l);

  im.setGradColor(Pixel(0,255,255), Pixel(50,50,50));
  l = line(point(20,350), point(380,350)); im.drawGraphic(l);
  */

  // Andrew's Portfolio 7
  //image im = image(400, 400, Pixel(255,255,255));
  //rect r = rect(point(0,0),point(400,400));
  //im.setGradColor(Pixel(255,255,255), Pixel(0,0,0));
  //im.setGradDirection(point(0,0),point(400,400));
  //im.drawFilledGraphic(r);

  //im.setGradColor(Pixel(255,0,0), Pixel(0,0,255));
  //im.setGradDirection(point(0,0),point(70,450));

  //circle c = circle(point(200,200), 200); im.drawFilledGraphic(c);

  //im.setGradColor(Pixel(255,255,0), Pixel(0,0,255));
  //im.setGradDirection(point(0,0),point(400,0));
  //  c = circle(point(200,200), 150); im.drawFilledGraphic(c);

  //im.setGradColor(Pixel(0,0,0), Pixel(255,0,0));
  //im.setGradDirection(point(100,100),point(300,300));
  //c = circle(point(200,200), 100); im.drawFilledGraphic(c);

  //im.setGradColor(Pixel(255,255,0), Pixel(0,255,0));
  //im.setGradDirection(point(0,150),point(0,250));
  //c = circle(point(200,200), 50); im.drawFilledGraphic(c);

  //im.gradFill(point(27, 30), Pixel(0, 0, 5));


  /*
  circle c = circle(point(200, 200), 200);
  im.setPenColor(Pixel(255,255,0));
  im.drawFilledGraphic(c);
  ellipse e = ellipse(point(125, 250), 50, 20);
  im.setPenColor(Pixel(176, 226, 255));
  im.drawFilledGraphic(e);
  e = ellipse(point(275, 250), 50, 20);
  im.drawFilledGraphic(e);
  c = circle(point(125, 250), 20);
  im.setPenColor(Pixel(248, 248, 255));
  im.drawFilledGraphic(c);
  c = circle(point(275, 250), 20);
  im.drawFilledGraphic(c);
  polyline p = polyline(4);
  p.addPoint(point(200, 230));
  p.addPoint(point(175, 150));
  p.addPoint(point(200, 150));
  p.addPoint(point(200, 155));
  im.setPenColor(Pixel(47, 79, 79));
  im.drawGraphic(p);
  polygon n = polygon(10);
  n.addPoint(point(100, 120));
  n.addPoint(point(200, 100));
  n.addPoint(point(300, 120));
  im.drawGraphic(n);
  im.setPenColor(Pixel(255, 255, 240));
  im.fill(point(200,102), Pixel(47, 79, 79));
  */

  cout << "wtf?" << endl;
  im.writeImage("../images/lab2.ppm");
}






