#include "graphic.h"

int main(int argc, char *argv[])
{
  image im = image(400, 400, Pixel(255, 255, 255));

  polygon p = polygon(4);
  p.addPoint(point(0, 160));
  p.addPoint(point(400, 160));
  p.addPoint(point(400, 400));
  p.addPoint(point(0, 400));
  im.setGradColor(Pixel(65,105,225), Pixel(135, 206, 250));
  im.setGradDirection(point(0,0), point(0,200));
  im.drawFilledGraphic(p);

  im.setPenColor(Pixel(0, 0, 0));
  p = polygon(4);
  p.addPoint(point(0, 0));
  p.addPoint(point(400, 0));
  p.addPoint(point(400, 160));
  p.addPoint(point(0, 160));
  im.drawFilledGraphic(p);
  
  image yellowDash = image(40, 1, Pixel(0, 0, 0));
  yellowDash.setPenColor(Pixel(255, 215, 0));
  line l = line(point(0,0), point(20,0)); yellowDash.drawGraphic(l);

  p = polygon(4);
  p.addPoint(point(0, 50));
  p.addPoint(point(400, 50));
  p.addPoint(point(400, 55));
  p.addPoint(point(0, 55));
  im.setPenPattern(yellowDash);
  im.drawFilledGraphic(p);
  im.disablePattern();

  im.setPenColor(Pixel(255, 165, 0));
  p = polygon(10);
  p.addPoint(point(340, 80));  
  p.addPoint(point(380, 140));
  p.addPoint(point(380, 180));
  p.addPoint(point(320, 180));
  p.addPoint(point(280, 220));
  p.addPoint(point(200, 220));
  p.addPoint(point(160, 180));
  p.addPoint(point(100, 180));
  p.addPoint(point(60, 120));
  p.addPoint(point(60, 80));
  im.drawFilledGraphic(p);

  im.setPenColor(Pixel(205, 205, 205));
  p = polygon(4);
  p.addPoint(point(134, 120));
  p.addPoint(point(194, 120));
  p.addPoint(point(194, 150));
  p.addPoint(point(164, 150));
  im.drawFilledGraphic(p);
  
  p = polygon(4);
  p.addPoint(point(208, 120));
  p.addPoint(point(268, 120));
  p.addPoint(point(238, 150));
  p.addPoint(point(208, 150));
  im.drawFilledGraphic(p);
  
  p = polygon(4);
  p.addPoint(point(280, 120));
  p.addPoint(point(320, 180));
  p.addPoint(point(280, 220));
  p.addPoint(point(240, 160));
  im.drawFilledGraphic(p);

  p = polygon(4);
  p.addPoint(point(200, 220));
  p.addPoint(point(160, 160));
  p.addPoint(point(120, 120));
  p.addPoint(point(160, 180));
  im.drawFilledGraphic(p);

  im.setPenColor(Pixel(0, 0, 0));
  p = polygon(8);
  p.addPoint(point(60, 80));
  p.addPoint(point(340, 80));
  p.addPoint(point(340, 120));
  p.addPoint(point(280, 120));
  p.addPoint(point(240, 160));
  p.addPoint(point(160, 160));
  p.addPoint(point(120, 120));
  p.addPoint(point(60, 120));
  im.drawGraphic(p);

  polyline pl = polyline(4);
  pl.addPoint(point(340, 80));
  pl.addPoint(point(380, 140));
  pl.addPoint(point(380, 180));
  pl.addPoint(point(340, 120));
  im.drawGraphic(pl);

  pl = polyline(8);
  pl.addPoint(point(380, 140));
  pl.addPoint(point(380, 180));
  pl.addPoint(point(320, 180));
  pl.addPoint(point(280, 220));
  pl.addPoint(point(200, 220));
  pl.addPoint(point(160, 180));
  pl.addPoint(point(100, 180));
  pl.addPoint(point(60, 120));
  im.drawGraphic(pl);
 

  //im.gradFill(point(100, 150), Pixel(1, 1, 1));



  im.setPenColor(Pixel(92, 92, 92));
  circle c = circle(point(120, 80), 20);
  im.drawFilledGraphic(c);
  c = circle(point(280, 80), 20);
  im.drawFilledGraphic(c);

  im.setPenColor(Pixel(192, 192, 192));
  c = circle(point(120, 80), 6);
  im.drawFilledGraphic(c);
  c = circle(point(280, 80), 6);
  im.drawFilledGraphic(c);

  im.setPenColor(Pixel(150, 150, 150));
  //im.fill(point(62, 82), Pixel(0, 0, 0));
  //im.fill(point(62, 122), Pixel(0, 0, 0));
  //im.fill(point(210, 180), Pixel(0, 0, 0));
  //im.fill(point(320, 140), Pixel(0, 0, 0));
  //im.fill(point(350, 120), Pixel(0, 0, 0));
  

  //im.gradFill(point(2, 180), Pixel(0, 0, 1));
  //im.gradFill(point(2, 2), Pixel(1, 1, 0));
  //im.gradFill(point(170, 140), Pixel(1, 1, 1));
  //im.gradFill(point(220, 140), Pixel(1, 1, 1));
 
  im.writeImage("../images/3Dcar.ppm");
}
