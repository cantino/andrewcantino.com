#include "model.h"
#include "graphic.h"
#include <math.h>
#include "view.h"

// ----------- modelPrimative ----------

int modelPrimative::getName()
{
  return 1;
}

// -------------- point3D --------------

point3D::point3D() {}

point3D::point3D(double x, double y, double z) : color(Pixel(0, 0, 0))
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = 1;
}

point3D::point3D(double x, double y, double z, double h) : color(Pixel(0, 0, 0))
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = h;
}

point3D::point3D(double x, double y, double z, Pixel color)
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = 1;
  this->color = color;
}
point3D::point3D(double x, double y, double z, double h, Pixel color)
{
  data[0] = x; data[1] = y; data[2] = z; data[3] = h;
  this->color = color;
}

Pixel point3D::getColor()
{
  return color;
}

void point3D::setColor(Pixel c)
{
  color = c;
}

double point3D::x() const { return data[0] / data[3]; }
double point3D::y() const { return data[1] / data[3]; }
double point3D::z() const { return data[2] / data[3]; }
double point3D::depth() const { return data[2]; }

double point3D::worldX() const { return worldData[0]; }
double point3D::worldY() const { return worldData[1]; }
double point3D::worldZ() const { return worldData[2]; }


void point3D::archive()
{
  worldData[0] = data[0]; worldData[1] = data[1]; worldData[2] = data[2];
}

point point3D::getPoint()
{
  return point(x(), y());
}

double point3D::magnitude()
{
  return sqrt(x()*x() + y()*y() + z()*z());
}

void point3D::normalize()
{
  double l = sqrt(data[0]*data[0] + data[1]*data[1] + data[2]*data[2]);
  data[0] = data[0] / l;
  data[1] = data[1] / l;
  data[2] = data[2] / l;
}

point3D point3D::normalized()
{
  double l = sqrt(data[0]*data[0] + data[1]*data[1] + data[2]*data[2]);
  return point3D(data[0] / l, data[1] / l, data[2] / l, data[3], color);
}

point3D crossProduct(point3D a, point3D b)
{
  return point3D(a.y()*b.z() - b.y()*a.z(),
		 a.z()*b.x() - b.z()*a.x(),
		 a.x()*b.y() - b.x()*a.y(),
		 1);
}

double dotProduct(point3D a, point3D b)
{
  return a.x()*b.x() + a.y()*b.y() + a.z()*b.z();
}

void point3D::operator*= (const matrix &rhs)
{
  *this = rhs * (*this);
}

std::ostream& operator<< (std::ostream & out, const point3D &p)
{
  out.precision(3);
  out << "(";
  for (int i = 0; i < 3; i++)
    {
      out << p.data[i] << ", ";
    }
  out << p.data[3] << ")";
  return out;
}

point3D operator+ (const point3D &x, const point3D &y)
{
  point3D p = point3D(); 
  p.data[0] = x.x() + y.x();
  p.data[1] = x.y() + y.y();
  p.data[2] = x.z() + y.z();
  p.data[3] = 1;
  p.color = Pixel((x.color.r + y.color.r) / 2, (x.color.g + y.color.g) / 2, (x.color.b + y.color.b) / 2);
  return p;
}

point3D operator- (const point3D &x, const point3D &y)
{
  point3D p = point3D();
  p.data[0] = x.x() - y.x();
  p.data[1] = x.y() - y.y();
  p.data[2] = x.z() - y.z();
  p.data[3] = 1;
  p.color = Pixel((x.color.r + y.color.r) / 2, (x.color.g + y.color.g) / 2, (x.color.b + y.color.b) / 2);
  return p;
}

point3D operator* (const double &d, const point3D &x)
{
  point3D p = point3D();
  p.data[0] = d * x.x();
  p.data[1] = d * x.y();
  p.data[2] = d * x.z();
  p.data[3] = 1;
  p.color = x.color;
  for (int i = 0; i < 3; i++) {
    p.worldData[i] = x.worldData[i];
  }
  return p;
}

void point3D::draw(matrix &m, image &i)
{
  point p = (m * (*this)).getPoint();
  i.drawGraphic(p);
}

void point3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(1);
  pRef3D.setFilled(false);
  point3D *p3D = new point3D(m * (*this));
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);
  polygonList.push_back(pRef3D);
}

// -------------- line3D ---------------

line3D::line3D() {}
line3D::line3D(point3D s, point3D e) : start(s), end(e) {}
void line3D::draw(matrix &m, image &i)
{
  line l = line((m * start).getPoint(), (m * end).getPoint());
  i.drawGraphic(l);
}
void line3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(2);
  pRef3D.setFilled(false);

  point3D *p3D = new point3D(m * start);
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);

  p3D = new point3D(m * end);
  pointList.push_back(p3D);
  pRef3D.addPoint(p3D);

  polygonList.push_back(pRef3D);

}

// ------------- polygon3D -------------

polygon3D::polygon3D() : points(NULL), filled(true), flat(false), shadowed(false) {}
polygon3D::polygon3D(int n) : pointCount(0), n(n), filled(true), flat(false), shadowed(false)
{
  points = new point3D[n];
}

polygon3D::polygon3D(const polygon3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
  filled = p.filled;
  flat = p.flat;
  kD = p.kD;
  kS = p.kS;
  nS = p.nS;
  shadowed = p.shadowed;
}

polygon3D& polygon3D::operator= (const polygon3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
    flat = rhs.flat;
    filled = rhs.filled;
    kD = rhs.kD;
    kS = rhs.kS;
    nS = rhs.nS;
    shadowed = rhs.shadowed;
  }
  return *this;
}

polygon3D::~polygon3D()
{
  delete[] points;
}

void polygon3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polygon." << endl;
  }
}

void polygon3D::setFilled(bool m) { filled = m; }

void polygon3D::setFlat(bool m) { flat = m; }

void polygon3D::setMaterial(colorVector kD, colorVector kS, double nS)
{
  this->kD = kD;
  this->kS = kS;
  this->nS = nS;
}

void polygon3D::draw(matrix &m, image &im)
{
  polygon p = polygon(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());

  if (filled)
    im.drawFilledGraphic(p);
  else
    im.drawGraphic(p);
}

void polygon3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  polygonRef3D pRef3D = polygonRef3D(pointCount);
  point3D *p3D;
  pRef3D.flat = flat;
  pRef3D.filled = filled;
  pRef3D.kD = kD;
  pRef3D.kS = kS;
  pRef3D.nS = nS;
  pRef3D.shadowed = shadowed;
  for (int i = 0; i < pointCount; i++) {
    p3D = new point3D(m * points[i]);
    pointList.push_back(p3D);
    pRef3D.addPoint(p3D);
  }

  polygonList.push_back(pRef3D);

}

// ------------ polyline3D -------------

polyline3D::polyline3D() : points(NULL) {}
polyline3D::polyline3D(int n) : pointCount(0), n(n)
{
  points = new point3D[n];
}

polyline3D::polyline3D(const polyline3D &p)
{
  pointCount = p.pointCount;
  n = p.n;
  points = new point3D[n];
  for (int i = 0; i < n; i++) {
    points[i] = p.points[i];
  }
}

polyline3D& polyline3D::operator= (const polyline3D &rhs)
{
  if (this != &rhs) {
    delete[] points;
    pointCount = rhs.pointCount;
    n = rhs.n;
    points = new point3D[n];
    for (int i = 0; i < n; i++) {
      points[i] = rhs.points[i];
    }
  }
  return *this;
}

polyline3D::~polyline3D()
{
  delete[] points;
}

void polyline3D::addPoint(point3D p)
{
  if (pointCount < n) {
    points[pointCount++] = p;
  } else {
    cerr << "You cannot add more than " << n << " point3Ds to this polyline." << endl;
  }
}

void polyline3D::draw(matrix &m, image &im)
{
  polyline p = polyline(pointCount);
  for (int i = 0; i < pointCount; i++)
    p.addPoint((m * points[i]).getPoint());
  im.drawGraphic(p);
}

// ---------- polygonMesh3D -----------

polygonMesh::polygonMesh() {}

polygonMesh::polygonMesh(vector<point3D*> * pointList, list<polygonRef3D> * polygonList)
{
  pntList = pointList;
  polyList = polygonList;
}

void polygonMesh::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  for (vector<point3D*>::iterator iter = pntList->begin(); iter != pntList->end(); iter++) {
    **iter *= m;
    pointList.push_back(*iter);
  }

  for (list<polygonRef3D>::iterator iter = polyList->begin(); iter != polyList->end(); iter++)
    polygonList.push_back(*iter);
}

void polygonMesh::draw(matrix &m, image &im) {}


// ---------------box3D----------------


box3D::box3D() : lx(1), ly(1), lz(1) {}

box3D::box3D(double lx, double ly, double lz)
{
  this->lx = lx;
  this->ly = ly;
  this->lz = lz;
}

box3D::~box3D() {}

void box3D::setMaterial(colorVector kD, colorVector kS, double nS)
{
  this->kD = kD;
  this->kS = kS;
  this->nS = nS;
}

void box3D::setFlat(bool b) { flat = b; }

void box3D::draw(matrix &m, image &i) {}

void box3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  point3D *p1 = new point3D(m * point3D(lx/2.0, ly/2.0, lz/2.0));
  point3D *p2 = new point3D(m * point3D(lx/2.0, -ly/2.0, lz/2.0));
  point3D *p3 = new point3D(m * point3D(-lx/2.0, ly/2.0, lz/2.0));
  point3D *p4 = new point3D(m * point3D(-lx/2.0, -ly/2.0, lz/2.0));
  point3D *p5 = new point3D(m * point3D(lx/2.0, ly/2.0, -lz/2.0));
  point3D *p6 = new point3D(m * point3D(lx/2.0, -ly/2.0, -lz/2.0));
  point3D *p7 = new point3D(m * point3D(-lx/2.0, ly/2.0, -lz/2.0));
  point3D *p8 = new point3D(m * point3D(-lx/2.0, -ly/2.0, -lz/2.0));  
  pointList.push_back(p1); pointList.push_back(p2);
  pointList.push_back(p3); pointList.push_back(p4);
  pointList.push_back(p5); pointList.push_back(p6);
  pointList.push_back(p7); pointList.push_back(p8);

  polygonRef3D s1 = polygonRef3D(4); polygonRef3D s2 = polygonRef3D(4);
  polygonRef3D s3 = polygonRef3D(4); polygonRef3D s4 = polygonRef3D(4);
  polygonRef3D s5 = polygonRef3D(4); polygonRef3D s6 = polygonRef3D(4);

  s1.addPoint(p1); s1.addPoint(p3); s1.addPoint(p4); s1.addPoint(p2);
  s2.addPoint(p2); s2.addPoint(p4); s2.addPoint(p8); s2.addPoint(p6);
  s3.addPoint(p4); s3.addPoint(p3); s3.addPoint(p7); s3.addPoint(p8);
  s4.addPoint(p1); s4.addPoint(p2); s4.addPoint(p6); s4.addPoint(p5);
  s5.addPoint(p1); s5.addPoint(p5); s5.addPoint(p7); s5.addPoint(p3);
  s6.addPoint(p8); s6.addPoint(p7); s6.addPoint(p5); s6.addPoint(p6);

  s1.kD = kD; s1.kS = kS; s1.nS = nS; s1.flat = flat;
  s2.kD = kD; s2.kS = kS; s2.nS = nS; s2.flat = flat;
  s3.kD = kD; s3.kS = kS; s3.nS = nS; s3.flat = flat;
  s4.kD = kD; s4.kS = kS; s4.nS = nS; s4.flat = flat;
  s5.kD = kD; s5.kS = kS; s5.nS = nS; s5.flat = flat;
  s6.kD = kD; s6.kS = kS; s6.nS = nS; s6.flat = flat;

  polygonList.push_back(s1); polygonList.push_back(s2);
  polygonList.push_back(s3); polygonList.push_back(s4);
  polygonList.push_back(s5); polygonList.push_back(s6);
}

// ------------ pyramid3D -------------

pyramid3D::pyramid3D() {}

pyramid3D::pyramid3D(point3D top, polygon3D base)
{
  this->top = top;
  this->base = base;
}

pyramid3D::~pyramid3D() {}

void pyramid3D::setMaterial(colorVector kD, colorVector kS, double nS)
{
  this->kD = kD;
  this->kS = kS;
  this->nS = nS;
}

void pyramid3D::setFlat(bool b) { flat = b; }

void pyramid3D::draw(matrix &m, image &i) {}

void pyramid3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  point3D *theHead = new point3D(m * top);
  pointList.push_back(theHead);
  polygonRef3D container = polygonRef3D(base.pointCount);
  container.kD = kD;
  container.kS = kS;
  container.nS = nS;
  container.flat = flat;
  for (int i = 0; i < base.pointCount; i++) {
    point3D *p3D = new point3D(m * base.points[i]);
    container.addPoint(p3D);
    pointList.push_back(p3D);
  }
  polygonList.push_back(container);
  for (int i = 0; i < base.pointCount - 1; i++) {
    polygonRef3D pRef3D = polygonRef3D(3);
    pRef3D.addPoint(container.points[i]);
    pRef3D.addPoint(container.points[i+1]);
    pRef3D.addPoint(theHead);
    pRef3D.kD = kD;
    pRef3D.kS = kS;
    pRef3D.nS = nS;
    pRef3D.flat = flat;
    polygonList.push_back(pRef3D);
  }
  polygonRef3D pRef3D = polygonRef3D(3);
  pRef3D.addPoint(container.points[base.pointCount - 1]);
  pRef3D.addPoint(container.points[0]);
  pRef3D.addPoint(theHead);
  pRef3D.kD = kD;
  pRef3D.kS = kS;
  pRef3D.nS = nS;
  pRef3D.flat = flat;
  polygonList.push_back(pRef3D);
}

// ---------- paramObject3D -----------

paramObject3D::paramObject3D() {}

paramObject3D::paramObject3D(point3D* (*f)(double, double), double dU, double dV)
{
  this->f = f;
  this->dU = dU;
  this->dV = dV;
}

paramObject3D::~paramObject3D() {}

void paramObject3D::setMaterial(colorVector kD, colorVector kS, double nS)
{
  this->kD = kD;
  this->kS = kS;
  this->nS = nS;
}

void paramObject3D::setFlat(bool b) { flat = b; }

void paramObject3D::draw(matrix &m, image &i) {}

void paramObject3D::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList)
{
  double u, v = .2;
  int initialListLoc = pointList.size();

  for (u = 0; u < 1; u += dU) {
    point3D *t = new point3D(m * *f(u, 0));
    pointList.push_back(t);
  }
 
  for (v = dV; v < 1; v += dV) {
  
    for (u = 0; u < 1; u += dU) {
      point3D *t = new point3D(m * *f(u, v));
      pointList.push_back(t);
      int myListLoc = pointList.size() - 1;

      if (u != 0) {
	polygonRef3D pRef3D1 = polygonRef3D(3);
	pRef3D1.addPoint(pointList[myListLoc]);
	pRef3D1.addPoint(pointList[myListLoc - 1]);
	pRef3D1.addPoint(pointList[myListLoc - 1.0 / dU]);	
	pRef3D1.setMaterial(kD, kS, nS);
	pRef3D1.setFlat(true);
	pRef3D1.shadowed = false;
	polygonList.push_back(pRef3D1);
      }

      if (u < 1 - dU) {
	polygonRef3D pRef3D2 = polygonRef3D(3);
	pRef3D2.addPoint(pointList[myListLoc]);
	pRef3D2.addPoint(pointList[myListLoc - 1.0 / dU]);
	pRef3D2.addPoint(pointList[myListLoc - (1.0 / dU - 1)]);	
	pRef3D2.setMaterial(kD, kS, nS);
	pRef3D2.setFlat(true);
	pRef3D2.shadowed = false;
	polygonList.push_back(pRef3D2);
      } else {
	polygonRef3D pRef3D2 = polygonRef3D(3);
	pRef3D2.addPoint(pointList[myListLoc]);
	pRef3D2.addPoint(pointList[myListLoc - 1.0 / dU]);
	pRef3D2.addPoint(pointList[myListLoc - (2.0 / dU - 1)]);
	pRef3D2.setMaterial(kD, kS, nS);
	pRef3D2.setFlat(true);
	pRef3D2.shadowed = false;
	polygonList.push_back(pRef3D2);

	polygonRef3D pRef3D3 = polygonRef3D(3);
	pRef3D3.addPoint(pointList[myListLoc]);	
	pRef3D3.addPoint(pointList[myListLoc - (2.0 / dU - 1)]);
	pRef3D3.addPoint(pointList[myListLoc - (1.0 / dU - 1)]);
	pRef3D3.setMaterial(kD, kS, nS);
	pRef3D3.setFlat(true);
	pRef3D3.shadowed = false;
	polygonList.push_back(pRef3D3);
      }
    } 
  }

  for (u = 0; u < 1.0 / dU; u++) {
    int myListLoc = int((pointList.size() - 1) - (1.0 / dU - u));
   
    if (u < 1.0 / dU - 1) {
      polygonRef3D pRef3D1 = polygonRef3D(3);
      pRef3D1.addPoint(pointList[myListLoc]);
      pRef3D1.addPoint(pointList[myListLoc + 1]);
      pRef3D1.addPoint(pointList[initialListLoc + u]);
      pRef3D1.setMaterial(kD, kS, nS);
      pRef3D1.setFlat(true);
      pRef3D1.shadowed = false;
      polygonList.push_back(pRef3D1);
    } else {
      polygonRef3D pRef3D1 = polygonRef3D(3);
      pRef3D1.addPoint(pointList[myListLoc]);
      pRef3D1.addPoint(pointList[myListLoc - (1.0 / dU - 1)]);
      pRef3D1.addPoint(pointList[initialListLoc + u]);
      pRef3D1.setMaterial(kD, kS, nS);
      pRef3D1.setFlat(true);
      pRef3D1.shadowed = false;
      polygonList.push_back(pRef3D1);
    }
   
    if (u < 1.0 / dU - 1) {
      polygonRef3D pRef3D2 = polygonRef3D(3);
      pRef3D2.addPoint(pointList[myListLoc + 1]);
      pRef3D2.addPoint(pointList[initialListLoc + u + 1]);
      pRef3D2.addPoint(pointList[initialListLoc + u]);
      pRef3D2.setMaterial(kD, kS, nS);
      pRef3D2.setFlat(true);
      pRef3D2.shadowed = false;
      polygonList.push_back(pRef3D2);
    } else {
      polygonRef3D pRef3D2 = polygonRef3D(3);
      pRef3D2.addPoint(pointList[initialListLoc + u]);
      pRef3D2.addPoint(pointList[myListLoc - (1.0 / dU - 1)]);
      pRef3D2.addPoint(pointList[initialListLoc]);
      pRef3D2.setMaterial(kD, kS, nS);
      pRef3D2.setFlat(true);
      pRef3D2.shadowed = false;
      polygonList.push_back(pRef3D2);
    }
  }
  
}

