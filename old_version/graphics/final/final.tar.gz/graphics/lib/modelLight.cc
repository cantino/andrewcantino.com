#include "model.h"

modelLight::modelLight() {}

vector3D modelLight::getL(point3D P)
{
  switch (type) {
  case 1:
    return vector3D(loc.worldX() - P.x(), loc.worldY() - P.y(), loc.worldZ() - P.z()).normalized();
    break;
  case 2:
    return vector3D(loc.worldX() - P.x(), loc.worldY() - P.y(), loc.worldZ() - P.z()).normalized();
    break;
  case 3:
    return -D;
    break;
  default:
    return vector3D(loc.worldX() - P.x(), loc.worldY() - P.y(), loc.worldZ() - P.z()).normalized();
  }
}

colorVector modelLight::getI(vector3D L)
{
  double d;
  switch (type) {
  case 1:
    return I;
    break;
  case 2:
    d = dotProduct(D, L);
    if (cos_a < dotProduct(D, L)) {
      return I;
    } else {
      return colorVector();
    }
    break;
  case 3:
    return I;
    break;
  default:
    return I;
  }
}

int modelLight::getName()
{
  return 4;
}

void modelLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList)
{
  cerr << "Render should always be overloaded by the child.\n";
}

pointLight::pointLight() { type = 1; }

pointLight::pointLight(colorVector I) {
  type = 1; 
  this->I = I;
  loc = point3D(0, 0, 0);
}

vector3D pointLight::getL(point3D P)
{
  return vector3D(loc.worldX() - P.x(), loc.worldY() - P.y(), loc.worldZ() - P.z()).normalized();
}

colorVector pointLight::getI(vector3D L)
{
  return I;
}

void pointLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList)
{
  loc *= m;
  lightList.push_back(*this);
}

spotLight::spotLight() { type = 2; }

spotLight::spotLight(colorVector I, vector3D D, double a) {
  type = 2;
  this->I = I;
  this->D = D.normalized();
  cos_a = cos(a);
  loc = point3D(0, 0, 0);
}

vector3D spotLight::getL(point3D P)
{
  return vector3D(loc.worldX() - P.x(), loc.worldY() - P.y(), loc.worldZ() - P.z()).normalized();
}

colorVector spotLight::getI(vector3D L)
{
  if (cos_a < dotProduct(-D, L)) {
    return I;
  } else {
    return colorVector();
  }
}

void spotLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList)
{
  loc *= m;
  lightList.push_back(*this);
}

sunLight::sunLight() { type = 3; }

sunLight::sunLight(colorVector I, vector3D D) {
  type = 3;
  this->I = I;
  this->D = D.normalized();
  loc = point3D(0, 0, 0);
}

vector3D sunLight::getL(point3D P)
{
  return -D;
}

colorVector sunLight::getI(vector3D L)
{
  return I;
}

void sunLight::render(matrix &m, vector<point3D*> &pointList, list<polygonRef3D> &polygonList, vector<modelLight> &lightList)
{
  lightList.push_back(*this);
}

