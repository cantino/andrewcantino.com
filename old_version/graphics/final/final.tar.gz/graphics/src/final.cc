#include "view.h"
#include <sstream>
#include <math.h>

using namespace std;

// Some global settings
int doWorldGravity = 1;
int doAirFriction = 1;
double airFrictionCoeff = .025; // .025;
double gravityConstant = 9.8;
double curTime = 0;
double timeStep = .0025;
#define DEFAULTK 1000
#define DEFAULTM .1

point3D* torus(double u, double v)
{
  double x, y, z;
  double c = 4;
  double a = 2;

  u *= 2 * 3.1415926;
  v *= 2 * 3.1415926;

  x = (c + a * cos(v)) * cos(u);
  y = (c + a * cos(v)) * sin(u);
  z = a * sin(v);

  return (new point3D(x, y, z));
}

// The mass structure for the physics model.
struct mass {
  vector3D l;
  vector3D v;
  vector3D force;
  point3D * target;
  double m;
  bool locked;
  
  // Memory (storage registers for Runga-Kutta)
  vector3D RKlocations[2];
  vector3D RKvelocities[2];

  mass();
  mass(vector3D l);
  double distTo(mass & t);
};

mass::mass() { m = DEFAULTM; v = vector3D(0, 0, 0); l = vector3D(0, 0, 0); locked = false; }
mass::mass(vector3D l) { this->m = DEFAULTM; this->v = vector3D(0, 0, 0); this->l = l; locked = false; }
double mass::distTo(mass & t)
{
  return sqrt(pow(l.x - t.l.x, 2) + pow(l.y - t.l.y, 2) + pow(l.z - t.l.z, 2));
}

// The spring structure for the physics model.
struct spring {
  vector<mass> * masses;
  int body1;
  int body2;
  double k;
  double damping;
  double restLength;
  spring();
  spring(int body1, int body2, vector<mass> * masses);
  void doForces();
};

spring::spring() : k(DEFAULTK), damping(.95) {}
spring::spring(int body1, int body2, vector<mass> * masses)
{
  this->body1 = body1;
  this->body2 = body2;
  this->k = DEFAULTK;
  this->damping = .95;
  this->masses = masses;
  this->restLength = (*masses)[body1].distTo((*masses)[body2]);
}
void spring::doForces()
{
  vector3D delta_pos = (*masses)[body1].l - (*masses)[body2].l;
  double r = delta_pos.magnitude();
  r = r - restLength;
  if (! (*masses)[body1].locked)
    (*masses)[body1].force = (*masses)[body1].force + ((-1*k*r*damping) * delta_pos.normalized());
  if (! (*masses)[body2].locked)
    (*masses)[body2].force = (*masses)[body2].force + ((k*r*damping) * delta_pos.normalized());
}

void findForces(vector<mass> & masses, vector<spring> & springs);
void doRungaKutta(vector<mass> & masses, vector<spring> & springs);

int main() {
  std::vector<mass> masses = std::vector<mass>();
  std::vector<spring> springs = std::vector<spring>();

  model particle;
  box3D * b = new box3D(1, 1, 1);
  b->setMaterial(colorVector(.2, .2, .8), colorVector(.8, .8, .8), 48);
  b->setFlat(true);
  particle.addItem(b);

  int width = 50, height = 50;

  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      mass m = mass(vector3D(j, 0, i));
      if ((i == height - 1) || (i == 0) || (j == 0) || (j == width - 1))
	m.locked = true;
      masses.push_back(m);
    }
  }

  for (unsigned int j = 0; j < masses.size() - width; j++) {
    if (j % width != 0) {
      spring s = spring(j - 1, j, &masses);
      springs.push_back(s);
    }
    spring s = spring(j, j + width, &masses);
    springs.push_back(s);
  }

  for (int t = 0; t < 100; t++) {
    doRungaKutta(masses, springs);
    curTime += timeStep;
  }
  
  //masses[0].v = vector3D(100, 100, 0);
  //for (int i = 0; i < width; i++) {
  masses[width / 2 * (height + 1)].l.x -= 5;
  masses[width / 2 * (height + 1)].l.y += 5;
  //}
  
  for (int i = 0; i < 70; i++) {
    model scene;
   
    std::vector<point3D*> * pointList = new std::vector<point3D*>();
    std::list<polygonRef3D> * polygonList = new std::list<polygonRef3D>();
    polygonMesh * mesh = new polygonMesh(pointList, polygonList);

    for (unsigned int j = 0; j < masses.size(); j++) {
      pointList->push_back(new point3D(masses[j].l.x, masses[j].l.y, masses[j].l.z));
    }

    for (unsigned int j = 0; j < pointList->size() - width; j++) {
      if ((j + 1) % width != 0)  {
	polygonRef3D pRef1f = polygonRef3D(3);
	pRef1f.addPoint((*pointList)[j]);
	pRef1f.addPoint((*pointList)[j + 1]);
	pRef1f.addPoint((*pointList)[j + width + 1]);
	pRef1f.setMaterial(colorVector(.9, .7, .7), colorVector(.8, .8, .8), 48);
	polygonList->push_back(pRef1f);
	
	polygonRef3D pRef1b = polygonRef3D(3);
	pRef1b.addPoint((*pointList)[j + 1]);	
	pRef1b.addPoint((*pointList)[j]);
	pRef1b.addPoint((*pointList)[j + width + 1]);
	pRef1b.setMaterial(colorVector(.9, .7, .7), colorVector(.8, .8, .8), 48);
	polygonList->push_back(pRef1b);

	polygonRef3D pRef2f = polygonRef3D(3);
	pRef2f.addPoint((*pointList)[j]);
	pRef2f.addPoint((*pointList)[j + width + 1]);
	pRef2f.addPoint((*pointList)[j + width]);
	pRef2f.setMaterial(colorVector(.9, .7, .7), colorVector(.8, .8, .8), 48);
	polygonList->push_back(pRef2f);

	polygonRef3D pRef2b = polygonRef3D(3);
	pRef2b.addPoint((*pointList)[j + width + 1]);	
	pRef2b.addPoint((*pointList)[j]);	
	pRef2b.addPoint((*pointList)[j + width]);
	pRef2b.setMaterial(colorVector(.9, .7, .7), colorVector(.8, .8, .8), 48);
	polygonList->push_back(pRef2b);
      }
    }

    for (int t = 0; t < 40; t++) {
      doRungaKutta(masses, springs);
      curTime += timeStep;
    }
    
    scene.addItem(mesh);
    
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(width / 2, -width, height / 2));
    scene.addItem(new pointLight(colorVector(1, 0, 0)));
    
    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(0, -width, height / 2), point3D(width / 3, width, 0), point3D(0, 0, 1));
    v.setProjectionDistance(2);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 10);
    v.setAmbientLight(colorVector(0/255.0, 0/255.0, 0/255.0));
    v.project(scene, im);
    
    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
    im.writeImage("../images/final3/" + osData.str() + ".ppm");
  }
}

void findForces(vector<mass> & masses, vector<spring> & springs)
{
  // Clear the old force vectors from previous time step
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].force = vector3D(0, 0, 0);
  }

  // Do springs
  for (unsigned int a = 0; a < springs.size(); a++) {
    springs[a].doForces();
  }
  
  if (doWorldGravity) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + ((gravityConstant * masses[a].m) * vector3D(0, 0, -1));
    }
  }
  
  if (doAirFriction) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + (-1*airFrictionCoeff) * masses[a].v;
    }
  }

  //for (unsigned int a = 0; a < masses.size(); a++) {
  //  cout << "force on mass[" << a << "] is " << masses[a].force << endl;
  //}
}

void doRungaKutta(vector<mass> & masses, vector<spring> & springs)
{
  // Integrate with a 4th order Runga-Kutta, we hope.
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    // First we backup the current information for all masses
    masses[a].RKvelocities[0] = masses[a].v;
    masses[a].RKlocations[0] = masses[a].l;
    masses[a].RKlocations[1] = (1/6.0) * masses[a].force; // Using RKlocations[1] to store force sum
    masses[a].RKvelocities[1] = (1/6.0) * masses[a].v; // Using RKvelocities[1] to store velocity sum
  }
  // Now we generate x1 and v1 just like a Euler Method step.
  for (unsigned int a = 0; a < masses.size(); a++) {
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].v + timeStep/2.0 * accel;
    masses[a].l = masses[a].l + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + (timeStep/2.0) * accel;
    masses[a].l = masses[a].RKlocations[0] + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + timeStep * accel;
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].v;
    masses[a].v = new_vel;
    
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/6.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/6.0) * masses[a].v;
    masses[a].v = masses[a].RKvelocities[0] + (timeStep/double(masses[a].m)) * masses[a].RKlocations[1];
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].RKvelocities[1];
  }
}


