#include "view.h"
#include <sstream>
#include <math.h>

using namespace std;

// Some global settings
int doWorldGravity = 1;
int doAirFriction = 1;
double airFrictionCoeff = .025;
double gravityConstant = 9.8;
double curTime = 0;
double timeStep = .1;

// The mass structure for the physics model.
struct mass {
  vector3D l;
  vector3D v;
  vector3D force;
  double m;
  bool locked;
  
  // Memory (storage registers for Runga-Kutta)
  vector3D RKlocations[2];
  vector3D RKvelocities[2];
  
  // Memory (storage registers for dynamic time-stepping)
  vector3D TSlocations[2];
  vector3D TSvelocities[2];

  mass();
  mass(vector3D l);
  double distTo(mass & t);
};

mass::mass() { m = 1; v = vector3D(0, 0, 0); l = vector3D(0, 0, 0); locked = false; }
mass::mass(vector3D l) { this->m = 1; this->v = vector3D(0, 0, 0); this->l = l; locked = false; }
double mass::distTo(mass & t)
{
  return sqrt(pow(l.x - t.l.x, 2) + pow(l.y - t.l.y, 2) + pow(l.z - t.l.z, 2));
}

// The spring structure for the physics model.
struct spring {
  mass * body1;
  mass * body2;
  double k;
  double damping;
  double restLength;
  spring();
  spring(mass * body1, mass * body2);
  void doForces();
};

spring::spring() : k(1), damping(.95) {}
spring::spring(mass * body1, mass * body2)
{
  this->body1 = body1;
  this->body2 = body2;
  this->k = 1;
  this->damping = .95;
  this->restLength = body1->distTo(*body2);
}
void spring::doForces()
{
  vector3D delta_pos = body1->l - body2->l;
  double r = delta_pos.magnitude();
  r = r - restLength;
  if (! body1->locked)
    body1->force = body1->force + ((-1*k*r*damping) * delta_pos.normalized()); // Hook's Law
  if (! body2->locked)
    body2->force = body2->force + ((k*r*damping) * delta_pos.normalized()); // Hook's Law
}

void findForces(vector<mass> & masses, vector<spring> & springs);
void doRungaKutta(vector<mass> & masses, vector<spring> & springs);

int main() {
  std::vector<mass> masses = std::vector<mass>();
  std::vector<spring> springs = std::vector<spring>();

  for (int i = 0; i < 100; i++) {
    //int x = (int)(drand48() * 1);
    //int y = (int)(drand48() * 1);
    //int z = (int)(drand48() * 1);
    mass m = mass(vector3D(0, 0, 5));
    m.v = vector3D(drand48() * 10 - 5, drand48() * 10 - 5, drand48() * 10);
    masses.push_back(m);
  }

  model particle;
  box3D * b = new box3D(1, 1, 1);
  b->setMaterial(colorVector(.5, 0, 0), colorVector(.8, .8, .8), 48);
  b->setFlat(true);
  particle.addItem(b);

  for (int i = 0; i < 50; i++) {
    for (int j = 0; j < 10; j++) {
      mass m = mass(vector3D(0, 0, 5));
      m.v = vector3D(drand48() * 10 - 5, drand48() * 10 - 5, drand48() * 10);
      masses.push_back(m);
    }

    doRungaKutta(masses, springs);
    curTime += timeStep;
    
    // Setup the polygonMesh
    std::vector<point3D*> * pointList = new std::vector<point3D*>();
    std::list<polygonRef3D> * polygonList = new std::list<polygonRef3D>();
    polygonMesh * mesh = new polygonMesh(pointList, polygonList);
    
    model scene;

    for (unsigned int j = 0; j < masses.size(); j++) {
      scene.addItem(new modelMatrixReset());
      scene.addItem(new modelTranslate3D(masses[j].l.x, masses[j].l.y, masses[j].l.z));
      scene.addItem(new modelRotate3Dz((i/25.0)*2*3.1415));
      scene.addItem(&particle);
    }

    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(0, -5, 0));
    scene.addItem(new pointLight(colorVector(1, 0, 0)));
    scene.addItem(new sunLight(colorVector(1, 1, 1), vector3D(0,0,1)));
    
    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(0, -25, 0), point3D(0, 1, 0), point3D(0, 0, 1));
    v.setProjectionDistance(20);
    v.setCameraSize(25, 25);
    v.setClipPlanes(0, 10000);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
    im.writeImage("../images/final1/" + osData.str() + ".ppm");
  }
}

void findForces(vector<mass> & masses, vector<spring> & springs)
{
  // Clear the old force vectors from previous time step
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].force = vector3D(0, 0, 0);
  }

  // Do springs
  for (unsigned int a = 0; a < springs.size(); a++) {
    springs[a].doForces();
  }
  
  if (doWorldGravity) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + ((gravityConstant * masses[a].m) * vector3D(0, 0, -1));
    }
  }
  
  if (doAirFriction) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + (-1*airFrictionCoeff) * masses[a].v;
    }
  }
}

void doRungaKutta(vector<mass> & masses, vector<spring> & springs)
{
  // Integrate with a 4th order Runga-Kutta, we hope.
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    // First we backup the current information for all masses
    masses[a].RKvelocities[0] = masses[a].v;
    masses[a].RKlocations[0] = masses[a].l;
    masses[a].RKlocations[1] = (1/6.0) * masses[a].force; // Using RKlocations[1] to store force sum
    masses[a].RKvelocities[1] = (1/6.0) * masses[a].v; // Using RKvelocities[1] to store velocity sum
  }
  // Now we generate x1 and v1 just like a Euler Method step.
  for (unsigned int a = 0; a < masses.size(); a++) {
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].v + timeStep/2.0 * accel;
    masses[a].l = masses[a].l + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + (timeStep/2.0) * accel;
    masses[a].l = masses[a].RKlocations[0] + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + timeStep * accel;
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].v;
    masses[a].v = new_vel;
    
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/6.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/6.0) * masses[a].v;
    masses[a].v = masses[a].RKvelocities[0] + (timeStep/double(masses[a].m)) * masses[a].RKlocations[1];
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].RKvelocities[1];
  }
}


