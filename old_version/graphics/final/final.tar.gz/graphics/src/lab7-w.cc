#include "view.h"
#include <sstream>

int main() {
  //  Required Image 1
  polygonRef3D p1 = polygonRef3D(3);
  p1.addPoint(new point3D(25, 75, 10, Pixel()));
  p1.addPoint(new point3D(25, 25, 15, Pixel()));
  p1.addPoint(new point3D(75, 50, 30, Pixel()));
  polygonRef3D p2 = polygonRef3D(3);
  p2.addPoint(new point3D(75, 75, 10, Pixel()));
  p2.addPoint(new point3D(75, 25, 10, Pixel()));
  p2.addPoint(new point3D(25, 50, 20, Pixel()));

  image im = image(100, 100, Pixel(255, 255, 255));
  im.makeZBuffer(0);

  im.setPenColor(Pixel(255, 0, 0));
  p1.drawZBuffer(im);
  im.setPenColor(Pixel(0, 0, 255));
  p2.drawZBuffer(im);

  im.writeImage("../images/lab7.ppm");
  
 
 
  /*
  model pyramid;
  {
  polygon3D *p = new polygon3D(4);
  p->addPoint(point3D(-1, -1, 0, Pixel(255,0,0)));
  p->addPoint(point3D(1, -1, 0, Pixel(255,0,0)));
  p->addPoint(point3D(1, 1, 0, Pixel(255,0,0)));
  p->addPoint(point3D(-1, 1, 0, Pixel(255,0,0)));
  pyramid.addItem(p);
  }{
  polygon3D *p = new polygon3D(3);
  p->addPoint(point3D(-1, -1, 0, Pixel(0,255,0)));
  p->addPoint(point3D(0, 0, 1, Pixel(0,255,0)));
  p->addPoint(point3D(1, -1, 0, Pixel(0,255,0)));
  pyramid.addItem(p);
  }{
  polygon3D *p = new polygon3D(3);
  p->addPoint(point3D(-1, -1, 0, Pixel(0,0,255)));
  p->addPoint(point3D(0, 0, 1, Pixel(0,0,255)));
  p->addPoint(point3D(-1, 1, 0, Pixel(0,0,255)));
  pyramid.addItem(p);
  }{  
  polygon3D *p = new polygon3D(3);
  p->addPoint(point3D(1, 1, 0, Pixel(255,255,0)));
  p->addPoint(point3D(0, 0, 1, Pixel(255,255,0)));
  p->addPoint(point3D(1, -1, 0, Pixel(255,255,0)));
  pyramid.addItem(p);
  }{  
  polygon3D *p = new polygon3D(3);
  p->addPoint(point3D(1, 1, 0, Pixel(0,255,255)));
  p->addPoint(point3D(0, 0, 1, Pixel(0,255,255)));
  p->addPoint(point3D(-1, 1, 0, Pixel(0,255,255)));
  pyramid.addItem(p);
  }
  //scene.addItem(new modelRotate3Dy(1.6));
  //scene.addItem(new modelScale3D(50));
  */
  
  /* Using pyramid3D
  model pyramid;

  polygon3D p = polygon3D(4);
  p.addPoint(point3D(-1, -1, 0, Pixel(255,0,0)));
  p.addPoint(point3D(1, -1, 0, Pixel(255, 0, 0)));
  p.addPoint(point3D(1, 1, 0, Pixel(0,0,255)));
  p.addPoint(point3D(-1, 1, 0, Pixel(0, 0, 255)));

  pyramid3D *pyr = new pyramid3D(point3D(0, 0, 1, Pixel(0, 0, 0)), p);
  pyramid.addItem(pyr);

  for (int i = 0; i < 80; i++) {
    model scene;
    scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, -2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, 2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);
    
    view3D v;
    image im = image(500, 500, Pixel(255, 255, 255));
    
    v.setCamera(point3D(5, 5, 1), point3D(-1, -1, -.2), point3D(-1, -1, .2));
    v.setProjectionDistance(2);
    v.setCameraSize(2, 2);
    v.setClipPlanes(0, 10);
    v.project(scene, im);
    
    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
 
    im.writeImage("../images/lab7-ani2/" + osData.str() + ".ppm");
  }
  */
}
