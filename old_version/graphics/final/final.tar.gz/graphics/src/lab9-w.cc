#include "view.h"
#include <sstream>
#include <math.h>

using namespace std;

point3D* torus(double u, double v)
{
  double x, y, z;
  double c = 4;
  double a = 2;

  u *= 2 * 3.1415926;
  v *= 2 * 3.1415926;

  x = (c + a * cos(v)) * cos(u);
  y = (c + a * cos(v)) * sin(u);
  z = a * tan(v);

  return (new point3D(x, y, z));
}

double spow(double x, double y)
{
  return x > 0 ? pow(x, y) : -pow(-x, y);
}

double e1;
double e2;

point3D* superellipsoid(double u, double v)
{
  double x, y, z;
  double a = 2;
  double b = 2;
  double c = 2;

  u = (.5 - u) * 3.1415926;
  v = -(.5 - v) * 2 * 3.1415926;

  x = a * spow(cos(u), e1) * spow(cos(v), e2);
  y = b * spow(cos(u), e1) * spow(sin(v), e2);
  z = c * spow(sin(u), e1);

  return (new point3D(x, y, z));
}

int main() {
  int i = 0;
  
  e2 = .2;
  e1 = .2;

  for (e2 = .2; e2 < .8; e2 += .2) {
    model scene;

    paramObject3D *pO3D = new paramObject3D(superellipsoid, 1.0 / 25, 1.0 / 25);
    pO3D->setMaterial(colorVector(.3, .8, .3), colorVector(.8, .8, .8), 32);
    pO3D->setFlat(true);
    scene.addItem(new modelRotate3Dz(i / 55.0 * 2 * 3.1415926));
    scene.addItem(pO3D);
    
    scene.addItem(new modelTranslate3D(0, 6, 3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    scene.addItem(new modelMatrixReset());    
    scene.addItem(new modelTranslate3D(6, 0, -3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(20, 10, 0), point3D(-20, -10, 0), point3D(0, 0, 1));
    v.setProjectionDistance(15);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
  

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i++;
    
    im.writeImage("../images/superellipse-rotate/" + osData.str() + ".ppm");
  }

  for (e1 = .2; e1 < 4; e1 += .2) {
    model scene;

    paramObject3D *pO3D = new paramObject3D(superellipsoid, 1.0 / 25, 1.0 / 25);
    pO3D->setMaterial(colorVector(.3, .8, .3), colorVector(.8, .8, .8), 32);
    pO3D->setFlat(true);
    scene.addItem(new modelRotate3Dz(i / 55.0 * 2 * 3.1415926));
    scene.addItem(pO3D);
    
    scene.addItem(new modelTranslate3D(0, 6, 3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    scene.addItem(new modelMatrixReset());    
    scene.addItem(new modelTranslate3D(6, 0, -3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(20, 10, 0), point3D(-20, -10, 0), point3D(0, 0, 1));
    v.setProjectionDistance(15);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
  

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i++;
    
    im.writeImage("../images/superellipse-rotate/" + osData.str() + ".ppm");
  }

 for (e1 = 3.8; e1 > 2; e1 -= .2) {
    model scene;

    paramObject3D *pO3D = new paramObject3D(superellipsoid, 1.0 / 25, 1.0 / 25);
    pO3D->setMaterial(colorVector(.3, .8, .3), colorVector(.8, .8, .8), 32);
    pO3D->setFlat(true);
    scene.addItem(new modelRotate3Dz(i / 55.0 * 2 * 3.1415926));
    scene.addItem(pO3D);
    
    scene.addItem(new modelTranslate3D(0, 6, 3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    scene.addItem(new modelMatrixReset());    
    scene.addItem(new modelTranslate3D(6, 0, -3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(20, 10, 0), point3D(-20, -10, 0), point3D(0, 0, 1));
    v.setProjectionDistance(15);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
  

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i++;
    
    im.writeImage("../images/superellipse-rotate/" + osData.str() + ".ppm");
 }

  for (e2 = 1; e2 < 4; e2 += .2) {
    model scene;

    paramObject3D *pO3D = new paramObject3D(superellipsoid, 1.0 / 25, 1.0 / 25);
    pO3D->setMaterial(colorVector(.3, .8, .3), colorVector(.8, .8, .8), 32);
    pO3D->setFlat(true);
    scene.addItem(new modelRotate3Dz(i / 55.0 * 2 * 3.1415926));
    scene.addItem(pO3D);
    
    scene.addItem(new modelTranslate3D(0, 6, 3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    scene.addItem(new modelMatrixReset());    
    scene.addItem(new modelTranslate3D(6, 0, -3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(20, 10, 0), point3D(-20, -10, 0), point3D(0, 0, 1));
    v.setProjectionDistance(15);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
  

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i++;
    
    im.writeImage("../images/superellipse-rotate/" + osData.str() + ".ppm");
  }

  for (e1 = 2; e1 > .1; e1 -= .2) {
    cout << "e1: " << e1 << "    e2: " << e2 << endl;
    model scene;
    
    paramObject3D *pO3D = new paramObject3D(superellipsoid, 1.0 / 25, 1.0 / 25);
    pO3D->setMaterial(colorVector(.3, .8, .3), colorVector(.8, .8, .8), 32);
    pO3D->setFlat(true);
    scene.addItem(new modelRotate3Dz(i / 55.0 * 2 * 3.1415926));
    scene.addItem(pO3D);
    
    scene.addItem(new modelTranslate3D(0, 6, 3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(6, 0, -3));
    scene.addItem(new pointLight(colorVector(1, 1, 1)));

    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(20, 10, 0), point3D(-20, -10, 0), point3D(0, 0, 1));
    v.setProjectionDistance(15);
    v.setCameraSize(3, 3);
    v.setClipPlanes(0, 3);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
  

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i++;
    
    im.writeImage("../images/superellipse-rotate/" + osData.str() + ".ppm");
    e2 -= .4;
  }
}



    /*
  scene.addItem(new modelMatrixReset());    
    scene.addItem(new modelScale3D(10, 10, 1));    
    polygon3D *floor1 = new polygon3D(3);
    floor1->addPoint(point3D(-1, -1, 0));
    floor1->addPoint(point3D(1, 1, 0));   
    floor1->addPoint(point3D(-1, 1, 0));
    floor1->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 128);
    floor1->setFlat(true);
    floor1->shadowed = true;
    //scene.addItem(floor1);

    polygon3D *floor2 = new polygon3D(3);
    floor2->addPoint(point3D(-1, -1, 0));
    floor2->addPoint(point3D(1, -1, 0));
    floor2->addPoint(point3D(1, 1, 0));
    floor2->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 128);
    floor2->setFlat(true);
    floor2->shadowed = true;
    //scene.addItem(floor2);
    */
