#include "view.h"
#include <sstream>

int main() {
  /*
  model scene;
  
  polygon3D *p = new polygon3D(4);
  p->addPoint(point3D(0, 0, 2));
  p->addPoint(point3D(0, 2, 0));
  p->addPoint(point3D(0, -2, 0));
  p->setMaterial(colorVector(.2, .2, .7), colorVector(.8, .8, .8), 16);
  p->setFlat(true);
  scene.addItem(p);
  
  
  p = new polygon3D(4);
  p->addPoint(point3D(2, 1.75, .25));
  p->addPoint(point3D(2, 2, 0));
  p->addPoint(point3D(2, 1.5, 0));   
  p->setMaterial(colorVector(.2, .2, .7), colorVector(.8, .8, .8), 16);
  p->setFlat(true);
  scene.addItem(p);
  

  scene.addItem(new modelMatrixReset());
  scene.addItem(new modelTranslate3D(-2, 2, 0));
  scene.addItem(new pointLight(colorVector(1, 1, 1)));
  
  view3D v;
  image im = image(500, 500, Pixel(255, 255, 255));
  
  v.setCamera(point3D(-2, 0, 0), point3D(1, 0, 0), point3D(0, 0, 1));
  v.setProjectionDistance(2);
  v.setCameraSize(4, 4);
  v.setClipPlanes(0, 3);
  v.setAmbientLight(colorVector(100/255.0, 100/255.0, 100/255.0));
  v.project(scene, im);

  im.writeImage("../images/lab8.ppm");
  */
  /*
  for (int i = 0; i < 40; i++) {
  model scene;
  model pyramid;

  polygon3D base = polygon3D(4);
  base.addPoint(point3D(-1, -1, 0, Pixel(255,0,0)));
  base.addPoint(point3D(1, -1, 0, Pixel(255, 0, 0)));
  base.addPoint(point3D(1, 1, 0, Pixel(0,0,255)));
  base.addPoint(point3D(-1, 1, 0, Pixel(0, 0, 255)));

  pyramid3D *pyr = new pyramid3D(point3D(0, 0, 1), base);
  pyr->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 32);
  pyr->setFlat(true);
  pyramid.addItem(pyr);
  scene.addItem(new modelRotate3Dz(-3.1415926 / 20 * i));
  //scene.addItem(new modelRotate3Dx(-3.1415926 / 2));
  scene.addItem(new modelTranslate3D(2, 0, 0));
  scene.addItem(&pyramid);
  
  scene.addItem(new modelMatrixReset());
  scene.addItem(new modelTranslate3D(0, 0, 2));
  scene.addItem(new pointLight(colorVector(0, 0, 1)));
  
  view3D v;
  image im = image(500, 500, Pixel(255, 255, 255));
  
  v.setCamera(point3D(0, 0, 0), point3D(2, 0, 0), point3D(0, 0, 1));
  v.setProjectionDistance(2);
  v.setCameraSize(2, 2);
  v.setClipPlanes(0, 3);
  v.setAmbientLight(colorVector(10/255.0, 10/255.0, 10/255.0));
  v.project(scene, im);

  ostringstream osData;
  osData.width(2);
  osData.fill('0');
  osData.setf(ios::right, ios::adjustfield);
  osData << i;
 
  im.writeImage("../images/lab8-ani2/" + osData.str() + ".ppm");

  //im.writeImage("../images/lab8.ppm");
  }
  */
  
  // Using pyramid3D
  model pyramid;

  polygon3D base = polygon3D(4);
  base.addPoint(point3D(-1, -1, 0, Pixel(255,0,0)));
  base.addPoint(point3D(1, -1, 0, Pixel(255, 0, 0)));
  base.addPoint(point3D(1, 1, 0, Pixel(0,0,255)));
  base.addPoint(point3D(-1, 1, 0, Pixel(0, 0, 255)));

  pyramid3D *pyr = new pyramid3D(point3D(0, 0, 1), base);
  pyr->setMaterial(colorVector(.3, .3, .8), colorVector(.8, .8, .8), 32);
  pyr->setFlat(true);
  pyramid.addItem(pyr);


  for (int i = 0; i < 40; i++) {
    model scene;
    /*
    polygon3D *p = new polygon3D(4);
    p->addPoint(point3D(-5, -5, 0));
    p->addPoint(point3D(5, -5, 0));
    p->addPoint(point3D(5, 5, 0));
    p->addPoint(point3D(-5, 5, 0));
    p->setMaterial(colorVector(.8, .8, .8), colorVector(.8, .8, .8), 32);
    p->setFlat(true);
    scene.addItem(p);
    */

    //scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, -2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);
    scene.addItem(new modelMatrixReset());
    //scene.addItem(new modelRotate3Dz(.5 * 0.157079633 * i));
    scene.addItem(new modelTranslate3D(0, 2, 0));
    scene.addItem(new modelRotate3Dz(0.157079633 * i));
    scene.addItem(&pyramid);

    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(5, 5, 2));
    scene.addItem(new sunLight(colorVector(1, 1, 1), vector3D(0, 0, 1)));

    view3D v;
    image im = image(300, 300, Pixel(255, 255, 255));
    
    v.setCamera(point3D(5, 0, 1), point3D(-1, 0, -.2), point3D(0, 0, .2));
    v.setProjectionDistance(2);
    v.setCameraSize(2, 2);
    v.setClipPlanes(0, 10);
    v.setAmbientLight(colorVector(10/255.0, 10/255.0, 10/255.0));
    v.project(scene, im);
    
    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;

    im.writeImage("../images/lab8-ani1/" + osData.str() + ".ppm");
  }
  

  /*
  bool intersect(point3D start, point3D light, list<polygonRef3D> & polygonList, polygonRef3D *pRef);

  list<polygonRef3D> pList;
  
  polygonRef3D pRef = polygonRef3D(3);

  point3D *p = new point3D(0, 0, 4);
  p->archive();
  pRef.addPoint(p);

  p = new point3D(-2, 1, 1);
  p->archive();
  pRef.addPoint(p);

  p = new point3D(0, 2, 1);
  p->archive();
  pRef.addPoint(p);
  
  pList.push_back(pRef);

  polygonRef3D *pRefJunk = new polygonRef3D(2);

  intersect(point3D(-1, 1, 4), point3D(-1, 1, 1), pList, pRefJunk);
  */
}

