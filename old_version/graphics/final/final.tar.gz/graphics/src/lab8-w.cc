#include "view.h"
#include "model.h"
#include <math.h>
#include <list>
#include <sstream>

int main () {
  image im = image(100, 100, Pixel(255, 255, 255));

  list<modelLight> lights;
 
  pointLight light = pointLight(colorVector(1, 1, 1));
  light.loc = point3D(-5, 0, 0);
  lights.push_back(light);

  light = pointLight(colorVector(0, 0, 1));
  light.loc = point3D(10, 3, 0);
  // lights.push_back(light);

  for (double kS = 0; kS <= 1; kS += .2) {
    for (int nS = 1; nS <= 6; nS++) {

      for (int row = 0; row < im.getRows(); row++) {
	for (int col = 0; col < im.getCols(); col++) {
	  vector3D p = vector3D(double(col - im.getCols() / 2) / (im.getCols()/2), double(row - im.getCols()/2) / (im.getCols()/2), -sqrt(1 - (double(col - im.getCols() / 2) / (im.getCols()/2))*(double(col - im.getCols() / 2) / (im.getCols()/2))) + 10);
	  
	  vector3D v = (vector3D(0, 0, 0) - p).normalized();
	  vector3D N = vector3D(p.x, 0, p.z - 10).normalized();
	  //vector3D L = (vector3D(-5, 0, 0) - p).normalized();
	  
	  //colorVector kS = colorVector(1, 1, 1);
	  colorVector kD = colorVector(0.3, 0.8, 0.3);
	  //colorVector l = colorVector(1, 1, 1);
	  colorVector Ia = colorVector(10.0 / 255, 10.0 / 255, 10.0 / 255);
	  
	  im.drawPixel(col, row, shade(lights, p, N, v, kD, colorVector(kS, kS, kS), pow(2, nS), Ia));
	}
      }

      ostringstream osData1;
      osData1.width(1);
      osData1.fill('0');
      osData1.setf(ios::right, ios::adjustfield);
      osData1 << kS * 5 + 1;

      ostringstream osData2;
      osData2.width(1);
      osData2.fill('0');
      osData2.setf(ios::right, ios::adjustfield);
      osData2 << nS;

      im.writeImage("../images/lab8-q1/" + osData1.str() + osData2.str() + ".ppm");
    }
  }
}
