#include "view.h"
#include <sstream>
#include <math.h>

using namespace std;

// Some global settings
int doWorldGravity = 1;
int doAirFriction = 1;
double airFrictionCoeff = .05; // .025;
double gravityConstant = 9.8;
double curTime = 0;
double timeStep = .01;
#define DEFAULTK 10

point3D* torus(double u, double v)
{
  double x, y, z;
  double c = 4;
  double a = 2;

  u *= 2 * 3.1415926;
  v *= 2 * 3.1415926;

  x = (c + a * cos(v)) * cos(u);
  y = (c + a * cos(v)) * sin(u);
  z = a * sin(v);

  return (new point3D(x, y, z));
}

// The mass structure for the physics model.
struct mass {
  vector3D l;
  vector3D v;
  vector3D force;
  point3D * target;
  double m;
  bool locked;
  
  // Memory (storage registers for Runga-Kutta)
  vector3D RKlocations[2];
  vector3D RKvelocities[2];

  mass();
  mass(vector3D l);
  double distTo(mass & t);
};

mass::mass() { m = 1; v = vector3D(0, 0, 0); l = vector3D(0, 0, 0); locked = false; }
mass::mass(vector3D l) { this->m = 1; this->v = vector3D(0, 0, 0); this->l = l; locked = false; }
double mass::distTo(mass & t)
{
  return sqrt(pow(l.x - t.l.x, 2) + pow(l.y - t.l.y, 2) + pow(l.z - t.l.z, 2));
}

// The spring structure for the physics model.
struct spring {
  mass * body1;
  mass * body2;
  double k;
  double damping;
  double restLength;
  spring();
  spring(mass * body1, mass * body2);
  void doForces();
};

spring::spring() : k(DEFAULTK), damping(.95) {}
spring::spring(mass * body1, mass * body2)
{
  this->body1 = body1;
  this->body2 = body2;
  this->k = DEFAULTK;
  this->damping = .95;
  this->restLength = body1->distTo(*body2);
}
void spring::doForces()
{
  vector3D delta_pos = body1->l - body2->l;
  double r = delta_pos.magnitude();
  r = r - restLength;
  if (! body1->locked)
    body1->force = body1->force + ((-1*k*r*damping) * delta_pos.normalized()); // Hook's Law
  if (! body2->locked)
    body2->force = body2->force + ((k*r*damping) * delta_pos.normalized()); // Hook's Law
}

void findForces(vector<mass> & masses, vector<spring> & springs);
void doRungaKutta(vector<mass> & masses, vector<spring> & springs);

int main() {
  std::vector<mass> masses = std::vector<mass>();
  std::vector<spring> springs = std::vector<spring>();

  paramObject3D *p03D = new paramObject3D(torus, 1.0 / 25, 1.0 / 25);
  p03D->setMaterial(colorVector(.7, .7, .7), colorVector(.8, .8, .8), 48);
  p03D->setFlat(true);

  matrix m = matrix::I;
  vector<point3D*> torusPts;
  list<polygonRef3D> torusPolys;
  matrix mx = matrix::I;
  p03D->render(m, torusPts, torusPolys);

  for (vector<point3D*>::iterator iter = torusPts.begin(); iter != torusPts.end(); iter++) {
    mass aMass = mass(vector3D((**iter).x(), (**iter).y(), (**iter).z()));
    aMass.v = vector3D(0, 0, 0);
    aMass.target = *iter;
    masses.push_back(aMass);
  }

  //masses[0].locked = true;

  for (unsigned int i = 0; i < masses.size(); i++)
    for (unsigned int j = i + 1; j < masses.size(); j++) {
      spring s = spring(&masses[i], &masses[j]);
      s.k = 400 * (1.0 / (pow(s.restLength, 4)));
      springs.push_back(s);
    }
  
  for (int i = 0; i < 50; i++) {
    for (int t = 0; t < 15; t++) {
      doRungaKutta(masses, springs);
      curTime += timeStep;

      for (unsigned int i = 0; i < masses.size(); i++)
	if (masses[i].l.z < -10) {
	  masses[i].v.z *= -.5;
	  masses[i].l.z = -10;
	}
    }
    
    //std::vector<point3D*> * pointList = new std::vector<point3D*>();
    //std::list<polygonRef3D> * polygonList = new std::list<polygonRef3D>();

    for (unsigned int k = 0; k < masses.size(); k++) {
      masses[k].target->data[0] = masses[k].l.x;
      masses[k].target->data[1] = masses[k].l.y;
      masses[k].target->data[2] = masses[k].l.z;
      masses[k].target->data[3] = 1;
    }
    
    polygonMesh * mesh = new polygonMesh(&torusPts, &torusPolys);
    
    model scene;
    scene.addItem(mesh);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(0, -15, 0));
    scene.addItem(new pointLight(colorVector(1, 0, 0)));
    scene.addItem(new sunLight(colorVector(1, 1, 1), vector3D(0, 0, 1)));
    
    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(0, -15, 0), point3D(0, 1, 0), point3D(0, 0, 1));
    v.setProjectionDistance(2);
    v.setCameraSize(5, 5);
    v.setClipPlanes(0, 1000);
    v.setAmbientLight(colorVector(75/255.0, 75/255.0, 75/255.0));
    v.project(scene, im);
    
    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
 
    im.writeImage("../images/final2-2/" + osData.str() + ".ppm");
  }
}

void findForces(vector<mass> & masses, vector<spring> & springs)
{
  // Clear the old force vectors from previous time step
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].force = vector3D(0, 0, 0);
  }

  // Do springs
  for (unsigned int a = 0; a < springs.size(); a++) {
    springs[a].doForces();
  }
  
  if (doWorldGravity) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + ((gravityConstant * masses[a].m) * vector3D(0, 0, -1));
    }
  }
  
  if (doAirFriction) {
    for (unsigned int a = 0; a < masses.size(); a++) {
      if (! masses[a].locked)
	masses[a].force = masses[a].force + (-1*airFrictionCoeff) * masses[a].v;
    }
  }

  //for (unsigned int a = 0; a < masses.size(); a++) {
  //  cout << "force on mass[" << a << "] is " << masses[a].force << endl;
  //}
}

void doRungaKutta(vector<mass> & masses, vector<spring> & springs)
{
  // Integrate with a 4th order Runga-Kutta, we hope.
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    // First we backup the current information for all masses
    masses[a].RKvelocities[0] = masses[a].v;
    masses[a].RKlocations[0] = masses[a].l;
    masses[a].RKlocations[1] = (1/6.0) * masses[a].force; // Using RKlocations[1] to store force sum
    masses[a].RKvelocities[1] = (1/6.0) * masses[a].v; // Using RKvelocities[1] to store velocity sum
  }
  // Now we generate x1 and v1 just like a Euler Method step.
  for (unsigned int a = 0; a < masses.size(); a++) {
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].v + timeStep/2.0 * accel;
    masses[a].l = masses[a].l + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + (timeStep/2.0) * accel;
    masses[a].l = masses[a].RKlocations[0] + (timeStep/2.0) * masses[a].v;
    masses[a].v = new_vel;
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/3.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/3.0) * masses[a].v;
    vector3D accel = (1/double(masses[a].m)) * masses[a].force;
    vector3D new_vel = masses[a].RKvelocities[0] + timeStep * accel;
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].v;
    masses[a].v = new_vel;
    
  }
  findForces(masses, springs);
  for (unsigned int a = 0; a < masses.size(); a++) {
    masses[a].RKlocations[1] = masses[a].RKlocations[1] + (1/6.0) * masses[a].force;
    masses[a].RKvelocities[1] = masses[a].RKvelocities[1] + (1/6.0) * masses[a].v;
    masses[a].v = masses[a].RKvelocities[0] + (timeStep/double(masses[a].m)) * masses[a].RKlocations[1];
    masses[a].l = masses[a].RKlocations[0] + timeStep * masses[a].RKvelocities[1];
  }
}


