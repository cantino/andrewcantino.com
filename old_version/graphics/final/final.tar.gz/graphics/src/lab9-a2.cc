#include "modelio.h"
#include <sstream>

using namespace std;

int main() {
  for (int i = 0; i < 25; i++) {
    // Note, loaded models may get mutated when rendered!
    model * test = loadASEModel("../models/sphere.ase");
    model scene;
    //scene.addItem(new modelRotate3Dz(((i/20.0)*2*3.1415)));
    scene.addItem(test);
    scene.addItem(new modelMatrixReset());
    polygon3D *floor = new polygon3D(4);
    floor->addPoint(point3D(-150, -150, -100));
    floor->addPoint(point3D(150, -150,  -100));
    floor->addPoint(point3D(150, 150,  -100));
    floor->addPoint(point3D(-150, 150,  -100));
    floor->setMaterial(colorVector(.7, .5, .5), colorVector(.8, .8, .8), 32);
    floor->setFlat(true);
    //scene.addItem(new modelScale3D(100, 100, 0));
    scene.addItem(floor);
    scene.addItem(new modelMatrixReset());
    scene.addItem(new modelTranslate3D(25, 25, 70));
    scene.addItem(new modelRotate3Dz((i/25.0)*2*3.1415926));
    scene.addItem(new pointLight(colorVector(1, 0, 0)));
    //scene.addItem(new sunLight(colorVector(1, 1, 1), vector3D(0,0,1)));
    cout << "Added the model." << endl;
    image im = image(500, 500, Pixel(255, 255, 255));
    view3D v;
    v.setCamera(point3D(100, 100, 100), point3D(-1, -1, -1), point3D(0, 0, 1));
    v.setProjectionDistance(4);
    v.setCameraSize(4, 4);
    v.setClipPlanes(0, 1000000);
    v.setAmbientLight(colorVector(100/255.0, 100/255.0, 100/255.0));
    v.project(scene, im);

    ostringstream osData;
    osData.width(2);
    osData.fill('0');
    osData.setf(ios::right, ios::adjustfield);
    osData << i;
    
    im.writeImage("../images/lab9-ani3/" + osData.str() + ".ppm");
  }
}
