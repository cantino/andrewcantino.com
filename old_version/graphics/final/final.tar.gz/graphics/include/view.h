#ifndef VIEW_H
#define VIEW_H

#include "model.h"

/**
 * A view class
 */
class view3D {
 private:
  point3D vrp, vpn, vup;
  double d, du, dv, F, B;
  int screenX, screenY;
  colorVector Ia;

 public:
  /**
   * Primative Constructor
   * Constructs an empty view object.  The object is then setup using the various mutator functions.
   */
  view3D();
  /**
   * Setup the camera in the scene
   * @param vrp The location of the viewing plane
   * @param vpn The direction the camera is pointing
   * @param vup The direction straight above the camera
   */
  void setCamera(point3D vrp, point3D vpn, point3D vup);
  /**
   * Set the focal length
   * @param d The location from the projection plane to the center of projection (the focal length)
   */
  void setProjectionDistance(double d);
  /**
   * Setup the size of the viewing plane
   * @param du The horizontal width of the viewing plane
   * @param dv The vertical width of the viewing plane
   */
  void setCameraSize(double du, double dv);
  /**
   * Set the front and back clip planes
   * @param F The location of the front clip plane relative to the vrp
   * @param B The location of the back clip plane relative to the vrp
   */
  void setClipPlanes(double F, double B);
  /**
   * Setup ambient lighting
   * @param Ia The intensity of the abient light
   */
  void setAmbientLight(colorVector Ia);
  /**
   * Do a perspective projection
   * @param m The model to render
   * @param i The image to project onto
   */
  void project(model &m, image &i);
  /**
   * Do a parallel projection
   * @param m The model to render
   * @param i The image to project onto
   */
  void parallelProject(model &m, image &i);
};

bool intersect(point3D start, point3D vector, list<polygonRef3D> & polygonList, polygonRef3D *pRef);

colorVector lambertian(vector3D L, vector3D N, colorVector l, colorVector C);
colorVector phong(vector3D L, vector3D N, vector3D v, colorVector l, colorVector C, double n);
Pixel shade(vector<modelLight> lights, list<polygonRef3D> &polygonList, point3D P, vector3D N, vector3D v, colorVector kD, colorVector kS, double n, colorVector Ia, polygonRef3D *pRef, bool shadow);

class polygonRef3D {
 private:
  struct edgeRecord3D {
    int yStart, yEnd;
    double xIntersect, dxPerScan, zIntersect, dzPerScan;
    
    double worldXIntersect, worldYIntersect, worldZIntersect;
    double dWorldXPerScan, dWorldYPerScan, dWorldZPerScan;
    double normalXIntersect, normalYIntersect, normalZIntersect;
    double dNormalXPerScan, dNormalYPerScan, dNormalZPerScan;

    friend bool edgeRecord3D_lt (const edgeRecord3D *x, const edgeRecord3D *y);
    friend edgeRecord3D createEdgeRecord(point3D p1, point3D p2, vector3D normal, bool flat);
  };

 public:
  point3D **points;
  vector3D normal;
  int pointCount, n;
  bool filled, flat;
  colorVector kD, kS;
  double nS;
  bool shadowed;

  polygonRef3D();
  polygonRef3D(int n);
  polygonRef3D(const polygonRef3D &p);
  virtual ~polygonRef3D();
  polygonRef3D& operator= (const polygonRef3D &rhs);
  void findNormal();
  vector3D getNormal();
  void setFilled(bool m);
  void setMaterial(colorVector kD, colorVector kS, double nS);
  void setFlat(bool m);
  Pixel getColor();

  void addPoint(point3D *p);

  void drawZBuffer(image &im, vector<modelLight> &lightList, list<polygonRef3D> &polygonList, point3D vrp, colorVector Ia);

  friend std::ostream& operator<< (std::ostream &out, const polygonRef3D &p);
};

#endif
