#ifndef FRACTAL_H
#define FRACTAL_H

#include "image.h"

/**
 * Julia Set Renderer
 * This class takes a range over which to generate an image, and then generates a julia set to fill that region.
 */
class julia {
 public:
  int *data;
  int rows, cols;

  /**
   * Primative Constructor
   */
  julia();
  /**
   * Constructor
   * @param x0 The lower left x value of the range to show
   * @param y0 The lower left y value of the range to show
   * @param x1 The upper right x value of the range to show
   * @param y1 The upper right x value of the range to show
   * @param sampleWidth The width of the resulting image, in pixels
   */
  julia(double x0, double y0, double x1, double y1, double cx, double cy, int sampleWidth);
  ~julia();

  /**
   * Draw the image
   * @return The resulting image
   */
  image drawImage();
};

/**
 * Mandelbrot Set Renderer
 * This class takes a range over which to generate an image, and then generates a maldelbrot set to fill that region.
 */
class mandelbrot {
 public:
  int *data;
  int rows, cols;

  /**
   * Primative Constructor
   */
  mandelbrot();
  /**
   * Constructor
   * @param x0 The lower left x value of the range to show
   * @param y0 The lower left y value of the range to show
   * @param x1 The upper right x value of the range to show
   * @param y1 The upper right x value of the range to show
   * @param sampleWidth The width of the resulting image, in pixels
   */
  mandelbrot(double x0, double y0, double x1, double y1, int sampleWidth);
  ~mandelbrot();

  /**
   * Draw the image
   * @return The resulting image
   */
  image drawImage();
};

#endif
