#!/bin/sh
#
#  Script to compile and run graphics
#  Written by Will Moss
#

print_usage()
{
    echo "Usage: $0 -c -d -o {source program}"; 
    echo "Where -c clean before compile";
    echo "      -d don't run after compiling";
    echo "      -o open the output image in xzgv";
    return
}

if [ $# -eq 0 ] ; then
    print_usage
    exit 1
fi

pushd . > /dev/null

clean=0
run=1
open=0
while getopts cdme: opt 
do
  case "$opt" in
      c) clean=1;;
      d) run=0;;
      o) open=1;;
      x) echo "Should Open"; exit 1;;
      \?) print_usage; exit 1;;
  esac
done

shift `expr $OPTIND -	1`    # shift options out of command line string

if [ -z $1 ]; then
    print_usage
    exit 1
fi

cd ~/graphics/lib
if [ $clean -eq 1 ]; then
    make clean
fi
make
cd ~/graphics/src
if [ $clean -eq 1 ]; then
    make clean
fi
make $1

if [ $run -eq 1 ]; then
    echo ""
    echo "Running $1..."
    ~/graphics/bin/$1
    echo "Completed Execution..."
fi

if [ $open -eq 1 ]; then
    echo "Opening in xzgv..."
    echo "This feature does not work yet."
fi

popd > /dev/null

